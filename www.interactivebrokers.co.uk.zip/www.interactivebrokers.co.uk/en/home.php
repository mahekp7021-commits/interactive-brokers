
<!DOCTYPE html>
<html dir="ltr" lang="en" data-theme="light">
<head>
<title>Home | Interactive Brokers U.K. Limited</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
<meta name="description" content="Leading online trading solutions for traders, investors and advisors, with direct global access to stocks, options, futures, currencies, bonds and funds. Transparent, low commissions and financing rates and support for best execution.">
<meta name="keywords" content="lowest cost, online broker, best execution, advanced technology, direct market access, global trading, stocks, options, futures, currencies, fixed income, mutual funds, ETFs">
<meta name="author" content="Interactive Brokers">
<meta name="robots" content="index, follow">
<meta property="og:site_name" content="Interactive Brokers U.K. Limited" />
<link rel="canonical" href="https://www.interactivebrokers.co.uk/en/home.php" />
<script type="application/ld+json">
{
"@context": "https://schema.org",
"@type": "Organization",
"name": "Interactive Brokers U.K. Limited",
"description":"Financial Services Company",
"disambiguatingDescription":"Financial Services Company",
"url": "https://www.interactivebrokers.co.uk"
}
</script>
<meta name="apple-mobile-web-app-title" content="IBKR">
<link rel="icon" sizes="192x192" href="/images/web/favicons/home-screen-icon-192x192.png" />
<link rel="icon" sizes="128x128" href="/images/web/favicons/home-screen-icon-128x128.png" />
<link rel="apple-touch-icon" sizes="57x57" href="/images/web/favicons/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon" sizes="72x72" href="/images/web/favicons/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon" sizes="114x114" href="/images/web/favicons/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon" sizes="144x144" href="/images/web/favicons/apple-touch-icon-144x144.png" />
<!-- SCRIPTS HEAD  -->
<script type="text/javascript">
const FP_PAGE_ID = '';
</script>
<script type="text/javascript" src='/scripts/common/js/jquery-3.6.1/jquery.min.js'></script>
<script type="text/javascript">
function createScriptElement(data) {
 if (typeof data == "undefined") {
  return;
 }
 var element = document.createElement("SCRIPT");
 element.type = "text/javascript";
 if (typeof data.id != "undefined") {
  element.id = data.id;
 }
 if (typeof data.source != "undefined") {
  element.src = data.source;
 }
 if (typeof data.loadfunction == "function") {
  element.onload = data.loadfunction;
 }
 document.head.appendChild(element);
}
function getCookieVal(cname) 
{
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(";");
  for(var i = 0; i <ca.length; i++) 
  {
      var c = ca[i];
      while (c.charAt(0) == " ") 
      {
            c = c.substring(1);
      }
      if (c.indexOf(name) == 0)
      {
            return c.substring(name.length, c.length);
        }
  }
  return "";
}
function checkWebCookie() 
{
if(!(getCookieVal('web') === '')){
    
}
if(!localStorage.getItem('web')){
  var webCookieVal = 4409713662;
  localStorage.setItem('web', webCookieVal);
}
  setTimeout(addCookies(), 100);
}
createScriptElement({ source : "/scripts/common/js/bootstrap-5.2.2/bootstrap.bundle.min.js", loadfunction: bsLoaded  });
createScriptElement({ source : "/scripts/common/js/lib.js?ver=9" });
createScriptElement({ source :  "/scripts/common/js/forge.all.min.js" });
createScriptElement({ source : "/scripts/common/js/analytics/ibkrfingerprint.js?t=1791706988" }); 
createScriptElement({ source : "/scripts/common/js/analytics/ibkranalyticscomb.js?t=1791706988" });
window.onload = function (){ checkWebCookie();}
    window.onload = function (){ mapAnalytics(); }
  function storeCookie()
{
 if(typeof(Storage) !== 'undefined')
 {
 }
}
createScriptElement({ source : "/scripts/common/js/ibmkttrack.js" });
function bsLoaded() {
  createScriptElement({ source : "/scripts/common/js/appear/appear.min.js?ver=1" });
  createScriptElement({ source : "/scripts/common/js/easing/easing.min.js?ver=1" });
  createScriptElement({ source : "/scripts/common/js/parallax/parallax.min.js?ver=1" });
  createScriptElement({ source : "/scripts/common/js/uitotop/uitotop.min.js?ver=1", loadfunction: uiLoaded });
}
function uiLoaded() {
  createScriptElement({ source : "/scripts/common/js/twsUtils.js?ver=2" });
  createScriptElement({ source : "/scripts/common/js/design/design.js?ver=1" }); 
}
</script>
<script type="text/javascript">
$(function() {
 $('div#langselector').find('a').each(function() {
  $(this).click(function() {
   var link = $(this).attr("href");
   if(link.match(/\/(en|fr|de|es|it|ru|cn|jp)\//))
   {
    var langs = link.split("/");
    if(langs[3] == 'en' || langs[3] == 'fr' || langs[3] == 'de' || langs[3] == 'es' || langs[3] == 'it' || langs[3] == 'ru' || langs[3] == 'cn' || langs[3] == 'jp')
    {
      var lang = langs[3];
      if(lang == 'cn')
      {
        lang = 'zh_CN';
      }
      if(lang == 'jp')
      {
        lang = 'ja';
      }
      if(hasCookie("IB_LANG"))
      {
        deleteCookie("IB_LANG");
      }
      setCookie("IB_LANG", lang, 7, '.interactivebrokers.co.uk');
    } else if(langs[1] == 'en') {
      var lang = 'en';
      setCookie("IB_LANG", lang, 7, '.interactivebrokers.co.uk');
    }
   }
  });
 });
 $('p#bandaid-close').click(function() {
  setCookie("IB_BANDAID", 1, 7, '.interactivebrokers.co.uk');
 });
 $('a#btnCloseBannerRegionSelector').click(function() {
  setCookie("IB_REGION_SEL", 1, 30, '.interactivebrokers.co.uk');
 });
 $('a#btnCloseBannerRegionDifc').click(function() {
  setCookie("IB_DIFC", 1, 30, '.interactivebrokers.co.uk');
 });
});
</script>
<script type="text/javascript">
$(document).ready(function(){

    // Shared helper: updates <html data-theme>, style attr, meta tag, and toggle buttons
    function applyTheme(theme) {
        $("html").attr("data-theme", theme);
        $("html").attr("style", "color-scheme:" + theme + ";");
        var $meta = $('meta[name="color-scheme"]');
        if ($meta.length) {
            $meta.attr("content", theme);
        } else {
            $('<meta>').attr({
                name: "color-scheme",
                content: theme
            }).appendTo('head');
        }
        if (theme === "light") {
            $("#desktop_dark, #mobile_dark").removeClass("active");
            $("#desktop_light, #mobile_light").addClass("active");
        } else {
            $("#desktop_light, #mobile_light").removeClass("active");
            $("#desktop_dark, #mobile_dark").addClass("active");
        }
    }
    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(";");
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == " ") {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }
    var currentCookie = getCookie("IB_THEME");
    if (currentCookie === "") {
        function getThemeFromOSorBrowser() {
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                return 'dark';
            } else {
                return 'light';
            }
        }
        function themeAlterListener(event) {
            const theme = event.matches ? 'dark' : 'light';
            applyTheme(theme);
        }
        const themeAtStart = getThemeFromOSorBrowser();
        document.cookie = "IB_THEME=" + themeAtStart + ";" + "path=/";
        applyTheme(themeAtStart);
        const themeMediaCheckCommand = window.matchMedia('(prefers-color-scheme: dark)');
        themeMediaCheckCommand.addListener(themeAlterListener);
    } else if (currentCookie === "light") {
        applyTheme("light");
    } else if (currentCookie === "dark") {
        applyTheme("dark");
    }
    $(".switch-data-theme").on("click", function(e){
        e.preventDefault();
        document.cookie = "IB_THEME=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
        var datatheme = $(this).hasClass("data-theme-dark") ? "dark" : "light";
        document.cookie = "IB_THEME=" + datatheme + ";" + "path=/";
        applyTheme(datatheme);
    });
});
</script>

<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    if(localStorage.getItem('consentMode') ===  null){
                    const consentMode = {
                'ad_storage': "granted",
                'ad_user_data': "granted",
                'ad_personalization': "granted",
                'analytics_storage': "granted"
            };
                localStorage.setItem('consentMode', JSON.stringify(consentMode));
        gtag('consent', 'default', consentMode);
    }
    else {
        gtag('consent', 'default', JSON.parse(localStorage.getItem('consentMode')));
    }
</script>
<!-- STYLES HEAD -->
<style type="text/css">
@import url('/css/bootstrap-5.2.2/bootstrap.min.css') layer(bootstrap);
</style>
<link rel="preload" as="style" href="/css/ibkr/main.min.css?v=b55b7ddc0d85cd05fcfd81527713c0eb">
<link rel="stylesheet" type="text/css" media="all" href="/css/ibkr/main.min.css?v=b55b7ddc0d85cd05fcfd81527713c0eb">
<link rel="preload" as="style" href="/css/ibkr/themes/theme-ibkr.min.css?v=b55b7ddc0d85cd05fcfd81527713c0eb">
<link rel="stylesheet" type="text/css" media="all" href="/css/ibkr/themes/theme-ibkr.min.css?v=b55b7ddc0d85cd05fcfd81527713c0eb"><link rel="stylesheet" type="text/css" media="all" href="/css/ibkr/home.min.css">

<script>(window.BOOMR_mq=window.BOOMR_mq||[]).push(["addVar",{"rua.upush":"true","rua.cpush":"false","rua.upre":"true","rua.cpre":"false","rua.uprl":"false","rua.cprl":"false","rua.cprf":"false","rua.trans":"SJ-5bed8481-c756-4000-ad8f-bf95203b4110","rua.cook":"true","rua.ims":"false","rua.ufprl":"false","rua.cfprl":"true","rua.isuxp":"false","rua.texp":"norulematch","rua.ceh":"false","rua.ueh":"false","rua.ieh.st":"0"}]);</script>
                                <script>!function(e){var n="https://s.go-mpulse.net/boomerang/";if("False"=="True")e.BOOMR_config=e.BOOMR_config||{},e.BOOMR_config.PageParams=e.BOOMR_config.PageParams||{},e.BOOMR_config.PageParams.pci=!0,n="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="E6798-MSRLA-AGTKP-4QTSS-AEXF9",function(){function e(){if(!i){var e=document.createElement("script");e.id="boomr-scr-as",e.src=window.BOOMR.url,e.async=!0,o.parentNode.appendChild(e),i=!0}}function t(e){i=!0;var n,t,a,r,d=document,O=window;if(window.BOOMR.snippetMethod=e?"if":"i",t=function(e,n){var t=d.createElement("script");t.id=n||"boomr-if-as",t.src=window.BOOMR.url,BOOMR_lstart=(new Date).getTime(),e=e||d.body,e.appendChild(t)},!window.addEventListener&&window.attachEvent&&navigator.userAgent.match(/MSIE [67]\./))return window.BOOMR.snippetMethod="s",void t(o.parentNode,"boomr-async");a=document.createElement("IFRAME"),a.src="about:blank",a.title="",a.role="presentation",a.loading="eager",r=(a.frameElement||a).style,r.width=0,r.height=0,r.border=0,r.display="none",o.parentNode.appendChild(a);try{O=a.contentWindow,d=O.document.open()}catch(_){n=document.domain,a.src="javascript:var d=document.open();d.domain='"+n+"';void(0);",O=a.contentWindow,d=O.document.open()}if(n)d._boomrl=function(){this.domain=n,t()},d.write("<bo"+"dy onload='document._boomrl();'>");else if(O._boomrl=function(){t()},O.addEventListener)O.addEventListener("load",O._boomrl,!1);else if(O.attachEvent)O.attachEvent("onload",O._boomrl);d.close()}function a(e){window.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!window.BOOMR||!window.BOOMR.version&&!window.BOOMR.snippetExecuted){window.BOOMR=window.BOOMR||{},window.BOOMR.snippetStart=(new Date).getTime(),window.BOOMR.snippetExecuted=!0,window.BOOMR.snippetVersion=12,window.BOOMR.url=n+"E6798-MSRLA-AGTKP-4QTSS-AEXF9";var o=document.currentScript||document.getElementsByTagName("script")[0],i=!1,r=document.createElement("link");if(r.relList&&"function"==typeof r.relList.supports&&r.relList.supports("preload")&&"as"in r)window.BOOMR.snippetMethod="p",r.href=window.BOOMR.url,r.rel="preload",r.as="script",r.addEventListener("load",e),r.addEventListener("error",function(){t(!0)}),setTimeout(function(){if(!i)t(!0)},3e3),BOOMR_lstart=(new Date).getTime(),o.parentNode.appendChild(r);else t(!1);if(window.addEventListener)window.addEventListener("load",a,!1);else if(window.attachEvent)window.attachEvent("onload",a)}}(),"".length>0)if(e&&"performance"in e&&e.performance&&"function"==typeof e.performance.setResourceTimingBufferSize)e.performance.setResourceTimingBufferSize();!function(){if(BOOMR=e.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var n="true"=="true"?1:0,t="cookiepresent",a="m447z6yxg72ke2wli5wa-f-5c05eef1c-clientnsv4-s.akamaihd.net",o="false"=="true"?2:1,i={"ak.v":"41","ak.cp":"1150933","ak.ai":parseInt("714965",10),"ak.ol":"0","ak.cr":6,"ak.ipv":4,"ak.proto":"h2","ak.rid":"b4ca0e97","ak.r":50721,"ak.a2":n,"ak.m":"a","ak.n":"essl","ak.cport":51700,"ak.gh":"23.55.244.158","ak.quicv":"","ak.tlsv":"tls1.3","ak.0rtt":"","ak.0rtt.ed":"","ak.csrc":"-","ak.acc":"","ak.t":"1791706988","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==53SwJm6j+a1vPrdT8VB8Q8OMRxj7V2yPUDE1EePzIqkcW0xYpNOmp3wgdi5xKBoHQr42D2KV80CXCPRO/nnJK7YyOwEMlMnmWfCp2qmIwgWf21JpbnHfDX3cYu3kYlRIpkRr9MXxX0xATruaP/mawNKNL0p93Hl/MR7QyNtVF3d+RyJeRrGNbyn6DDF1f9RO99lVnLn5MAdZBDnDX/WO6ZqHnBLLSRIvDnA2ZikCv6FC4XttquxnM8AgTXHyQSEfXerCNhE2nHUDt0ADsoJ20FPtH/WatwkeaMlg8sJfKxrOp8tkJ6DnS7lNTjKAaaxs8nGhJd/XTDjeX2RzT20/Fd6/EdFpezgG70M8R6A/8IFqG/TLmom0D7KsLCa+PyFJikEQ/GEP/cKaLfuHddzv+STnqkV9kySb4QFM2GlOHxk=","ak.pv":"98","ak.dpoabenc":"","ak.tf":o};if(""!==t)i["ak.ruds"]=t;var r={i:!1,av:function(n){var t="http.initiator";if(n&&(!n[t]||"spa_hard"===n[t]))i["ak.feo"]=void 0!==e.aFeoApplied?1:0,BOOMR.addVar(i)},rv:function(){var e=["ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.m","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.0rtt.ed","ak.r","ak.acc","ak.t","ak.tf"];BOOMR.removeVar(e)}};BOOMR.plugins.AK={akVars:i,akDNSPreFetchDomain:a,init:function(){if(!r.i){var e=BOOMR.subscribe;e("before_beacon",r.av,null,null),e("onbeacon",r.rv,null,null),r.i=!0}return this},is_complete:function(){return!0}}}}()}(window);</script></head>
<body>
<!-- GOOGLE ---------------------------------------------------------------------------------------------------- -->
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='/gtmibkruk/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-KJ7JR5V');</script>
<!-- End Google Tag Manager -->
<!-- MENU ---------------------------------------------------------------------------------------------------- -->
<!-- HEADER START --------------------------------------------------------------------------------------------------- -->
<div class="ibkr-header" id="ibkr-header" role="banner">
                <style type="text/css">
.banner-risk-warning {
    margin:0px;
    padding:8px 0px;
    width:100%;
    height:auto;
    background-color:#242424;
}
.banner-risk-warning p {
    margin:0px;
    padding:0px;
    font-weight:400;
    font-size:1.0rem;
    line-height:1.25rem;
    text-align:center;
    color:var(--white-80);
}
/* BOOTSTRAP 4 | MEDIA QUERY | EXTRA SMALL (< 576PX) ---------------------------------------------------------------------------------------------------- */
@media (max-width:575.98px) {
    .banner-risk-warning {
        padding:4px 0px;
    }
    .banner-risk-warning p {
        font-size:0.8125rem;
        line-height:1.0rem;
    }
}
/* BOOTSTRAP 4 | MEDIA QUERY | SMALL (576PX-767.98PX) ---------------------------------------------------------------------------------------------------- */
@media (min-width:576px) and (max-width:767.98px) {
    .banner-risk-warning {
        padding:4px 0px;
    }
    .banner-risk-warning p {
        font-size:0.8125rem;
        line-height:1.0rem;
    }
}
/* BOOTSTRAP 4 | MEDIA QUERY | MEDIUM (768PX-991.98PX) ---------------------------------------------------------------------------------------------------- */
@media (min-width:768px) and (max-width:991.98px) {
    .banner-risk-warning {
        padding:4px 0px;
    }
    .banner-risk-warning p {
        font-size:0.8125rem;
        line-height:1.0rem;
    }
}
/* BOOTSTRAP 4 | MEDIA QUERY | LARGE (992PX-1199.98PX) ---------------------------------------------------------------------------------------------------- */
@media (min-width:992px) and (max-width:1199.98px) {
}
/* BOOTSTRAP 4 | MEDIA QUERY | EXTRA LARGE (>1200PX) ---------------------------------------------------------------------------------------------------- */
@media (min-width:1200px) {
    
}
</style>
<div class="banner-risk-warning">
    <div class="container">
        <div class="row">
            <div class="col">
                <p>Investing in financial products involves risk. Losses may exceed the value of your original investment.</p>
            </div>
        </div>
    </div>
</div>    <!-- NAV TOP START (LG/XL ONLY) -->
    <nav class="navbar navbar-inverse navbar-expand-lg navbar-top d-none d-lg-block" role="navigation" aria-label="Top navigation">
        <div class="container">
            <div class="navbar-collapse collapse" id="ibkr-nav-top">
                <!-- LEFT MENU -->
                <ul class="navbar-nav mr-auto align-items-center">
                    <!-- FOR INDIVIDUALS -->
                    <li class="nav-item dropdown"><a href="#" target="_self" class="nav-link dropdown-toggle" id="nav-for-individuals" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">For Individuals</a>
                        <div class="dropdown-menu dropdown-ind-accounts" aria-labelledby="nav-for-individuals">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/accounts/individual.php" target="_self" class="dropdown-item" >Individual or Joint</a>
                                    <a href="/en/accounts/trust.php" target="_self" class="dropdown-item" >Trust Accounts</a>
                                    <a href="/en/accounts/family-account.php" target="_self" class="dropdown-item" >Family Accounts</a>
                                                                            <a href="/en/accounts/isa-accounts.php" target="_self" class="dropdown-item" >Individual Savings Account (ISA)</a>
                                        <a href="/en/accounts/individuals/sippAccount.php" target="_self" class="dropdown-item" >Self-Invested Personal Pension (SIPP)</a>
                                                                    </div>
                            </div>
                        </div>
                    </li>
                    <!-- FOR INSTITUTIONS -->
                    <li class="nav-item dropdown"><a href="#" target="_self" class="nav-link dropdown-toggle" id="nav-for-institutions" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">For Institutions</a>
                        <div class="dropdown-menu dropdown-inst-accounts" aria-labelledby="nav-for-institutions">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/accounts/institutions.php" target="_self" class="dropdown-item" >Institutions Home</a>
                                    <p class="pb-0 dropdown-item-label">ADVISOR ACCOUNTS</p>
                                    <a href="/en/accounts/advisor/overview.php" target="_self" class="dropdown-item indent-1x" >Registered Investment Advisors</a>
                                    <a href="/en/accounts/family-office.php" target="_self" class="dropdown-item indent-1x" >Family Offices</a>
                                    <p class="pb-0 dropdown-item-label">INSTITUTIONAL ACCOUNTS</p>
                                    <a href="/en/accounts/proprietary-trading-group.php" target="_self" class="dropdown-item indent-1x" >Proprietary Trading Groups</a>
                                    <a href="/en/accounts/hedge-fund.php" target="_self" class="dropdown-item indent-1x" >Hedge Funds</a>
                                    <a href="/en/accounts/broker.php" target="_self" class="dropdown-item indent-1x" >Introducing Brokers</a>
                                    <a href="/en/accounts/small-business.php" target="_self" class="dropdown-item indent-1x" >Small Businesses</a>
                                    <a href="/en/accounts/fsa-insurance-providers.php" target="_self" class="dropdown-item indent-1x" >Full-Service Administrator <br>Insurance Providers</a>
                                    <a href="/en/accounts/money-manager.php" target="_self" class="dropdown-item indent-1x" >Money Managers</a>
                                    <p class="pb-0 dropdown-item-label">ADMINISTRATIVE ACCOUNTS</p>
                                    <a href="/en/accounts/compliance-officer.php" target="_self" class="dropdown-item indent-1x" >Compliance Officers</a>
                                    <a href="/en/accounts/administrator.php" target="_self" class="dropdown-item indent-1x" >Fund Administrators</a>
                                     
                                    <p class="pb-0 dropdown-item-label">OTHER ACCOUNTS</p>
                                    <a href="https://interactivebrokers.eu/campus/stl/" target="_blank" class="dropdown-item indent-1x" >Educators</a>
                                                                    </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <!-- RIGHT MENU -->
                <ul class="navbar-nav ml-auto align-items-center">
                                        <!-- FREE TRIAL -->
                    <li class="nav-item"><a href="/en/trading/free-trial.php" target="_self" class="nav-link">FREE TRIAL</a></li>
                                        <!-- CAREERS -->
                    <li class="nav-item"><a href="/en/general/about/careers-splash.php" target="_self" class="nav-link">Careers</a></li>
                    <!-- ABOUT US -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" id="nav-about-us" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About Us</a>
                        <div class="dropdown-menu dropdown-about-us" aria-labelledby="nav-about-us">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/general/financial-strength.php" target="_self" class="dropdown-item" >Strength and Security</a>
                                    <a href="/en/general/about/info-and-history.php" target="_self" class="dropdown-item">Information and History</a>
                                    <a href="/en/general/awards.php" target="_self" class="dropdown-item">Awards</a>
                                    <a href="/en/about/news-at-ibkr.php" target="_self" class="dropdown-item">News at IBKR</a>
                                    <a href="/en/general/about/press-and-media.php" target="_self" class="dropdown-item">Press and Media</a>
                                    <a href="https://investors.interactivebrokers.com/ir/main.php" target="_blank" class="dropdown-item" rel="noreferrer noopener">Investor Relations</a>
                                    <a href="/en/general/ibkr-on-social-media.php" target="_self" class="dropdown-item" rel="noreferrer noopener">IBKR on Social Media</a>
                                    <a href="/en/general/about/sustainability.php" target="_self" class="dropdown-item">Sustainability</a>
                                    <a href="/en/accounts/legalDocuments/brokerPerformanceReports.php" target="_self" class="dropdown-item">Regulatory Reports</a>
                                    <a href="/en/accounts/referrer.php" target="_self" class="dropdown-item">Refer a Friend</a>
                                    <a href="/en/general/about/affiliate-programs.php" target="_self" class="dropdown-item">Affiliate Programs</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- SUPPORT -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" id="nav-support" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Support</a>
                        <div class="dropdown-menu dropdown-contact-us" aria-labelledby="nav-support">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/support/fund-my-account.php" target="_self" class="dropdown-item">Fund Your Account</a>
                                    <a href="/en/support/individuals.php" target="_self" class="dropdown-item">For Individuals</a>
                                    <a href="/en/support/institutions.php" target="_self" class="dropdown-item">For Institutions</a>
                                    <a href="/en/support/institutional-sales-contacts.php?p=uk" target="_self" class="dropdown-item">Institutional Sales Contacts</a>
                                                                        <a href="/en/general/contact/ibot-container.php" target="_self" class="dropdown-item">Browse Our FAQs</a>
                                                                        <a href="/en/support/reports-and-dates.php" target="_self" class="dropdown-item">Tax Information</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- LANGUAGE SELECTOR -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link nav-language dropdown-toggle" id="nav-language" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span>Language</span><img src="/images/web/icons/icon-language.svg" alt="Language" width="23" height="18" border="0" /></a>
                        <div class="dropdown-menu dropdown-language" aria-labelledby="nav-language">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/home.php" class="dropdown-item">English</a>
                                    <a href="/fr/home.php" target="_self" class="dropdown-item">Français</a>
                                    <a href="/de/home.php" target="_self" class="dropdown-item">Deutsch</a>
                                    <a href="/es/home.php" target="_self" class="dropdown-item">Español</a>
                                    <a href="/it/home.php" target="_self" class="dropdown-item">Italiano</a>
                                    <a href="/ru/home.php" target="_self" class="dropdown-item">Pусский</a>
                                                                    </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- NAV TOP END -->
    <!-- NAV BOTTOM START -->
    <nav class="navbar navbar-inverse navbar-expand-lg navbar-bottom" role="navigation" aria-label="Main navigation">
        <div class="container">
            <!-- LOGO -->
                        <a href="/en/home.php" target="_self" title="Interactive Brokers Home" alt="Interactive Brokers Logo" class="navbar-brand brand-logo" aria-label="Interactive Brokers Home"><span>Interactive Brokers Home</span></a>
            <!-- TOGGLE (XS/SM/MD ONLY) -->
            <button class="navbar-toggler" type="button" aria-label="Toggle Navigation"><span class="navbar-toggler-icon"><i class="fas fa-bars" aria-hidden="true"></i></span></button>
            <!-- OPEN ACCOUNT BUTTON (XS/SM/MD ONLY) -->
            <a href="https://www.interactivebrokers.co.uk/Universal/Application" target="_self" data-type="cta" class="d-block d-lg-none btn btn-open-account">Open Account</a>
            <!-- LOG IN (SM/MD ONLY) -->
                            <a href="https://www.interactivebrokers.co.uk/sso/Login?RL=1" target="_self" class="d-none d-sm-block d-lg-none btn btn-log-in">Log In</a>
                        <!-- IBKR NAV BOTTOM START -->
            <div class="navbar-collapse collapse" id="ibkr-nav-bottom">
                <ul class="navbar-nav ml-auto align-items-center">
                    <!-- WHY IBKR -->
                    <li class="nav-item"><a href="/en/whyib/overview.php" target="_self" class="nav-link">Why IBKR</a></li>
                    <!-- WHY IBKR JAPAN -->
                                        <!-- PRICING -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" id="nav-pricing" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pricing</a>
                        <div class="dropdown-menu dropdown-pricing" aria-labelledby="nav-pricing">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/pricing/commissions-home.php" target="_self" class="dropdown-item">Commissions</a>
                                    <a href="/en/trading/margin-rates.php" target="_self" class="dropdown-item">Margin Rates</a>
                                    <a href="/en/accounts/fees/pricing-interest-rates.php" target="_self" class="dropdown-item">Interest Rates</a>
                                    <a href="/en/pricing/short-sale-cost.php" target="_self" class="dropdown-item">Short Sale Cost</a>
                                    <a href="/en/pricing/market-data-pricing.php" target="_self" class="dropdown-item">Market Data Pricing</a>
                                    <a href="/en/pricing/stock-yield-enhancement-program.php" target="_self" class="dropdown-item">Stock Yield Enhancement Program</a>
                                    <a href="/en/pricing/other-fees-overview.php" target="_self" class="dropdown-item">Other Fees</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- TRADING -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" id="nav-technology" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Trading</a>
                        <div class="dropdown-menu dropdown-technology" aria-labelledby="nav-technology">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/trading/trading-platforms.php" target="_self" class="dropdown-item">Platforms</a>
                                    <a href="/en/trading/ib-api.php" target="_self" class="dropdown-item">APIs</a>
                                    <a href="/en/trading/margin.php" target="_self" class="dropdown-item">Margin</a>
                                    <a href="/en/trading/ai-integrations.php" target="_self" class="dropdown-item">AI Integration</a>
                                    <a href="/en/trading/products-exchanges.php" target="_self" class="dropdown-item">Symbol and Exchange Search</a>
                                    <a href="/en/trading/products-stocks.php" target="_self" class="dropdown-item">Products Overview</a>
                                    <a href="/en/pricing/research-news-services.php" target="_self" class="dropdown-item">Research and News</a>
                                    <a href="/en/trading/clients-ibkr-ats.php?menu=A" target="_self" class="dropdown-item">IBKR ATS</a>
                                    <a href="/en/trading/ordertypes.php" target="_self" class="dropdown-item">Order Types</a>
                                    <a href="/en/whyib/reporting.php" target="_self" class="dropdown-item">Reporting</a>
                                    <a href="/en/trading/securities-financing.php" target="_self" class="dropdown-item">Securities Financing</a>
                                    <a href="/en/trading/features-in-focus.php" target="_self" class="dropdown-item">Features in Focus</a>
                                    <a href="/en/general/education/probability_lab.php" target="_self" class="dropdown-item">Probability Lab</a>
                                    <a href="/en/trading/global-outsourced-trading-desk.php" target="_self" class="dropdown-item">Global Outsourced Trading Desk</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- SERVICES -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" id="nav-products" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
                        <div class="dropdown-menu dropdown-products" aria-labelledby="nav-products">
                            <div class="row">
                                <div class="col">
                                    <a href="/en/trading/globalanalyst.php" target="_self" class="dropdown-item">IBKR GlobalAnalyst</a>
                                    <a href="/en/portfolioanalyst/overview.php" target="_self" class="dropdown-item" rel="noreferrer noopener">PortfolioAnalyst</a>
                                    <a href="/en/trading/products-bonds.php" target="_self" class="dropdown-item">Bonds Marketplace</a>
                                    <a href="/en/trading/products-mutual-funds.php" target="_self" class="dropdown-item">Mutual Funds Marketplace</a>
                                    <a href="/en/trading/commission-free-etfs-mkt.php" target="_self" class="dropdown-item">No Transaction Fee ETFs</a>
                                    <a href="https://ndcdyn.interactivebrokers.com/aces/Marketplace/InvestorsMarketplace" target="_blank" class="dropdown-item">Investors' Marketplace</a>
                                    <a href="/en/trading/short-securities-availability.php" target="_self" class="dropdown-item">Short Securities Availability</a>
                                    <a href="/en/trading/third-party-integration.php" target="_self" class="dropdown-item">Third Party Integration</a>
                                    <a href="/en/trading/sustainable-investing.php" target="_self" class="dropdown-item">Sustainable Investing</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- EDUCATION -->
                    <li class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" id="nav-education" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Education</a>
                        <div class="dropdown-menu dropdown-education" aria-labelledby="nav-education">
                            <div class="row">
                                <div class="col">
                                     
                                    <a href="https://interactivebrokers.eu/campus/" target="_blank" class="dropdown-item">IBKR Campus</a>
                                    <a href="https://interactivebrokers.eu/campus/academy" target="_blank" class="dropdown-item" rel="noreferrer noopener">Traders' Academy</a>
                                    <a href="https://interactivebrokers.eu/campus/news" target="_blank" class="dropdown-item" rel="noreferrer noopener">Traders' Insight</a>
                                    <a href="https://interactivebrokers.eu/campus/category/podcasts/" target="_blank" class="dropdown-item" rel="noreferrer noopener">IBKR Podcasts</a>
                                    <a href="https://interactivebrokers.eu/campus/quant" target="_blank" class="dropdown-item" rel="noreferrer noopener">IBKR Quant Blog</a>
                                    <a href="https://interactivebrokers.eu/campus/webinars" target="_blank" class="dropdown-item" rel="noreferrer noopener">Webinars</a>
                                    <a href="/en/trading/fif-ibkr-forum.php" target="_self" class="dropdown-item" >IBKR Forum</a>
                                    <a href="https://interactivebrokers.eu/campus/stl/" target="_blank" class="dropdown-item">Student Trading Lab</a>
                                    <a href="https://interactivebrokers.eu/campus/glossary" target="_blank" class="dropdown-item" rel="noreferrer noopener">Traders' Glossary</a>
                                                                        <a href="/en/general/calendar/calendar.php" target="_self" class="dropdown-item">Traders' Calendar</a>
                                </div>
                            </div>
                        </div>
                    </li>
                                         <!-- AI SEARCH -->
                    <li class="nav-item d-none d-lg-block" >
                        <a href="/en/search/index.php" class="nav-link nav-search" id="nav-search" aria-label="Search" target="_self"><span>Search</span><i class="fas fa-search" aria-hidden="true"></i></a>
                    </li>
                                         <!-- LOG IN -->
                    <li class="nav-item dropdown d-none d-lg-block"><a href="#" target="_self" class="nav-link nav-login dropdown-toggle" id="nav-log-in" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Log In</a>
                        <div class="dropdown-menu dropdown-login" aria-labelledby="nav-log-in">
                            <div class="row">
                                <div class="col">
                                                                            <a href="https://www.interactivebrokers.co.uk/sso/Login?RL=1" target="_self" class="dropdown-item dropdown-portal">Portal Login</a>
                                                                        <a href="/en/trading/ibkr-desktop-download.php" target="_self" class="dropdown-item">Download IBKR Desktop </a>
                                    <a href="/en/trading/download-tws.php" target="_self" class="dropdown-item">Download Trader Workstation</a>
                                    <a href="/en/trading/ibkr-mobile.php#download" target="_self" class="dropdown-item">Download IBKR Mobile</a>
                                    <a href="/en/trading/ibgateway-latest.php" target="_self" class="dropdown-item">Download IB Gateway</a>
                                    <a href="/en/trading/trading-platforms.php" target="_self" class="dropdown-item">Compare All IBKR Platforms</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- OPEN ACCOUNT -->
                    <li class="nav-item dropdown d-none d-lg-block"><a href="#" target="_self" class="nav-link nav-open-account dropdown-toggle" id="nav-open-account" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Open Account</a>
                        <div class="dropdown-menu dropdown-open-account" aria-labelledby="nav-open-account">
                            <div class="row">
                                <div class="col">
                                    <a href="https://www.interactivebrokers.co.uk/Universal/Application" target="_self" data-type="cta" class="dropdown-item dropdown-portal">Start Application</a>
                                    <a href="https://www.interactivebrokers.co.uk/sso/Login?c=t" target="_self" class="dropdown-item">Finish an Application</a>
                                    <a href="/en/general/what-you-need-inv.php" target="_self" class="dropdown-item">What You Need</a>
                                    <a href="/en/accounts/account-guide.php" target="_self" class="dropdown-item">A Guide to Choosing the Right Account</a>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <!-- IBKR MENU END -->
            </div>
        </div>
    </nav>
    <!-- NAV BOTTOM END -->
</div>
<!-- HEADER END ---------------------------------------------------------------------------------------------------- -->
<!-- MOBILE NAV START (XS/SM/MD ONLY) ---------------------------------------------------------------------------------------------------- -->
<div class="menu-mobile d-lg-none" role="navigation" aria-label="Mobile navigation">
    <!-- CLOSE BUTTON -->
    <div class="close-button"><button type="button" class="btn-close" aria-label="Close Menu"><i class="fas fa-times"></i></button></div>
    <!-- LOGO -->
    <div class="logo-container"><a href="/en/home.php" target="_self" class="brand-logo" aria-label="Interactive Brokers Home"><span>Interactive Brokers Home</span></a></div>
        <!-- AI SEARCH -->
    <div class="search-container-gen-ai pt-10 pb-10 ps-20 pe-20 bg-gray-5">
        <div class="search-box w-100 text-center">
            <a href="/en/search/index.php" target="_self"  class="btn btn-sm btn-tertiary btn-outline w-100 mt-1">Ask a Question <i class="fas fa-search" aria-hidden="true"></i></a>  <!--  type="button"  -->
        </div>
    </div>
        <ul>
            <li><a href="https://www.interactivebrokers.co.uk/sso/Login?RL=1" target="_self" class="menu-log-in">Portal Login</a></li>
        <!-- OPEN ACCOUNT -->
    <li class="has-submenu"><a href="#" target="_self" class="menu-open-account" data-submenu="submenu-open-account">Open Account</a>
        <div class="submenu" id="submenu-open-account">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-open-account">Back</button></p>
            <p class="submenu-title">OPEN ACCOUNT</p>
            <ul>
            <li><a href="https://www.interactivebrokers.co.uk/Universal/Application" target="_self" data-type="cta" class="menu-start-application">Start Application</a></li>
            <li><a href="https://www.interactivebrokers.co.uk/sso/Login?c=t" target="_self">Finish an Application</a></li>
            <li><a href="/en/general/what-you-need-inv.php" target="_self">What You Need</a></li>
            <li><a href="/en/accounts/account-guide.php" target="_self">A Guide to Choosing the Right Account</a></li>
            </ul>
        </div>
    </li>
            <!-- FREE TRIAL -->
    <li><a href="/en/trading/free-trial.php" target="_self">Free Trial</a></li>
        <!-- WHY IBKR -->
    <li><a href="/en/whyib/overview.php" target="_self">Why IBKR</a></li>
    <!-- ACCOUNT TYPES -->
    <li class="has-submenu"><a href="#" target="_self" data-submenu="submenu-account-types">Account Types</a>
        <div class="submenu" id="submenu-account-types">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-account-types">Back</button></p>
            <p class="submenu-title">FOR INDIVIDUALS</p>
            <ul>
            <li><a href="/en/accounts/individual.php" target="_self" >Individual or Joint</a></li>
            <li><a href="/en/accounts/trust.php" target="_self" >Trust Accounts</a></li>
            <li><a href="/en/accounts/family-account.php" target="_self" >Family Accounts</a></li>
                            <li><a href="/en/accounts/isa-accounts.php" target="_self" >Individual Savings Account (ISA)</a></li>
                <li><a href="/en/accounts/individuals/sippAccount.php" target="_self" >Self-Invested Personal Pension (SIPP)</a></li>
                        </ul>
            <p class="submenu-title">FOR INSTITUTIONS</p>
            <ul>
                <li><a href="/en/accounts/institutions.php" target="_self" >Institutions Home</a></li>
                <li><p class="submenu-title text-primary fs-8 lh-8 fw-400">ADVISOR ACCOUNTS</p></li>
                <li><a href="/en/accounts/advisor/overview.php" target="_self" >Registered Investment Advisors</a></li>
                <li><a href="/en/accounts/family-office.php" target="_self" >Family Offices</a></li>
                <li><p class="submenu-title text-primary fs-8 lh-8 fw-400">INSTITUTIONAL ACCOUNTS</p></li>
                <li><a href="/en/accounts/proprietary-trading-group.php" target="_self" >Proprietary Trading Groups</a></li>
                <li><a href="/en/accounts/hedge-fund.php" target="_self" >Hedge Funds</a></li>
                <li><a href="/en/accounts/broker.php" target="_self" >Introducing Brokers</a></li>
                <li><a href="/en/accounts/small-business.php" target="_self" >Small Businesses</a></li>
                <li><a href="/en/accounts/fsa-insurance-providers.php" target="_self" >Full-Service Administrator <br>Insurance Providers</a></li>
                <li><a href="/en/accounts/money-manager.php" target="_self" >Money Managers</a></li>
                <li><p class="submenu-title text-primary fs-8 lh-8 fw-400">ADMINISTRATIVE ACCOUNTS</p></li>
                <li><a href="/en/accounts/compliance-officer.php" target="_self" >Compliance Officers</a></li>
                <li><a href="/en/accounts/administrator.php" target="_self" >Fund Administrators</a></li>
                 
                <li><p class="submenu-title text-primary fs-8 lh-8 fw-400">OTHER ACCOUNTS</p></li>
                <li><a href="https://interactivebrokers.eu/campus/stl/" target="_blank" >Educators</a></li>
                            </ul>
        </div>
    </li>
    <!-- PRICING -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-pricing">Pricing</a>
        <div class="submenu" id="submenu-pricing">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-pricing">Back</button></p>
            <p class="submenu-title">PRICING</p>
            <ul>
            <li><a href="/en/pricing/commissions-home.php" target="_self">Commissions</a></li>
            <li><a href="/en/trading/margin-rates.php" target="_self">Margin Rates</a></li>
            <li><a href="/en/accounts/fees/pricing-interest-rates.php" target="_self">Interest Rates</a></li>
            <li><a href="/en/pricing/short-sale-cost.php" target="_self">Short Sale Cost</a></li>
            <li><a href="/en/pricing/market-data-pricing.php" target="_self">Market Data Pricing</a></li>
            <li><a href="/en/pricing/stock-yield-enhancement-program.php" target="_self">Stock Yield Enhancement Program</a></li>
            <li><a href="/en/pricing/other-fees-overview.php" target="_self">Other Fees</a></li>
            </ul>
        </div>
    </li>
    <!-- TRADING -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-trading">Trading</a>
        <div class="submenu" id="submenu-trading">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-trading">Back</button></p>
            <p class="submenu-title">TRADING</p>
            <ul>
            <li><a href="/en/trading/trading-platforms.php" target="_self">Platforms</a></li>
            <li><a href="/en/trading/ib-api.php" target="_self">APIs</a></li>
            <li><a href="/en/trading/margin.php" target="_self">Margin</a></li>
            <li><a href="/en/trading/ai-integrations.php" target="_self" >AI Integration</a></li>
            <li><a href="/en/trading/products-exchanges.php" target="_self">Symbol and Exchange Search</a></li>
            <li><a href="/en/trading/products-stocks.php" target="_self">Products Overview</a></li>
            <li><a href="/en/pricing/research-news-services.php" target="_self">Research and News</a></li>
            <li><a href="/en/trading/clients-ibkr-ats.php?menu=A" target="_self" >IBKR ATS</a></li>
            <li><a href="/en/trading/ordertypes.php" target="_self">Order Types</a></li>
            <li><a href="/en/whyib/reporting.php" target="_self">Reporting</a></li>
            <li><a href="/en/trading/securities-financing.php" target="_self">Securities Financing</a></li>
            <li><a href="/en/trading/features-in-focus.php" target="_self">Features in Focus</a></li>
            <li><a href="/en/general/education/probability_lab.php" target="_self">Probability Lab</a></li>
            <li><a href="/en/trading/global-outsourced-trading-desk.php" target="_self">Global Outsourced Trading Desk</a></li>
            </ul>
        </div>
    </li>
    <!-- SERVICES -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-services">Services</a>
        <div class="submenu" id="submenu-services">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-services">Back</button></p>
            <p class="submenu-title">SERVICES</p>
            <ul>
            <li><a href="/en/trading/globalanalyst.php" target="_self">IBKR GlobalAnalyst</a></li>
            <li><a href="/en/portfolioanalyst/overview.php" target="_self" rel="noreferrer noopener">PortfolioAnalyst</a></li>
            <li><a href="/en/trading/products-bonds.php" target="_self">Bonds Marketplace</a></li>
            <li><a href="/en/trading/products-mutual-funds.php" target="_self">Mutual Funds Marketplace</a></li>
            <li><a href="/en/trading/commission-free-etfs-mkt.php" target="_self">No Transaction Fee ETFs</a></li>
            <li><a href="https://ndcdyn.interactivebrokers.com/aces/Marketplace/InvestorsMarketplace" target="_blank">Investors' Marketplace</a></li>
            <li><a href="/en/trading/short-securities-availability.php" target="_self">Short Securities Availability</a></li>
            <li><a href="/en/trading/third-party-integration.php" target="_self">Third Party Integration</a></li>
            <li><a href="/en/trading/sustainable-investing.php" target="_self">Sustainable Investing</a></li>
            </ul>
        </div>
    </li>
    <!-- EDUCATION -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-education">Education</a>
        <div class="submenu" id="submenu-education">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-education">Back</button></p>
            <p class="submenu-title">EDUCATION</p>
            <ul>
             
            <li><a href="https://interactivebrokers.eu/campus/" target="_blank">IBKR Campus</a></li>
            <li><a href="https://interactivebrokers.eu/campus/academy" target="_blank">Traders' Academy</a></li>
            <li><a href="https://interactivebrokers.eu/campus/news" target="_blank">Traders' Insight</a></li>
            <li><a href="https://interactivebrokers.eu/campus/category/podcasts/" target="_blank">IBKR Podcasts</a></li>
            <li><a href="https://interactivebrokers.eu/campus/quant" target="_blank">IBKR Quant Blog</a></li>
            <li><a href="https://interactivebrokers.eu/campus/webinars" target="_blank">Webinars</a></li>
            <li><a href="/en/trading/fif-ibkr-forum.php" target="_self">IBKR Forum</a></li>
            <li><a href="https://interactivebrokers.eu/campus/stl/" target="_blank">Student Trading Lab</a></li>
            <li><a href="https://interactivebrokers.eu/campus/glossary" target="_blank">Traders' Glossary</a></li>
                        <li><a href="/en/general/calendar/calendar.php" target="_self">Traders' Calendar</a></li>
            </ul>
        </div>
    </li>
    <!-- ABOUT US -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-about-us">About Us</a>
        <div class="submenu" id="submenu-about-us">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-about-us">Back</button></p>
            <p class="submenu-title">ABOUT US</p>
            <ul>
            <li><a href="/en/general/financial-strength.php" target="_self">Strength and Security</a></li>
            <li><a href="/en/general/about/info-and-history.php" target="_self">Information and History</a></li>
            <li><a href="/en/general/about/careers-splash.php" target="_self">Careers</a></li>
            <li><a href="/en/general/awards.php" target="_self">Awards</a></li>
            <li><a href="/en/about/news-at-ibkr.php" target="_self">News at IBKR</a></li>
            <li><a href="/en/general/about/press-and-media.php" target="_self">Press and Media</a></li>
            <li><a href="https://investors.interactivebrokers.com/ir/main.php" target="_blank" rel="noreferrer noopener">Investor Relations</a></li>
            <li><a href="/en/general/ibkr-on-social-media.php" target="_self">IBKR on Social Media</a></li>
            <li><a href="/en/general/about/sustainability.php" target="_self">Sustainability</a></li>
            <li><a href="/en/accounts/legalDocuments/brokerPerformanceReports.php" target="_self">Regulatory Reports</a></li>
            <li><a href="/en/accounts/referrer.php" target="_self">Refer a Friend</a></li>
            <li><a href="/en/general/about/affiliate-programs.php" target="_self">Affiliate Programs</a></li>
            </ul>
        </div>
    </li>
    <!-- SUPPORT -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-support">Support</a>
        <div class="submenu" id="submenu-support">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-support">Back</button></p>
            <p class="submenu-title">SUPPORT</p>
            <ul>
            <li><a href="/en/support/fund-my-account.php" target="_self">Fund Your Account</a></li>
            <li><a href="/en/support/individuals.php" target="_self">For Individuals</a></li>
            <li><a href="/en/support/institutions.php" target="_self">For Institutions</a></li>
            <li><a href="/en/support/institutional-sales-contacts.php?p=uk" target="_self">Institutional Sales Contacts</a></li>
                        <li><a href="/en/general/contact/ibot-container.php" target="_self">Browse our FAQs</a></li>
                        <li><a href="/en/support/reports-and-dates.php" target="_self">Tax Information</a></li>  
            </ul>
        </div>
    </li>
    <!-- LANGUAGE -->
    <li class="has-submenu"><a href="#" data-submenu="submenu-language">Language</a>
        <div class="submenu" id="submenu-language">
            <p class="nav-link-back"><button type="button" data-submenu-close="submenu-language">Back</button></p>
            <p class="submenu-title">LANGUAGE</p>
            <ul>
            <li><a href="/en/home.php" target="_self">English</a></li>
            <li><a href="/fr/home.php" target="_self">Français</a></li>
            <li><a href="/de/home.php" target="_self">Deutsch</a></li>
            <li><a href="/es/home.php" target="_self">Español</a></li>
            <li><a href="/it/home.php" target="_self">Italiano</a></li>
            <li><a href="/ru/home.php" target="_self">Pусский</a></li>
                        </ul>
        </div>
    </li>
    </ul>
</div>
<!-- MOBILE NAV OVERLAY -->
<div class="website-overlay d-lg-none"></div>
<!-- MOBILE NAV END ---------------------------------------------------------------------------------------------------- -->
<!-- MODAL START | GDPR COOKIES -->
<div class="modal modal-cookies fade" id="cookie-modal" tabindex="-1" role="dialog" aria-labelledby="modalCookieLabel">
	<div class="modal-dialog modal-dialog-centered modal-xl" role="document">
		<div class="modal-content">
			<div class="modal-header d-block">
				<p class="fs-5 modal-title" id="modalCookieLabel">Privacy Preference Center</p>
                <p class="pt-10 pr-30">This website uses cookies to offer a better browsing experience and to collect usage information. <br>By clicking on the "ACCEPT COOKIES" button you accept our Cookie Policy.</p>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-12 col-lg-4">
                        <p class="fs-4 modal-title text black" id="modalCookieLabel">Customize Privacy Settings</p>
						<ul role="tablist" class="nav flex-column" id="cookieTabs">
                            <li role="presentation" class="nav-item" name="tab1"><a class="nav-link" href="#tab-01" aria-controls="tab-01" role="tab" data-bs-toggle="tab">Your Privacy</a></li>
                            <li role="presentation" class="nav-item" name="tab2"><a id="temporary" class="nav-link" href="#tab-02" aria-controls="tab-02" role="tab" data-bs-toggle="tab">Strictly Necessary Cookies</a></li>
                            <li role="presentation" class="nav-item" name="tab3"><a class="nav-link" href="#tab-03" aria-controls="tab-03" role="tab" data-bs-toggle="tab">Performance Cookies</a></li>
                            <li role="presentation" class="nav-item" name="tab4"><a class="nav-link" href="#tab-04" aria-controls="tab-04" role="tab" data-bs-toggle="tab">Functional Cookies</a></li>
                            <li role="presentation" class="nav-item" name="tab5"><a class="nav-link" href="#tab-05" aria-controls="tab-05" role="tab" data-bs-toggle="tab">Marketing Cookies</a></li>
                            <li role="presentation" class="nav-item" name="tab6"><a class="nav-link" href="#tab-06" aria-controls="tab-06" role="tab" data-bs-toggle="tab">Cookie Policy</a></li>
						</ul>
		            </div>
					<div class="col-12 col-lg-8">
						<!-- TAB CONTENT START -->
						<div class="tab-content">
							<!-- TAB-01 -->
							<div role="tabpanel" id="tab-01" class="tab-pane active">
								<p><strong>Your Privacy</strong></p>
								<p>When you visit any website it may use cookies and web beacons to store or retrieve information on your browser. This information might be about you, your preferences or your device and is typically used to make the website work as expected. The information does not usually directly identify you, but can provide a personalized browsing experience. Because we respect your right to privacy, you can choose not to allow some types of cookies and web beacons. Please click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience on our website and limit the services we can offer.</p>
							</div>
							<!-- TAB 02 -->
							<div role="tabpanel" id="tab-02" class="tab-pane">
								<p><strong>Strictly Necessary Cookies</strong></p>
								<p>Strictly necessary cookies are necessary for the website to function and cannot be switched off in our systems. They are typically set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. While you can set your browser to block or alert you about these cookies, some parts of the website will not work. These cookies do not store any personally identifiable information.</p>
								<br>
								<p class="text-success text-small">Always Active</p>
							</div>
							<!-- TAB 03 -->
							<div role="tabpanel" id="tab-03" class="tab-pane">
								<p><strong>Performance Cookies and Web Beacons</strong></p>
								<p>Performance cookies and web beacons allow us to count visits and traffic sources so we can measure and improve website performance. They help us to know which pages are the most and least popular and see how visitors navigate around our website. All information these cookies and web beacons collect is aggregated and anonymous. If you do not allow these cookies and web beacons we will not know when you have visited our website and will not be able to monitor its performance.</p>
								<form>
								<fieldset>
								<p class="checkbox-label"><input type="checkbox" name="toggle-performance-cookies" data-on-color="success" data-off-color="default" data-on-text="Yes" data-off-text="No"checked="checked"><label id="act-perf">Active</label></p>
								</fieldset>
								</form>
							</div>
							<!-- TAB 04 -->
							<div role="tabpanel" id="tab-04" class="tab-pane">
								<p><strong>Functional Cookies</strong></p>
								<p>Functional cookies enable our website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.</p>
								<form>
								<fieldset>
								<p class="checkbox-label"><input type="checkbox" name="toggle-functional-cookies" data-on-color="success" data-off-color="default" data-on-text="Yes" data-off-text="No"checked="checked"><label id="act-func">Active</label></p>
								</fieldset>
								</form>
							</div>
							<!-- TAB 05 -->
							<div role="tabpanel" id="tab-05" class="tab-pane">
								<p><strong>Marketing Cookies and Web Beacons</strong></p>
								<p>Marketing Cookies and web beacons may be set through our website by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other websites. They do not directly store personal information, but uniquely identify your browser and internet device. If you do not allow these cookies and web beacons, you will experience less targeted advertising. Our website does not track users when they cross to third party websites, does not provide targeted advertising to them and therefore does not respond to "Do Not Track" signals.</p>
								<form>
								<fieldset>
								<p class="checkbox-label"><input type="checkbox" name="toggle-targeting-cookies" data-on-color="success" data-off-color="default" data-on-text="Yes" data-off-text="No"checked="checked"><label id="act-target">Active</label></p>
								</fieldset>
								</form>
							</div>
                            <!-- TAB COOKIE POLICY  -->
							<div role="tabpanel" id="tab-06" class="tab-pane tab-policy">
                                <h2>Interactive Brokers Group Cookie Policy</h2><br>
                                <p><strong>What are Cookies and Web Beacons?</strong></p>
                                    <p> Cookies are pieces of data that a website transfers to  a user's hard drive for record-keeping purposes. Web beacons are transparent  pixel images that are used in collecting information about website usage,  e-mail response and tracking. Generally,  cookies may contain information about your Internet Protocol ("IP") addresses, the region or general  location where your computer or device is accessing the internet, browser type,  operating system and other usage information about the website or your usage of  our services, including a history of the pages you view.</p>
                                <p><strong>How We Use Cookies and Web Beacons</strong></p>
                                    <p>Interactive Brokers Group collects information from cookies and web beacons and stores it in an internal database. This information is retained in accordance with our Privacy Policy. This website uses the following cookies and web beacons:</p>
                                    <p><strong>Strictly Necessary Cookies</strong></p>
                                    <p>These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can configure your browser to block or alert you about these cookies, but certain areas of the site will not function properly. These cookies do not store any personal data.</p>
                                    <p><strong>Performance Cookies and Web Beacons</strong></p>
                                    <p>These cookies and web beacons allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information that these cookies and web beacons collect is aggregated and, therefore, anonymous. If you do not allow these cookies and web beacons our aggregated statistics will not have a record of your visit.</p>
                                    <p>The website uses Google Analytics, a web analytics service provided by Google, Inc. ("Google"). Google Analytics  uses cookies to help  analyse how  you use this  website. The information generated by the cookie about your use of this website (including your IP address) will be transmitted to and stored by Google on servers in the United States. Google will use this information for the purposes of evaluating your use of the website, compiling reports on website activity for website operators and providing other services relating to website activity and internet usage. Google may also transfer this information to third parties where required to do so by law, or where such third parties process the information on Google's behalf. Google will not associate your IP address with any other data held by Google. </p>
                                    <p><strong>Functional Cookies</strong></p>
                                    <p>These cookies enable the website to provide enhanced functionality and personalization. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies, some or all of these services may not function properly.</p>
                                    <p><strong>Marketing Cookies and Web Beacons</strong></p>
                                <p>These cookies and web beacons may be set throughout our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant advertisements on other sites. They do not store personal information that could identify you directly, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies and web beacons, you will experience less targeted advertising. The website does not track users when they cross to third party websites, does not provide targeted advertising to them and therefore does not respond to Do Not Track ("DNT") signals.</p>
                                <p><strong>Managing Your Cookie Preferences</strong></p>
                                <p>You have many choices with regards to the management of cookies on your computer. All major browsers allow you to block or delete cookies from your system. However, if you do decide to disable cookies you may not be able to access some areas of our website or the website may function incorrectly. To learn more about your ability to manage cookies and web beacons and how   to   disable   them,   please   consult   the   privacy   features   in   your   browser   or visit <a href="http://www.allaboutcookies.org" target="_new" class="linkarrowexternal">www.allaboutcookies.org</a>. </p>
                                <p>This website may link through to third party websites which may also use cookies and web beacons over which we have no control. We recommend that you check the relevant third parties privacy policy for information about any cookies and web beacons that may be used.</p>
							</div>
						</div>
						<!-- TAB CONTENT END -->
					</div>
				</div>		
		    </div>
			<div class="modal-footer">
				<div class="row">
					<div class="col">
						<p>
                            <button type="button" class="btn btn-default" id="gdpr-customize-settings">Customize Settings</button>
                            <button type="button" class="btn btn-default" id="gdpr-save-settings">Save Custom Settings</button>
                                                        <a href="javascript:allowAllCookies();" class="btn btn-success" id="btn_accept_cookies"><i class="fas fa-check-circle"></i> Accept Cookies</a>
                        </p>
					</div>
				</div>
			</div>
		</div>
    </div>
</div>
<!-- MODAL END | GDPR COOKIES -->
<script type="text/javascript" src="/scripts/common/js/2015/bootstrap-switch.min.js"></script>
<script type="text/javascript">
 var statePerformanceCookie = true;
 var stateFunctionalCookie = true;
 var stateTargetingCookie = true;
         function setConsent(consent){
            const consentMode = {
                'functionality_storage': consent.necessary ? 'granted' : 'denied',
                'security_storage': consent.necessary ? 'granted' : 'denied',
                'ad_storage': consent.marketing ? 'granted' : 'denied',
                'analytics_storage': consent.analytics ? 'granted' : 'denied',
                'ad_personalization': consent.preferences ? 'granted' : 'denied',
                'ad_user_data': consent.marketing ? 'granted' : 'denied'
            };
            if (typeof gtag == 'function'){
                gtag('consent', 'update', consentMode);
            }
            localStorage.setItem('consentMode', JSON.stringify(consentMode));
        }
     
 $(function() {
    $('#act-perf').addClass('text-success');
      $('#act-func').addClass('text-success');
      $('#act-target').addClass('text-success');
    $('#btn_accept_cookies').on("click tap touch", function() {
   $('#cookie-header').slideUp();
  });
  $('#cookie-modal-close').on("click tap touch", function() {
   window.location.reload(true);
  });
  $('#btn_accept_cookies').on("click tap touch", function() {
   if(typeof document.fp === "function")
   {
    var fip = fp();
   } else {
    var fip = '';
   }
   $.ajax({
    url: '/response_handlers/cookies/index.php',
    accept: 'application/json',
    type: 'POST',
    dataType: 'json',
    data: {
     gdpr_update_cookies: 'true',
     t: '69b09198d4248b8f24494f27a01367b9',
     perf: true,
     func: true,
     targ: true,
     fp: fip
    },
    success: function(res)
    {
     if(res && !res['error'])
     {
      if(res['success'] && res['success'] == '1')
      {
       $('#cookie-modal').modal('hide');
       $('#cookie-header').slideUp();
      }
     }
     location.reload(true);
    },
    error: function(xhr, ajaxOpt, err){}
   });
      var ibdmn='interactivebrokers.co.in';(function(d,c){let s=d.createElement('script');s.src='https://www.interactivebrokers.co.in/mkt/ibgtag.js?wbst='+c;s.id='_ib_tag';s.async=true;d.getElementsByTagName('head')[0].appendChild(s);})(document,'IN');
     });
  // Show Modal Body and hide 'Customize Settings' button
  $('#gdpr-customize-settings').on("click tap touch", function() {
     $('#gdpr-save-settings').show();
     $('#gdpr-customize-settings').hide();
     $('.modal-cookies .modal-body').show();
      // Initialize first tab in modal window to display
      $('#cookieTabs li:first-child a').click();
  }); 
  $('#gdpr-save-settings').on("click tap touch", function() {
   if(typeof document.fp === "function")
   {
    var fip = fp();
   } else {
    var fip = '';
   }
      setConsent({
    necessary: true,
    analytics: statePerformanceCookie,
    preferences: stateFunctionalCookie,
    marketing: stateTargetingCookie
  });
     $.ajax({
    url: '/response_handlers/cookies/index.php',
    accept: 'application/json',
    type: 'POST',
    dataType: 'json',
    data: {
     gdpr_update_cookies: 'true',
     t: '69b09198d4248b8f24494f27a01367b9',
     perf: statePerformanceCookie,
     func: stateFunctionalCookie,
     targ: stateTargetingCookie,
     fp: fip
    },
    success: function(res)
    {
     if(res && !res['error'])
     {
      if(res['success'] && res['success'] == '1')
      {
       $('#cookie-modal').modal('hide');
       $('#cookie-header').slideUp();
      }
     }
     location.reload(true);
    },
    error: function(xhr, ajaxOpt, err){}
   });
      if(stateTargetingCookie == true)
   {
     var ibdmn='interactivebrokers.co.in';(function(d,c){let s=d.createElement('script');s.src='https://www.interactivebrokers.co.in/mkt/ibgtag.js?wbst='+c;s.id='_ib_tag';s.async=true;d.getElementsByTagName('head')[0].appendChild(s);})(document,'IN');
   } 
//commenting out the else part to remove the bug from UK website home page pop up for save custom settings.
//else {
//    $.ajax({
//     url: 'https://www.interactivebrokers.co.in/response_handlers/cookies/index.php',
//     accept: 'application/json',
//     type: 'POST',
//     dataType: 'json',
//     data: {
//      remove_ib_tag: 'true',
//      t: '69b09198d4248b8f24494f27a01367b9',
//     }, success: function(res) { location.reload(true); },
//     error: function(xhr, ajaxOpt, err){}
//    });
//   }
     });
  // BOOTSTRAP SWITCH initialize
  $("[name='toggle-performance-cookies']").bootstrapSwitch();
  $("[name='toggle-functional-cookies']").bootstrapSwitch();
  $("[name='toggle-targeting-cookies']").bootstrapSwitch();
 });
  $('#gdpr-reject-all').on("click tap touch", function() {
   if(typeof document.fp === "function")
   {
    var fip = fp();
   } else {
    var fip = '';
   }
      setConsent({
    necessary: false,
    analytics: false,
    preferences: false,
    marketing: false
   });
      $.ajax({
    url: '/response_handlers/cookies/index.php',
    accept: 'application/json',
    type: 'POST',
    dataType: 'json',
    data: {
     gdpr_update_cookies: 'true',
     t: '69b09198d4248b8f24494f27a01367b9',
     perf: false,
     func: false,
     targ: false,
     fp: fip
    },
    success: function(res)
    {
     if(res && !res['error'])
     {
      if(res['success'] && res['success'] == '1')
      {
       $('#cookie-modal').modal('hide');
       $('#cookie-header').slideUp();
       location.reload(true);
      } 
     } else {
       location.reload(true); 
     }
    },
    error: function(xhr, ajaxOpt, err)
    {
     location.reload(true);
    }
   });
  });
 // respond to on/off switch events
 $("input[name='toggle-performance-cookies']").on('switchChange.bootstrapSwitch', function (event, state) {
  statePerformanceCookie = state;
  if(state === true)
  {
   $('#act-perf').addClass('text-success');
  } else {
   $('#act-perf').removeClass('text-success');
  }
  $("input[name='toggle-performance-cookies']").attr( "checked", state );
 });
 $("input[name='toggle-functional-cookies']").on('switchChange.bootstrapSwitch', function (event, state) {
  stateFunctionalCookie = state;
  if(state === true)
  {
   $('#act-func').addClass('text-success');
  } else {
   $('#act-func').removeClass('text-success');
  }
  $("input[name='toggle-functional-cookies']").attr( "checked", state );
 });
 $("input[name='toggle-targeting-cookies']").on('switchChange.bootstrapSwitch', function (event, state) {
  stateTargetingCookie = state;
  if(state === true)
  {
   $('#act-target').addClass('text-success');
  } else {
   $('#act-target').removeClass('text-success');
  }
  $("input[name='toggle-targeting-cookies']").attr( "checked", state );
 });
 // initialize button state when tab is clicked
 $("[name='tab3']").on("click tap touch", function() {
	initPerformanceCookie();
 });
  $("[name='tab4']").on("click tap touch", function() {
	initFunctionalCookie();
 });
  $("[name='tab5']").on("click tap touch", function() {
	initTargetingCookie();
 });
 function initPerformanceCookie(){
	 // read current state of bootstrapSwtich and change if it doesn't match the saved cookie boolean
	if (statePerformanceCookie != $("[name='toggle-performance-cookies']").bootstrapSwitch('state')){
		$("[name='toggle-performance-cookies']").bootstrapSwitch().click();
		$("input[name='toggle-performance-cookies']").attr( "checked", statePerformanceCookie );
	}
 }
 function initFunctionalCookie(){
	 if (stateFunctionalCookie != $("[name='toggle-functional-cookies']").bootstrapSwitch('state')){
		$("[name='toggle-functional-cookies']").bootstrapSwitch().click();
   		$("input[name='toggle-functional-cookies']").attr( "checked", stateFunctionalCookie );
	}
 }
 function initTargetingCookie(){
	 if (stateTargetingCookie != $("[name='toggle-targeting-cookies']").bootstrapSwitch('state')){
		$("[name='toggle-targeting-cookies']").bootstrapSwitch().click();
   		$("input[name='toggle-targeting-cookies']").attr( "checked", stateTargetingCookie );
	}
 }
 function allowAllCookies(){
  // reset all Active on/off switches to on and update corresponding variables
  if ( !statePerformanceCookie ) {
   $("input[name='toggle-performance-cookies']").attr( "checked", true );
   $("[name='toggle-performance-cookies']").bootstrapSwitch().click();
   statePerformanceCookie = true;
  }
  if ( !stateFunctionalCookie ) {
   $("input[name='toggle-functional-cookies']").attr( "checked", true );
   $("[name='toggle-functional-cookies']").bootstrapSwitch().click();
   stateFunctionalCookie = true;
  }
  if ( !stateTargetingCookie ) {
   $("input[name='toggle-targeting-cookies']").attr( "checked", true );
   $("[name='toggle-targeting-cookies']").bootstrapSwitch().click();
   stateTargetingCookie = true;
  }
    setConsent({
    necessary: true,
    analytics: true,
    preferences: true,
    marketing: true
  });
    initPerformanceCookie();
  initFunctionalCookie();
  initTargetingCookie();
 }
   // Hide Modal Body and hide 'Save Custom Settings' button
  $('#gdpr-save-settings').hide();
  $('.modal-cookies .modal-body').hide();
</script><!-- CONTENTS START ---------------------------------------------------------------------------------------------------- -->
<div id="contents">
<!-- HOME HERO CAROUSEL ---------------------------------------------------------------------------------------------------- -->
    <!-- CAROUSEL ---------------------------------------------------------------------------------------------------- -->
	<style type="text/css">
		/* Page Title */
		section#page-title {display: none;}
		/* Banner Carousel Structure */
		@media (max-width:767.98px) {
			.hero-carousel {
				width: 100%;
				padding: 0;
			}
		}
		@media (min-width:768px) {
			.hero-carousel {
				background-color: #FFFFFF;
				margin: 0px;
				padding: 0px;
				position: relative;
				width: 100%;
				height: 550px;
				min-height: 450px !important;
				z-index: 1;
			}
		}
		@media (min-width:768px) and (min-height:1300px) {
			.hero-carousel {
				min-height: 800px !important;
			}
		}
		@media (min-width:1300px) and (min-height:1600px) {
			.hero-carousel {
				min-height: 1000px !important;
			}
		}
		@media (max-width:767.98px) {
			.hero-carousel .container {
				width: 100%;
				max-width: none;
			}
		}
		@media (min-width:768px) {
			.hero-carousel .carousel,
			.hero-carousel .carousel .carousel-inner,
			.hero-carousel .carousel .carousel-inner .carousel-item,
			.hero-carousel .carousel .carousel-inner .carousel-item .container {
				height: 100%  !important;
			}
			.hero-carousel .carousel .carousel-inner .carousel-item .container {
				padding-bottom: 75px !important;
				align-content: center  !important;
				display: flex  !important;
			}
			.hero-carousel .carousel .carousel-inner .carousel-item .container .row {
				width: 100%;
			}
		}
		@media (min-width:768px) and (max-width:1170px) {
			.hero-carousel .carousel .carousel-inner .carousel-item .container {
				width: 100%;
				max-width: none;
				padding-left: 30px;
				padding-right: 30px;
			}
		}
		/* Banner Carousel Items */
		@media (max-width:767.98px) {
			.hero-carousel .carousel-item {
				position: relative !important;
				display: block !important;
				float: none;
				margin-top: 5px !important;
				margin-right: auto !important;
				margin-left: auto !important;
				padding: 35px 20px;
				width: calc(100% - 10px);
			}
		}
		@media (min-width:768px) {
			.hero-carousel .carousel-item {
				position: absolute;
				display: none;
				top: 0;
				inset-inline-start: 0;
				opacity: 0;
				transform: translateX(40px);
				margin-right: 0;
				transition: -webkit-transform .6s cubic-bezier(0.25, 0.1, 0.25, 1), opacity .6s cubic-bezier(0.25, 0.1, 0.25, 1);
				transition: transform .6s cubic-bezier(0.25, 0.1, 0.25, 1), opacity .6s cubic-bezier(0.25, 0.1, 0.25, 1);
			}
			.hero-carousel .carousel-item-next,
			.hero-carousel .carousel-item-prev,
			.hero-carousel .carousel-item.active {
				display: block;
				opacity: 1;
				-webkit-transform: translateX(0%);
				transform: translateX(0%)
			}
			.hero-carousel .active.carousel-item-right,
			.hero-carousel .carousel-item-next:not(.carousel-item-left) {
				opacity: 0;
				-webkit-transform: translateX(40px);
				transform: translateX(40px)
			}
			.hero-carousel .active.carousel-item-left,
			.hero-carousel .carousel-item-prev:not(.carousel-item-right) {
				opacity: 0;
				-webkit-transform: translateX(-40px);
				transform: translateX(-40px)
			}
		}
		@media (min-width:768px) and (max-width:1199.98px){
			.hero-carousel .carousel-item {
				padding-top: 3rem;
			}
		}
		/* Banner Carousel Indicators */
		@media (min-width:768px) {
			.hero-carousel .carousel-indicators {
				position: absolute;
				bottom: 30px;
			}
			.hero-carousel .carousel-indicators li {
				background: #fff  !important;
				width: 50px !important;
				height: 6px !important;
				border-radius: 0 !important;
				box-shadow: 0px 2px 5px rgba(0,0,0,.2);
				margin: 0 5px;
				opacity: .5;
				border: none;
			}
			.hero-carousel .carousel-indicators li.active {
				opacity: 1;
			}
		}
		/* Banner Slide Content */
		.hero-carousel .hero-content .hero-eyebrow {
            font-size: .9753rem;
            font-weight: var(--fw-600);
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }
        .hero-carousel .hero-content .hero-eyebrow + .hero-headline {
            margin-top: .5rem;
        }
		.hero-carousel .hero-content .hero-headline {
			margin: 0;
			font-weight: 600;
			line-height: 1.2;
		}
		.hero-carousel .hero-content {
			width: 100%;
		}
		@media (max-width:767.98px) {
			.hero-carousel .hero-content .hero-headline {
				font-size: 1.875rem;
			}
		}
		@media (min-width:768px) {
			.hero-carousel .hero-content .hero-headline {
				font-size: 2.25rem;
			}
		}
		@media (min-height:900px) and (min-width:1200px) {
			.hero-carousel .hero-content .hero-headline {
				font-size: 2.5rem;
			}
		}
		.hero-carousel .hero-content .hero-subhead {
			margin: 0;
			font-size: 1rem;
			line-height: 1.4;
			font-weight: 400;
		}
        .hero-carousel .hero-headline + .hero-subhead,
        .hero-carousel .hero-headline + .hero-checklist,
        .hero-carousel .hero-subhead + .hero-text,
        .hero-carousel .hero-subhead + .hero-checklist {
            margin-top: 1rem;
		}
        .hero-carousel .hero-subhead + .hero-subhead {
            margin-top: .75rem;
        }
		.hero-carousel .hero-headline + .hero-cta,
		.hero-carousel .hero-subhead + .hero-cta,
        .hero-carousel .hero-checklist + .hero-cta{
			margin-top: 2.25rem;
		}
		.hero-carousel .hero-cta .btn{
			padding: 12px 30px;
			min-width: 180px;
		}
		@media (min-width:576px) {
			.hero-carousel .hero-cta a.btn + a.btn {
				margin: 0 0 0 8px;
			}
		}
		/* Hero Img Scaling Wrapper */
		.hero-img-scaling-wrapper {
			position:relative;
			width: 100%;
			display: block;
			margin-left: auto;
			margin-right: auto;
		}
		@media (min-width:992px) {
			.hero-carousel .hero-img-scaling-wrapper {
				height: 70%;
			}
		}
		@media (max-height:899.98px) and (min-width:1200px) {
			.hero-carousel .hero-img-scaling-wrapper {
				height: 90%;
			}
		}
		@media (min-height:900px) and (min-width:1200px) {
			.hero-carousel .hero-img-scaling-wrapper {
				height: 70%;
			}
		}
		@media (min-height:1000px) and (min-width:1200px) {
			.hero-carousel .hero-img-scaling-wrapper {
				height: 60%;
			}
		}
		@media (max-width:991.98px) {
			.hero-carousel .hero-img-scaling-wrapper img {
				position:relative;
			}
		}
		@media (min-width:992px) {
			.hero-carousel .hero-img-scaling-wrapper img{
				position:absolute;
				top: 0px;
				left: 0px;
				height: 100%;
				max-width: none;
			}
		}
        /* Helpers */
		.hero-carousel .carousel-disclosure{
			font-size: .8125rem;
			line-height: 1.2;
			margin-top:20px;
		}
		.hero-carousel .carousel-disclosure a,
		.hero-carousel .carousel-disclosure a:link,
		.hero-carousel .carousel-disclosure a:visited,
		.hero-carousel .carousel-disclosure a:hover,
		.hero-carousel .carousel-disclosure a:active,
		.hero-carousel .carousel-disclosure a:focus {
			text-decoration: underline;
			color: #222;
		}
		@media (min-width:992px) {
			.text-lg-start {
				text-align: start !important;
			}
		}
		@media (min-width:768px) {
			.text-md-white, .text-md-white a {
				color: #fff !important;
			}
		}
	</style>
    <section class="page-title" id="page-title">
        <div class="container">
            <div class="row">
                <div class="col"><h1>Interactive Brokers Home</h1></div>
            </div>
        </div>
    </section>
    <section class="hero-carousel" id="hero-carousel">
        <div id="carouselBannerAds" class="carousel slide" data-bs-ride="carousel" data-bs-pause="false" data-bs-interval="8000">
            <ol class="carousel-indicators d-none d-md-flex">
                              <li data-bs-target="#carouselBannerAds" data-bs-slide-to="0" class="active"></li>
                            <li data-bs-target="#carouselBannerAds" data-bs-slide-to="1" class=""></li>
                            <li data-bs-target="#carouselBannerAds" data-bs-slide-to="2" class=""></li>
                            <li data-bs-target="#carouselBannerAds" data-bs-slide-to="3" class=""></li>
                        </ol>
            <div class="carousel-inner">
                                    <div class="carousel-item carousel-overnight-trading active">
                        <style>
/* ============================================================== */
/* =============     Banner OVERNIGHT TRADING      ============== */
/* ============================================================== */
/* Hero img */        
@media (max-width:767.98px) {
    .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-mobile.jpg'); 
        background-repeat: no-repeat;
        background-size: 150%;
        background-position: top center;
        padding-top: calc(50% + 20px) !important;
    }
}
@media (min-width:768px) and (max-width:991.98px) {
    .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-tablet.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: 50% 60%;
    }
    [dir="rtl"] .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-tablet-rtl.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: 50% 60%;
    }
}
@media (min-width:768px) and (max-width:991.98px) and (max-height:699.98px){
    .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-tablet.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: 50% 50%;
    }
    [dir="rtl"] .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-tablet-rtl.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: 50% 50%;
    }
}
@media (min-width:992px) and (max-width:1199.98px) {
    .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-laptop.jpg?v1');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: right center;
    }
    [dir="rtl"] .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-laptop-rtl.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: left center;
    }
}
@media (max-height: 799.98px) and (min-width:1200px) {
    .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-desktop.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: right center;
    }
    [dir="rtl"] .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-desktop-rtl.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: left center;
    }
}
@media (min-height: 800px) and (min-width:1200px) {
    .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-desktop-hd.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: right center;
    }
    [dir="rtl"] .hero-carousel .carousel-overnight-trading {
        background: #0b1021 url('/images/web/hero-banner-home-overnight-trading-desktop-hd-rtl.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: left center;
    }
}		
.hero-carousel .carousel-overnight-trading .hero-headline,
.hero-carousel .carousel-overnight-trading .hero-subhead {
    color: #FFF;
}
.hero-carousel .carousel-interest a.btn.btn-primary {
    box-shadow: 0 3px 20px rgb(0, 0, 0, .1) !important;
}	
</style>

                <div class="container">
                    <div class="row align-items-xl-center">
                        <div class="col-12 col-lg-7 col-xl-6">		                        
                            <div class="hero-content">
				                                                        <h2 class="hero-headline">Trade US Stocks and ETFs, Index Futures and Options, and Bonds Around the Clock</h2>
                                    <p class="hero-subhead">React immediately to market-moving news and trade over 10,000 US stocks and ETFs, US equity index futures and options, US Treasuries, global corporate bonds, European government bonds and UK gilts when it’s convenient for you.</p>
				                                                    <div class="hero-cta">
                                    <a class="btn btn-primary" href="/en/trading/us-overnight-trading.php" target="_self">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    </div>
                                    <div class="carousel-item carousel-institutions-global ">
                        <style>
        /* ============================================================== */
        /* ==================        Banner institutions-uk        ================== */
        /* ============================================================== */
        .hero-carousel .carousel-institutions-global .hero-headline,
        .hero-carousel .carousel-institutions-global .hero-subhead {
            color: #000;
        }
        @media (max-width:768px) {
            .hero-carousel .carousel-institutions-global {
                min-height: 65vh;
            }
        }
        /* Hero img */		
        @media (max-width:991.98px) {
            .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-tablet.webp?v1');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: bottom center;
            }
        }
        @media (min-width:992px) and (max-width:1199.98px) {
            .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-laptop.webp');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: right center;
            }
            [dir="rtl"] .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-laptop-rtl.webp');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: left center;
            }
        }
        @media (max-height: 799.98px) and (min-width:1200px) {
            .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-desktop.webp');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: right center;
            }
            [dir="rtl"] .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-desktop-rtl.webp');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: left center;
            }
        }
        @media (min-height: 800px) and (min-width:1200px) {
            .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-desktop-hd.webp');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: right bottom;
            }
            [dir="rtl"] .hero-carousel .carousel-institutions-global {
                background: #b2d2eb url('/images/web/carousel/hero-banner-home-institutions-global-desktop-hd-rtl.webp');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: left bottom;
            }
        }
</style>            

                <div class="container">
                    <div class="row align-items-xl-center">
                        <div class="col-12 col-lg-5 col-xl-7 col-xxl-8">		                        
                            <div class="hero-content text-center text-lg-start">
                                    <h2 class="hero-headline">The Competitive Edge for Institutions</h2>
                                <p class="hero-subhead">Institutions gain a competitive edge with IBKR's financial strength, advanced technology, and execution quality, empowering hedge funds, advisors, broker-dealers, and small businesses to grow and scale globally.</p>
                                <div class="hero-cta mt-4">
                                    <a class="btn btn-primary" href="/en/accounts/institutions.php" target="_self">View Institutional Solutions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                                </div>
                                    <div class="carousel-item carousel-interest ">
                        <style>
    /* ============================================================== */
    /* ==================     Banner INTEREST      ================== */
    /* ============================================================== */
    /* Hero img */		
    @media (max-width:767.98px) {
        .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-mobile.jpg'); 
            background-repeat: no-repeat;
            background-size: 150%;
            background-position: top center;
            padding-top: calc(50% + 20px) !important;
        }
    }
    @media (min-width:768px) and (max-width:991.98px) {
        .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-tablet.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: bottom right;
        }
        [dir="rtl"] .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-tablet-rtl.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: bottom left;
        }
    }
    @media (min-width:992px) and (max-width:1199.98px) {
        .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-laptop.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: right center;
        }
        [dir="rtl"] .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-laptop-rtl.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: left center;
        }
    }
    @media (max-height: 799.98px) and (min-width:1200px) {
        .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-desktop.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: right center;
        }
        [dir="rtl"] .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-desktop-rtl.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: left center;
        }
    }
    @media (min-height: 800px) and (min-width:1200px) {
        .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-desktop-hd.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: right bottom;
        }
        [dir="rtl"] .hero-carousel .carousel-interest {
            background: #f0f0f0 url('/images/web/hero-banner-home-interest-desktop-hd-rtl.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: left bottom;
        }
    }		
    .hero-carousel .carousel-interest .hero-headline,
    .hero-carousel .carousel-interest .hero-subhead {
        color: #222;
    }
    .hero-carousel .carousel-interest a.btn.btn-primary {
        box-shadow: 0 3px 20px rgb(0, 0, 0, .1) !important;
    }	
</style>

                <div class="container">
                    <div class="row align-items-xl-center">
                        <div class="col-12 col-lg-7 col-xl-6">		                        
                            <div class="hero-content">
                                <h2 class="hero-headline">Interactive Brokers Clients Earn Up to USD 3.38% on Their Instantly Available Cash Balances<span class="disclosure-indicator" aria-details="d-rate-interest">*</span></h2>
                                <div class="hero-cta">
                                    <a class="btn btn-primary" href="/en/accounts/fees/pricing-interest-rates.php" target="_self">Learn More</a>
                                </div>
                                <p class="disclosure-item-inline carousel-disclosure">*Restrictions apply. For additional information on interest rates, <a href="/en/index.php?f=46788">click here</a>. <span class="d-none d-lg-inline"><br></span>Credit interest rate as of September 18, 2026.</p>
                            </div>
                        </div>
                    </div>
                </div>
                    </div>
                                    <div class="carousel-item carousel-ibkr-desktop ">
                            <style>
    /* ============================================================== */
    /* ==================   Banner IBKR DESKTOP    ================== */
    /* ============================================================== */
    .hero-carousel .carousel-ibkr-desktop {
        background: radial-gradient(49.37% 69.1% at 50% 0%, rgba(107, 158, 244, 0.50) 0%, rgba(107, 158, 244, 0.00) 100%), #15181E;
    }
    @media (min-width:992px) {
        .hero-carousel .carousel-ibkr-desktop {
            background: radial-gradient(54.88% 76.8% at 81% 0%, rgba(107, 158, 244, 0.50) 0%, rgba(107, 158, 244, 0.00) 100%), #15181E;
        }
    }
    @media (max-width:991.98px) {
        .carousel-ibkr-desktop {
            padding-top:50% !important;
        }
    }
    @media (max-width:991.98px) and (min-width:576px) {
        .carousel-ibkr-desktop {
            padding-top:40vh !important;
        }
    }
    .carousel-ibkr-desktop .hero-img-wrapper  {
        z-index: 1;
        overflow:visible;
    }
    @media (max-width:991.98px) {
        .carousel-ibkr-desktop .hero-img-wrapper {
            position:absolute;
            width: 100%;
            padding-top: 50%;
            height: 0;
            top: 0px;
            left:0px;
        }
    }
    @media (max-width:991.98px) and (min-width:576px) {
        .carousel-ibkr-desktop .hero-img-wrapper {
            padding-top: 40vh;
        }
    }
    @media (min-width:992px) {
        .carousel-ibkr-desktop .hero-img-wrapper {
            position: absolute;
            width: 50%;
            height: 100%;
            right: 0;
            top:0;
            bottom: 0;
        }
    }
    @media (min-width:1400px) {
        .carousel-ibkr-desktop .hero-img-wrapper {
            width: 40%;
        }
    }
    .carousel-ibkr-desktop .hero-img-wrapper img {
        object-fit: contain;
        object-position: center;
        position: absolute;
        top: 50%;
        left: 50%;
        translate: -50% -50%;
        border-radius: .5rem;
    }
    @media (max-width:991.98px) {
        .carousel-ibkr-desktop .hero-img-wrapper img {
            height: calc(100% - 4rem);
            width: calc(100% - 4rem);
        }
    }
    @media (max-width:991.98px) and (min-width: 576px) {
        .carousel-ibkr-desktop .hero-img-wrapper img {
            height: calc(100% - 12vh);
            width: calc(100% - 4rem);
        }
    }
    @media (min-width:992px)  {
        .carousel-ibkr-desktop .hero-img-wrapper img {
            height: calc(100% - 5rem);
            width: calc(100% - 5rem);
        }
    }
    @media (min-width:1200px)  {
        .carousel-ibkr-desktop .hero-img-wrapper img {
            height: auto;
            width: 85%;
            max-height: calc(100% - 5rem);
            max-width: calc(100% - 5rem);
        }
    }
    @media (min-width:1600px)  {
        .carousel-ibkr-desktop .hero-img-wrapper img {
            width: 75%;
        }
    }
    .hero-carousel .carousel-ibkr-desktop .hero-headline {
        color: #fff;
    }
    .hero-carousel .carousel-ibkr-desktop .hero-subhead {
        color: #b7b8ba;
    }
    </style>
    
                    <div class="hero-img-wrapper">
                    <picture>
                        <source media="(min-width:1200px)" srcset="/images/web/hero-banner-home-ibkr-desktop-update-xl.webp?v=691692ee9e2f209b9076f9f866394469 1200w, /images/web/hero-banner-home-ibkr-desktop-update-xl.png?v=691692ee9e2f209b9076f9f866394469 1200w">
                        <source media="(min-width:992px)" srcset="/images/web/hero-banner-home-ibkr-desktop-update-lg.webp?v=691692ee9e2f209b9076f9f866394469 1199w, /images/web/hero-banner-home-ibkr-desktop-update-lg.png?v=691692ee9e2f209b9076f9f866394469 1199w">
                        <source media="(min-width:768px)" srcset="/images/web/hero-banner-home-ibkr-desktop-update-md.webp?v=691692ee9e2f209b9076f9f866394469 991w, /images/web/hero-banner-home-ibkr-desktop-update-md.png?v=691692ee9e2f209b9076f9f866394469 991w">
                        <source media="(min-width:576px)" srcset="/images/web/hero-banner-home-ibkr-desktop-update-sm.webp?v=691692ee9e2f209b9076f9f866394469 767w, /images/web/hero-banner-home-ibkr-desktop-update-sm.png?v=691692ee9e2f209b9076f9f866394469 767w">
                        <source srcset="/images/web/hero-banner-home-ibkr-desktop-update.webp?v=691692ee9e2f209b9076f9f866394469  575w, /images/web/hero-banner-home-ibkr-desktop-update.png?v=691692ee9e2f209b9076f9f866394469 575w">
                        <img class="drop-shadow-xl" src="/images/web/hero-banner-home-ibkr-desktop-update.png?v=691692ee9e2f209b9076f9f866394469" alt="IBKR Desktop" width="2000" height="1104">
                    </picture>
                </div>
                <div class="container">
                    <div class="row align-items-lg-center">
                        <div class="col-12 col-lg-6">		                        
                            <div class="hero-content d-flex flex-column align-items-start align-items-sm-center align-items-lg-start text-sm-center text-lg-start">
                                <h2 class="hero-headline">Power Meets Simplicity</h2>
                                <p class="hero-subhead text-white"><strong>Experience the future of trading with IBKR Desktop.</strong></p> 
                                <p class="hero-subhead">Built from the ground up, it combines proven features with innovative tools in a streamlined, intuitive interface.</p>
                                <div class="hero-cta">
                                    <a class="btn btn-primary" href="/en/trading/ibkr-desktop.php" target="_self">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                        </div>
                            </div>
        </div>
    </section>	<!-- DROP LINKS ---------------------------------------------------------------------------------------------------- -->
	<section id="droplinks">
		<div class="container">
			<div class="row">
				<div class="col-12 col-lg-3">
					<div class="row align-items-center">
						<div class="col-12 col-sm-2 offset-sm-1 col-md-2 offset-md-2 col-lg-12 offset-lg-0"><!-- col-xl-3 offset-xl-0 -->
                            <a href="#sec-low-cost" target="_self" class="page-scroll">
							    <div><img src="/images/web/crd-low-cost.svg?v122123" alt="Low Cost"></div>
                            </a>
						</div>
						<div class="col-12 col-sm-8 col-md-7 col-lg-12" ><!--col-xl-9-->
                            <a href="#sec-low-cost" target="_self" class="page-scroll">
                                <h5 class="mt-15">Professional Pricing</h5>
                                <p>Low commissions, low margin rates, interest paid, and Stock Yield Enhancement.<sup class="disclosure-indicator" aria-details="d-rate-margin-lowest-3p">3</sup><sup>,</sup><sup class="disclosure-indicator" aria-details="d-rate-interest">4</sup></p> 
                            </a>
						</div>
					</div>
				</div>
				<div class="col-12 col-lg-3">
					<div class="row align-items-center">
						<div class="col-12 col-sm-2 offset-sm-1 col-md-2 offset-md-2 col-lg-12 offset-lg-0"><!-- col-xl-3 offset-xl-0 -->
                            <a href="#sec-global-access" target="_self" class="page-scroll">
							<div><img src="/images/web/crd-global-access.svg?v122123" alt="Global Access"></div>
                            </a>
						</div>
						<div class="col-12 col-sm-8 col-md-7 col-lg-12" ><!--col-xl-9-->
                            <a href="#sec-global-access" target="_self" class="page-scroll">
							<h5 class="mt-15">Global Access</h5>
							<p>Invest globally in stocks, options, futures, currencies, bonds and funds from a single unified platform.</p>
                            </a>
						</div>
					</div>
				</div>
				<div class="col-12 col-lg-3">
					<div class="row align-items-center">
						<div class="col-12 col-sm-2 offset-sm-1 col-md-2 offset-md-2 col-lg-12 offset-lg-0"><!-- col-xl-3 offset-xl-0 -->
                            <a href="#sec-technology" target="_self" class="page-scroll">
							<div><img src="/images/web/crd-technology.svg?v122123" alt="Premier Technology"></div>
                            </a>
						</div>
						<div class="col-12 col-sm-8 col-md-7 col-lg-12" ><!--col-xl-9-->
                            <a href="#sec-technology" target="_self" class="page-scroll">
							<h5 class="mt-15">Premier Technology</h5>
							<p>IBKR's powerful suite of technology helps you optimize your trading speed and efficiency and perform sophisticated portfolio analysis.</p>
                            </a>
						</div>
					</div>
				</div>
				<div class="col-12 col-lg-3">
					<div class="row align-items-center">
						<div class="col-12 col-sm-2 offset-sm-1 col-md-2 offset-md-2 col-lg-12 offset-lg-0"><!-- col-xl-3 offset-xl-0 -->
                            <a href="#sec-strength" target="_self" class="page-scroll">
							<div><img src="/images/web/crd-vault-icon.svg" alt="Strength and Security"></div>
                            </a>
						</div>
						<div class="col-12 col-sm-8 col-md-7 col-lg-12" ><!--col-xl-9-->
                            <a href="#sec-strength" target="_self" class="page-scroll">
							<h5 class="mt-15">Strength & Security</h5>
							<p>$22.3 billion in equity capital<span class="disclosure-indicator" aria-details="d-metrics-ibg-affiliates">7</span>, automated risk controls, all assets marked to market daily, rated "A- Outlook Stable" by Standard &  Poor's.<span class="disclosure-indicator" aria-details="d-metrics-ibkr-rating-3p">8</span></p>
                            </a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- AWARD SET ---------------------------------------------------------------------------------------------------- -->
	<!-- AWARD WINNING PLATFORM AND SERVICES -->
<style type="text/css">
    #award-winning {
        padding-top: 50px;
        padding-bottom: 20px;
    }

    #award-winning .awardset {
        margin: 20px;
    }
    #award-winning .award-attribute {
        text-align: center;
        font-size: 0.875rem;
    }
    #award-winning .award-headline {
        text-align: center;
        padding-bottom: 2rem;
    }
    .award-content {
        max-width: 200px;
        height: 100%;
        margin: auto;
    }
    /* Aspect Ratio */
    .award-img-aspect {
        width: 100%;
        padding-top: 100%;
        height: 0;
        position:relative;
    }
    /* Aspect Ratio Container */
    .award-img-aspect .award-img {
        position: absolute;
        height: 100% !important;
        width: 100% !important;
        top: 0;
        left: 0;
        display: flex;
    }
    .award-img-aspect .award-img img {
        padding: 0 !important;
        width: 100% !important;
        height: 100% !important;
        object-fit: contain;
        object-position: center;
        transform-origin: center;
    }
    #award-winning .btn-awards {
        text-align: center;
        margin: 20px;
    }
    /* MEDIA QUERY | EXTRA SMALL < 576px ---------------------------------------------------------------------------------------------------- */
    @media (max-width:575.98px) {
        #award-winning .award-attribute {
            text-align: center;
            font-size: 1rem;
        }
    }
    /* MEDIA QUERY | SMALL > 576px ---------------------------------------------------------------------------------------------------- */
    @media (min-width:576px) and (max-width:767.98px) {
        #award-winning .award-attribute {
            text-align: center;
            font-size: 1rem;
        }
    }
    /* MEDIA QUERY | MEDIUM > 768px ---------------------------------------------------------------------------------------------------- */
    @media (min-width:768px) and (max-width:991.98px) {
        #award-winning .awardset {
            margin: 0;
        }
        #award-winning .award-attribute {
            text-align: center;
            font-size: 1rem;
        }
    }
    /* MEDIA QUERY | LARGE > 992px ---------------------------------------------------------------------------------------------------- */
    @media (min-width:992px) {
#award-winning .awardset{
            margin-top: 0;
            margin-end: 25px;
            -webkit-margin-end: 25px;
            -moz-margin-end: 25px;
            margin-bottom: 0;
            margin-start: 0;
            -webkit-margin-start: 0;
            -moz-margin-start: 0;
        }
        #award-winning .awardset:last-child {
            margin:0;
        }
    }
</style>
<section id="award-winning">
	<div class="container">
        <div class="row justify-content-center">
			<div class="col-12 text-center">
								<h2 class="award-headline">Award Winning Platform & Services</h2>
							</div>
		</div>
                <div class="row justify-content-center align-items-stretch">
                        <div class="col-12 col-sm-5 col-md-3 col-lg-2 awardset order-1">
                <div class="award-content">
                    <div class="award-img-aspect">
                        <div class="award-img">
                            <img style="scale: .9;" class="award-sb" loading="lazy" src="/images/dam/awards/2026/awards-2026-stockbrokers-professionaltrading.svg" alt="StockBrokers.com 2026 rated #1 for Professional Trading" />
                        </div>
                    </div>
                    <p class="award-attribute"> #1 Professional Trading <span class="d-none d-md-inline"><br /></span>#1 International Trading </p>
                </div>
            </div>
            <div class="col-12 col-sm-5 col-md-3 col-lg-2 awardset order-2 order-lg-1">
                <div class="award-content">
                    <div class="award-img-aspect">
                        <div class="award-img">
                            <img style="scale: .9;" class="award-bz d-dark-none" loading="lazy" src="/images/dam/awards/INV_broker-advanced_vt-green.svg" alt="Nerdwallet Award">
                            <img style="scale: .9;" class="award-bz d-light-none" loading="lazy" src="/images/dam/awards/INV_broker-advanced_vt-white.svg" alt="Nerdwallet Award">
                        </div>
                    </div>
                    <p class="award-attribute"> Best Online Broker<span class="d-inline d-md-none">,</span> <span class="d-none d-md-inline"><br /></span> for Advanced Traders </p>    
                </div>
            </div>
            <div class="col-12 col-sm-5 col-md-3 col-lg-2 awardset order-0">
                <div class="award-content">
                    <div class="award-img-aspect">
                        <div class="award-img">
                            <img style="scale: .85;" class="award-bc d-light-none" loading="lazy" src="/images/dam/awards/best-online-broker-2026-badges-d.png" alt="BrokerChooser 2026 Award - Best Online Broker">
                            <img style="scale: .85;" class="award-bc d-dark-none" loading="lazy" src="/images/dam/awards/best-online-broker-2026-badges.png" alt="BrokerChooser 2026 Award - Best Online Broker">
                        </div>
                    </div>
                    <p class="award-attribute">Best Online Broker </p>
                </div>
            </div>
            <div class="col-12 col-sm-5 col-md-3 col-lg-2 awardset order-4">
                <div class="award-content">
                    <div class="award-img-aspect">
                        <div class="award-img">
                            <img style="scale: .85;" class="award-bc" loading="lazy" src="/images/dam/awards/award-2026-investing-in-the-web.png" alt="Investing in the Web 2026 Award - Best Global Broker Overall">
                        </div>
                    </div>
                    <p class="award-attribute">Best Global Broker Overall </p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-12 btn-awards"> 
                <a href="/en/general/awards.php" target="_self" class="btn btn-lg btn-secondary" hreflang="en-US">See All Awards</a> 
            </div>
        </div>
	</div>
</section>	<!-- LOW COST ---------------------------------------------------------------------------------------------------- -->
    <span class="id-drop"><span id="sec-low-cost"></span></span>
	<section id="low-cost">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-12 col-lg-5">
<picture>
	<source media="(min-width:1200px)" srcset="/images/web/home-low-cost-xl.webp?v=70dcd7aada594af2ea68e2c6120db810 1200w, /images/web/home-low-cost-xl.jpg?v=70dcd7aada594af2ea68e2c6120db810 1200w">
	<source media="(min-width:992px)" srcset="/images/web/home-low-cost-lg.webp?v=70dcd7aada594af2ea68e2c6120db810 1199w, /images/web/home-low-cost-lg.jpg?v=70dcd7aada594af2ea68e2c6120db810 1199w">
	<source media="(min-width:768px)" srcset="/images/web/home-low-cost-md.webp?v=70dcd7aada594af2ea68e2c6120db810 991w, /images/web/home-low-cost-md.jpg?v=70dcd7aada594af2ea68e2c6120db810 991w">
	<source media="(min-width:576px)" srcset="/images/web/home-low-cost-sm.webp?v=70dcd7aada594af2ea68e2c6120db810 767w, /images/web/home-low-cost-sm.jpg?v=70dcd7aada594af2ea68e2c6120db810 767w">
	<source srcset="/images/web/home-low-cost.webp?v=70dcd7aada594af2ea68e2c6120db810  575w, /images/web/home-low-cost.jpg?v=70dcd7aada594af2ea68e2c6120db810 575w">
						<img src="/images/web/home-low-cost.jpg?v=70dcd7aada594af2ea68e2c6120db810" alt="Low Cost" loading="lazy" width="1600" height="1200"/>
				</picture>
				</div>
				<div class="col-12 col-lg-6 offset-lg-1">
					<h2>Experience Professional Pricing</h2>
					<ul class="checklist">
						<li>Low commissions with no added spreads, ticket charges, platform fees, custody fees or account minimums.</li>
						<li>IBKR BestX<sup>SM</sup> is a powerful suite of advanced trading technologies designed to help clients achieve best execution and maximize price improvement while minimizing market impact.</li>
                        <li>Low margin rates, with rates as low as <a href="/en/trading/margin-rates.php" target="_self">USD 4.38%</a>.<sup class="disclosure-indicator" aria-details="d-rate-margin-lowest-3p">3</sup></li>
                        <li>Earn high interest rates of up to <a href="/en/accounts/fees/pricing-interest-rates.php" target="_self" >USD 3.38%</a> on instantly available cash.<sup class="disclosure-indicator" aria-details="d-rate-interest">4</sup></li>
						<li>Earn extra income on your lendable shares</li>
					</ul>
					<a href="/en/whyib/overview.php#section-low-cost" class="btn btn-home-outline" target="_self">Learn More About IBKR</a>
				</div>
			</div>
		</div>
	</section>
	<!-- GLOBAL ACCESS ------------------------------------------------------------------------------------------------------ -->
    <span class="id-drop"><span id="sec-global-access"></span></span>
	<!-- GLOBAL ACCESS ---------------------------------------------------------------------------------------------------- -->
<script type="text/javascript" src="/scripts/common/js/map-script.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="/css/ibkr/map.css">
<section id="global-access" class="mt-40">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 margin-bottom-20">
                <h2>Discover a World of Opportunities</h2>
                <br>
                <p>
                                With     IBKR’s Universal Account, clients can trade stocks, options, futures, currencies, bonds, and funds around the world from a single screen.<span class="disclosure-indicator" aria-details="d-accounts-universal-uk">**</span> 
 Fund your account in multiple currencies and trade assets denominated in multiple currencies. Access market data 24 hours a day and six days a week.</p>
                                
                <div class="totals">
                    <div class="row">
                        <div class="col">
                            <h2>170</h2>
                            <p class="text-small">Markets</p>
                        </div>
                        <div class="col">
                            <h2>40</h2>
                            <p class="text-small">Countries</p>
                        </div>
                        <div class="col">
                                                        <h2>29</h2>
                            <p class="text-small">Currencies<span class="disclosure-indicator" aria-details="d-metrics-ibkr-currencies">*</span></p>
                                                    </div>
                    </div>
                </div>
                <br>
                <a href="/en/whyib/global_access.php" class="btn btn-lg btn-outline btn-tertiary mb-4" target="_self">Global Markets</a>
                <p class="disclosure-item-inline text-sm">Available currencies vary by Interactive Brokers affiliate.</p>
                <p class="text-sm">Graphic is for illustrative purposes only and should not be relied upon for investment decisions.</p>
            </div>
            <div class="col-12 col-lg-8 map-wrapper">
                <!-- MAP OF EXCHANGES BEGIN ----------------------------------------------------------------------------------------------------  -->
                <div id="places-map">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="exch-map "><!--animate-fade-in-->
                                    <img class="lazy" data-src="/images/web/map-solo-2245664933.png" alt="Map Locations"  /> <!-- width="800" height="452" -->
                                    <div class="map-pins"> 
										<span class="map-location-marker-closed marker-nyse tooltip" data-map-title="NYSE" data-map-subtitle="New York Stock Exchange" data-map-hours="Mon - Fri: 9:30 - 16:00 EST" data-map-hours2=""  data-map-link="0"></span> 
                                        <span class="map-location-marker-closed marker-cboe tooltip" data-map-title="Cboe" data-map-subtitle="Chicago Board Options Exchange" data-map-hours="Mon - Fri: 8:30 - 15:15 EST" data-map-hours2=""  data-map-link="0"></span> 
                                        <span class="map-location-marker-closed marker-tsx tooltip" data-map-title="TSX" data-map-subtitle="Toronto Stock Exchange" data-map-hours="Mon - Fri: 9:30 - 16:00 EST" data-map-hours2=""  data-map-link="0"></span> 
                                        <span class="map-location-marker-closed marker-bmv tooltip" data-map-title="BMV" data-map-subtitle="Bolsa Mexicana de Valores" data-map-hours="Mon - Fri: 8:30 - 15:00 CST" data-map-hours2=""  data-map-link="0"></span> 
										<span class="map-location-marker-closed marker-lse tooltip" data-map-title="LSE" data-map-subtitle="London Stock Exchange" data-map-hours="Mon - Fri: 8:00 - 16:50 GMT" data-map-hours2=""  data-map-link="90"></span> 
                                        <span class="map-location-marker-closed marker-xmad tooltip" data-map-title="XMAD" data-map-subtitle="Bolsa de Madrid" data-map-hours="Mon - Fri: 9:00 - 17:35 CET" data-map-hours2=""  data-map-link="90"></span> 
                                        <span class="map-location-marker-closed marker-fra tooltip" data-map-title="FRA" data-map-subtitle="Frankfurt Stock Exchange" data-map-hours="Mon - Fri: 8:00 - 20:00 CET" data-map-hours2=""  data-map-link="90"></span> 
                                        <span class="map-location-marker-closed marker-six tooltip" data-map-title="SIX" data-map-subtitle="Swiss Exchange" data-map-hours="Mon - Fri: 9:00 - 17:32 CET" data-map-hours2=""  data-map-link="90"></span> 
                                        <span class="map-location-marker-closed marker-bse tooltip" data-map-title="BSE" data-map-subtitle="Budapest Stock Exchange" data-map-hours="Mon - Fri: 9:00 - 17:20 CET" data-map-hours2=""  data-map-link="90"></span> 
										<span class="map-location-marker-closed marker-adx tooltip" data-map-title="ADX" data-map-subtitle="Abu Dhabi Securities Exchange" data-map-hours="Mon - Fri 10:00 - 14:45 GST"  data-map-hours2=""   data-map-link="90"></span> 
										<span class="map-location-marker-closed marker-tadawul tooltip" data-map-title="Tadawul" data-map-subtitle="Saudi Exchange" data-map-hours="Sun - Thu 10:00 - 15:20 AST"  data-map-hours2=""   data-map-link="90"></span> 
										<span class="map-location-marker-closed marker-b3 tooltip" data-map-title="B3" data-map-subtitle="Brazil Stock Exchange" data-map-hours="Mon - Fri 10:00 - 16:55 BRT"  data-map-hours2=""   data-map-link="90"></span> 
										<span class="map-location-marker-closed marker-tase tooltip" data-map-title="TASE" data-map-subtitle="Tel Aviv Stock Exchange" data-map-hours="Sun 9:30 - 16:25 IST"  data-map-hours2="Mon - Thu 9:30 - 17:15 IST"   data-map-link="90"></span> 
										<span class="map-location-marker-closed marker-nse tooltip" data-map-title="NSE" data-map-subtitle="National Stock Exchange of India" data-map-hours="Mon - Fri: 9:15-15:30 IST" data-map-hours2=""  data-map-link="190"></span> 
                                        <span class="map-location-marker-closed marker-sgx tooltip" data-map-title="SGX" data-map-subtitle="Singapore Stock Exchange" data-map-hours="Mon - Fri: 9:00 - 17:00 SGT" data-map-hours2=""  data-map-link="190"></span> 
                                        <span class="map-location-marker-closed marker-ksc tooltip" data-map-title="KSC" data-map-subtitle="Korea Stock Exchange" data-map-hours="Mon - Fri: 9:00 - 15:45 KST" data-map-hours2=""  data-map-link="190"></span> 
                                        <span class="map-location-marker-closed marker-tse tooltip" data-map-title="TSE" data-map-subtitle="Tokyo Stock Exchange" data-map-hours="Mon - Fri: 9:00 - 11:30 and 12:30 - 15:00 JST" data-map-hours2="(Lunch break 11:30 - 12:30 JST)"  data-map-link="190"></span> 
                                        <span class="map-location-marker-closed marker-asx tooltip" data-map-title="ASX" data-map-subtitle="Australia Stock Exchange" data-map-hours="Mon - Fri: 10:00 - 16:00 AEDT" data-map-hours2=""  data-map-link="190"></span> 
                                        <span class="map-location-marker-closed marker-hkse tooltip" data-map-title="HKSE" data-map-subtitle="Hong Kong Stock Exchange" data-map-hours="Mon - Fri: 9:30 - 12:00 and 13:00 - 16:00 HKT" data-map-hours2="(Lunch break 12:00 - 13:00 HKT)"  data-map-link="190"></span> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-20">
                            <div class="col">
                                <div class="map-message mt-20">
                                    <span id="local-time">Local Time:</span>
                                    <span id="open-label">Open</span>
                                    <span id="closed-label">Closed</span>
                                    <p class="openCloseMessage">mssage123</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- MAP OF EXCHANGES END ----------------------------------------------------------------------------------------------------  -->
            </div>
        </div> 
                <div class="row disclosure-item-inline">
            <div class="col">
                <p class="text-small text-gray"><span class="disclosure-item-inline" id="d-accounts-universal-uk">** </span>Regulations require securities and commodities activities to be conducted in separate accounts.  Universal Account refers to the consolidation of these accounts for display purposes only, enabling clients the ability to use a single platform to conduct trading activity and view consolidated activity and position information for all products and services offered. 
 </p>
            </div>
        </div>
            </div>
</section>	<!-- PREMIER TECHNOLOGY ------------------------------------------------------------------------------------------------- -->
    <span class="id-drop"><span id="sec-technology"></span></span>
	<span class="drop-link"><span id="trading-technology"></span></span>
<section id="trading-technology-section">
  <div class="container">
			<div class="row justify-content-center">
                <div class="col-12 col-md-10 col-lg-9">
					<figure>
						<picture>	
							<source media="(min-width:1200px)"  type="image/webp" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-xl.webp 1200w">	
							<source media="(min-width:1200px)"  type="image/png" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-xl.png 1200w">	
							<source media="(min-width:992px)"  type="image/webp" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-lg.webp 1199w">	
							<source media="(min-width:992px)"  type="image/png" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-lg.png 1199w">	
							<source media="(min-width:768px)"  type="image/webp" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-md.webp 991w">	
							<source media="(min-width:768px)"  type="image/png" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-md.png 991w">	
							<source media="(min-width:576px)"  type="image/webp" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-sm.webp 767w">	
							<source media="(min-width:576px)"  type="image/png" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-sm.png 767w">	
							<source type="image/webp" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-xs.webp 575w">	
							<source type="image/png" srcset="/images/dam/device-interface/ibkr-destop-laptop-device-xs.png 575w">	
							<img class="drop-shadow-xl" src="/images/dam/device-interface/ibkr-destop-laptop-device.png" border="0" width='2016' height='1158' alt='IBKR Desktop Laptop Device' loading="lazy" />
						</picture>	
					</figure>
                </div>
	  		</div>
	  		<div class="row justify-content-center">
				<div class="col-12 col-lg-11">
					<h2 class="text-center">Powerful Trading Platforms To Help You Succeed</h2>
				</div>	  			
	  		</div>
	  		<div class="row justify-content-center mt-20">
				<div class="col-12 col-lg-5">	  
                    <div class="mb-20">
                        <p>Award winning platforms for every investor from beginner to advanced on mobile, web and desktop.</p>
                        <p class="fw-600"><a href="/en/trading/trading-platforms.php" target="_self" class="link-chevron-circle-right">Trading Platforms</a></p>
                    </div> 
				    <div class="mb-20">
                                                <p>Discover new investment opportunities with over 200 free and premium research, market commentary and news providers.</p>
                        <p class="fw-600"><a href="/en/pricing/free-research-news-services.php" target="_self" class="link-chevron-circle-right"> Research, Market Commentary and News</a> </p>
                                            </div>
				    <div class="mb-20">
                        <p>Spot market opportunities, analyze results, manage your account and make better decisions with our free trading tools.</p>
                        <p class="fw-600"><a href="/en/trading/features-in-focus.php" target="_self" class="link-chevron-circle-right">Free Trading Tools</a></p>
                    </div>
				</div>
				<div class="col-12 col-lg-5 offset-lg-1">
				    <div class="mb-20">
                        <p>100+ order types - from limit orders to complex algorithmic trading - help you execute any trading strategy.</p>
                        <p class="fw-600"><a href="/en/trading/ordertypes.php" target="_self" class="link-chevron-circle-right">Order Types and Algos</a></p>
                    </div>
				    <div class="mb-20">
                                                    <p>Real-time trade confirmations, margin details, transaction cost analysis, sophisticated portfolio analysis and more.</p>
                                                <p class="fw-600"><a href="/en/whyib/reporting.php" target="_self" class="link-chevron-circle-right">Comprehensive Reporting</a></p>
                    </div>
				</div>
			</div>
		</div>
</section><!-- THIRD PARTY PROFESSIONAL QUOTE SECTION ------------------------------------------------------------------------------------------------>
<style type="text/css">
/*MOBILE/DEFAULTS*/
	section.third-party-quote-block {
		padding: 0;
	}
	section.third-party-quote-block	a.third-party-attr-link {
		width: fit-content;
	}
	section.third-party-quote-block svg {
		max-width: 32px;
		height: auto;
	}	
	section.third-party-quote-block .quote-block-area {
		padding: 30px 40px 30px 40px;
	}
	section.third-party-quote-block h2.third-party-quote-text {
		font-size: var(--fs-5);
		line-height: var(--lh-5);
	}
	section.third-party-quote-block h3.third-party-quote-attribution {
		font-size: var(--fs-6);
		line-height: var(--lh-6);
		/*text-decoration: underline;*/
	}	
	section.third-party-quote-block h3.third-party-quote-attribution span.third-party-quote-date {
		font-size: var(--fs-8);
		line-height: var(--lh-8);
		/* text-decoration: underline; */
	}		
/*DARK v LITE COLOR MGMT*/
	@layer bootstrap {
/*		DARK THEME COLOR RULES*/
        section.third-party-quote-block.quotes-dark-mode svg {
            fill: rgba(255,255,255,.9);
        }
        
		section.third-party-quote-block.quotes-dark-mode .third-party-quote-text,
		section.third-party-quote-block.quotes-dark-mode .third-party-quote-attribution, 
        section.third-party-quote-block.quotes-dark-mode .third-party-attr-link {
			color: rgba(255,255,255,.9);
		}
		section.third-party-quote-block.quotes-dark-mode .quote-block-area {
			background: 
				radial-gradient(180.62% 113% at 0.96% 2.23%, rgba(88, 155, 255, 0.10) 0%, rgba(88, 155, 255, 0.02) 100%), 
				linear-gradient(0deg, rgba(21, 24, 30, 0.40) 0%, rgba(21, 24, 30, 0.40) 100%), 
				radial-gradient(34.55% 74.25% at 72.71% 84.13%, rgba(21, 24, 30, 0.00) 0%, #15181E 100%);
		}
/*		LIGHT MODE COLOR RULES*/
        section.third-party-quote-block.quotes-light-mode svg {
            fill: var(--dark-90);
        }
		section.third-party-quote-block.quotes-light-mode .quote-block-area {
			background-color: var(--gray-5);
		}		
		section.third-party-quote-block.quotes-light-mode .third-party-quote-text,
		section.third-party-quote-block.quotes-light-mode .third-party-quote-attribution, 
        section.third-party-quote-block.quotes-light-mode .third-party-attr-link {
			color: var(--dark-90);
		}
	}
/*DESKTOPS*/
@media (min-width: 768px){
	section.third-party-quote-block {
	}
	section.third-party-quote-block .quote-block-area {
		padding: 40px 50px 40px 50px;
	}	
	section.third-party-quote-block h2.third-party-quote-text {
		font-size: var(--fs-4);
		line-height: var(--lh-4);
	}
	section.third-party-quote-block h3.third-party-quote-attribution {
		/*font-size: var(--fs-5);
		line-height: var(--lh-5);*/
        font-size: var(--fs-7);
		line-height: var(--lh-7);
	}		
	section.third-party-quote-block h3.third-party-quote-attribution span.third-party-quote-date {
		font-size: var(--fs-7);
		line-height: var(--lh-7);
		/* text-decoration: underline; */
	}			
}	
/*XL DESKTOPS*/
@media (min-width: 1200px){
	section.third-party-quote-block .quote-block-area {
		padding: 40px 50px 40px 50px;
	}	
}	
</style>
<section class="third-party-quote-block mt-10 mb-20 quotes-light-mode " >
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-11 col-md-10 col-lg-9 col-xl-8 text-center align-self-center quote-block-area">
				<svg width="39" height="32" viewBox="0 0 39 32" role="img" aria-labelledby="desc2" xmlns="http://www.w3.org/2000/svg">
					<desc id="desc2">Quote mark</desc>
					<path d="M9.56129 32C7.71613 32 6.20645 31.619 5.03226 30.8571C3.85806 30.0952 2.89355 29.1217 2.13871 27.9365C1.3 26.4974 0.712904 25.0159 0.37742 23.4921C0.125807 21.8836 0 20.5714 0 19.5556C0 15.4074 1.04839 11.6402 3.14516 8.25398C5.24194 4.86773 8.5129 2.1164 12.9581 0L14.0903 2.28571C11.4903 3.38624 9.22581 5.1217 7.29678 7.49207C5.45161 9.86244 4.52903 12.2751 4.52903 14.7302C4.52903 15.746 4.65484 16.6349 4.90645 17.3968C6.24839 16.2963 7.8 15.746 9.56129 15.746C11.7419 15.746 13.629 16.4656 15.2226 17.9048C16.8161 19.3439 17.6129 21.3333 17.6129 23.873C17.6129 26.2434 16.8161 28.1905 15.2226 29.7143C13.629 31.2381 11.7419 32 9.56129 32ZM30.9484 32C29.1032 32 27.5935 31.619 26.4194 30.8571C25.2452 30.0952 24.2806 29.1217 23.5258 27.9365C22.6871 26.4974 22.1 25.0159 21.7645 23.4921C21.5129 21.8836 21.3871 20.5714 21.3871 19.5556C21.3871 15.4074 22.4355 11.6402 24.5323 8.25398C26.629 4.86773 29.9 2.1164 34.3452 0L35.4774 2.28571C32.8774 3.38624 30.6129 5.1217 28.6839 7.49207C26.8387 9.86244 25.9161 12.2751 25.9161 14.7302C25.9161 15.746 26.0419 16.6349 26.2936 17.3968C27.6355 16.2963 29.1871 15.746 30.9484 15.746C33.129 15.746 35.0161 16.4656 36.6097 17.9048C38.2032 19.3439 39 21.3333 39 23.873C39 26.2434 38.2032 28.1905 36.6097 29.7143C35.0161 31.2381 33.129 32 30.9484 32Z" />
				</svg>
                 <h2 class="third-party-quote-text text-italic fw-300 mt-20" cite="https://brokerchooser.com/broker-reviews/interactive-brokers-review">
                    "In all, IBKR tops our list of brokerages: it is the highest-rated broker at BrokerChooser."                </h2>
                <div class="row justify-content-center">
                    <div class="col-12 d-flex justify-content-center">
                        <a class="third-party-attr-link" target="_blank" href="https://brokerchooser.com/broker-reviews/interactive-brokers-review"
                        target="_blank"
                        rel="noreferrer nofollow">
						<div class="d-flex align-items-center justify-content-center">
                            <h3 class="third-party-quote-attribution fw-400 mt-2">
								- BrokerChooser</span> |   
                                <span class="third-party-quote-date">April 7, 2026</span>
                                <i class="fa-solid fa-arrow-up-right-from-square fs-8 lh-8 ps-10 pe-10"></i>
                            </h3>
						</div>
						                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>	<!-- BROKER SECURITY ---------------------------------------------------------------------------------------------------- -->
    <span class="id-drop"><span id="sec-strength"></span></span>
    <!-- BROKER SECURITY ---------------------------------------------------------------------------------------------------- -->
<span class="id-drop"><span id="broker-security"></span></span>
<section id="broker-security">
<div class="container">
    <div class="row align-items-center">
        <div class="col-12 col-lg-6 margin-bottom-20">
            <h2>A Broker You Can Trust</h2>
            <p>When placing your money with a broker, you need to make sure your broker is secure and can endure through good and bad times in the broader financial markets. Our strong capital position, conservative balance sheet and automated risk controls are designed to protect IBKR from major market events that can threaten the stability of financial institutions.</p>
            <div class="totals">
                <div class="row">
                    <div class="col-6 col-sm-4">
                        <p class="mt-20 mb-0">Member of the</p>
                        <p class="fs-2 fw-300 my-0">S&amp;P 500</p>
                        <p>Nasdaq Listed: IBKR </p>
                    </div>
                    <div class="col-6 col-sm-4">
                        <p class="mt-20 mb-0">&nbsp;</p>
                        <p class="fs-2 fw-300 my-0">$22.3B</p>
                        <p class="text-small">Equity Capital<span class="disclosure-indicator" aria-details="d-metrics-ibg-affiliates">*</span></p>
                    </div>
                    <div class="col-6 col-sm-4">
                        <p class="mt-20 mb-0">&nbsp;</p>
                        <p class="fs-2 fw-300 my-0">73.5%</p>
                        <p class="text-small">Privately Held<span class="disclosure-indicator" aria-details="d-metrics-ibg-affiliates">*</span></p>
                    </div>
                    <div class="col-6 col-sm-4">
                        <p class="mt-20 mb-0">&nbsp;</p>
                        <p class="fs-2 fw-300 my-0">$13.9B</p>
                        <p class="text-small">Excess Regulatory Capital<span class="disclosure-indicator" aria-details="d-metrics-ibg-affiliates">*</span></p>
                    </div>
                    <div class="col-6 col-sm-4">
                        <p class="mt-20 mb-0">&nbsp;</p>
                        <p class="fs-2 fw-300 my-0">5.19M</p>
                        <p class="text-small">Client Accounts<span class="disclosure-indicator" aria-details="d-metrics-ibg-affiliates">*</span></p>
                    </div>
                    <div class="col-6 col-sm-4">
                        <p class="mt-20 mb-0">&nbsp;</p>
                        <p class="fs-2 fw-300 my-0">4.82M</p>
                        <p class="text-small">Daily Avg Revenue Trades<span class="disclosure-indicator" aria-details="d-metrics-ibg-affiliates">*</span></p>
                    </div>
                </div>
            </div>
            <br>
<a href="/en/general/financial-strength.php" class="btn btn-lg btn-secondary" target="_self">IBKR Protection</a>
        </div>
        <div class="col-12 col-lg-5 offset-lg-1">
<picture>
	<source media="(min-width:1200px)" srcset="/images/web/home-security-xl.webp?v=16bc5109771a1fe5f202675551139124 1200w, /images/web/home-security-xl.jpg?v=16bc5109771a1fe5f202675551139124 1200w">
	<source media="(min-width:992px)" srcset="/images/web/home-security-lg.webp?v=16bc5109771a1fe5f202675551139124 1199w, /images/web/home-security-lg.jpg?v=16bc5109771a1fe5f202675551139124 1199w">
	<source media="(min-width:768px)" srcset="/images/web/home-security-md.webp?v=16bc5109771a1fe5f202675551139124 991w, /images/web/home-security-md.jpg?v=16bc5109771a1fe5f202675551139124 991w">
	<source media="(min-width:576px)" srcset="/images/web/home-security-sm.webp?v=16bc5109771a1fe5f202675551139124 767w, /images/web/home-security-sm.jpg?v=16bc5109771a1fe5f202675551139124 767w">
	<source srcset="/images/web/home-security.webp?v=16bc5109771a1fe5f202675551139124  575w, /images/web/home-security.jpg?v=16bc5109771a1fe5f202675551139124 575w">
	                    <img loading="lazy" src="/images/web/home-security.jpg?v=16bc5109771a1fe5f202675551139124" alt="Secure metal vault door" width="1600" height="1067"/>

                </picture>
        </div>
    </div>
        <p class="disclosure-item-inline text-sm text-dark-gray pl-3 mt-3">Interactive Brokers Group and its affiliates. For additional information view our <a href="https://investors.interactivebrokers.com/ir/main.php" target="_blank" rel="noopener">Investor Relations - Earnings Release</a> section. The number of client accounts displayed includes all account types across all IBG affiliates as of June 2, 2026.</p>
</div>
</section>	<!-- ACCOUNT TYPES and THREE STEPS ---------------------------------------------------------------------------------- -->
	<style type="text/css">
/* ACCOUNT TYPES ---------------------------------------------------------------------------------------------------- */
#account-types h2 {
	text-align:center;
	margin-top: 20px;
	margin-bottom: 5px;
	font-weight:300;
}
#account-types p {
    font-size:0.875rem;
    text-align:center;
}
#account-types p a, #account-types p a:link, #account-types p a:visited, #account-types p a:hover, #account-types p a:active, #account-types p a:focus {
    color:var(--dark-70);
    text-decoration:none;
}
#account-types p a:hover {
    color:var(--primary);
}
#account-types p a img {
    height:60px;
    display:block;
    margin:20px auto;
}
#account-types div.inst-btn {
	border-left:1px solid var(--border-color);
}
[dir="rtl"] #account-types div.inst-btn {
	border-left:none;
	border-right:1px solid var(--border-color);

}
/* THREE STEPS ---------------------------------------------------------------------------------------------------- */
#three-steps.lazy {
    background-image:none;
    background-color:#0c2247;
}
#three-steps {
    background-image:url("/images/web/candlestick-bkgd.jpg");
    background-size:cover;
    background-position:50%;
    min-height:330px;
}
#three-steps h3, #three-steps h4, #three-steps h5, #three-steps p {
    color:var(--white);
    text-align:center;
    font-weight:300;
}
#three-steps h5 {
    font-weight:600;
    text-transform:uppercase;
}
</style>
    <!-- ACCOUNT TYPES ---------------------------------------------------------------------------------------------------- -->
    <section id="account-types">
        <div class="container">
            <div class="row padding-bottom-10">
                <div class="col">
                    <h2 class="text-center">Choose the Best Account Type for You</h2>
                </div>
            </div>
                         <!-- UK -->
            <div class="row justify-content-center">
                <div class="col-6 col-md-2">
                    <p><a href="/en/accounts/individual.php"><img loading="lazy" src="/images/web/acct-type-individual.svg" alt="Individual Accounts" /> Individual Accounts</a></p>
                </div>
                <div class="col-6 col-md-2">
                    <p><a href="/en/accounts/individual.php"><img loading="lazy" src="/images/web/acct-type-joint.svg?v122123" alt="Joint Accounts" /> Joint Accounts</a></p>
                </div>
                <div class="col-6 col-md-2">
                    <p><a href="/en/accounts/individual.php"><img loading="lazy" src="/images/web/acct-type-retirement-ira.svg" alt="Retirement Accounts" /> Retirement Accounts</a></p>
                </div>
                <div class="col-6 col-md-2">
                    <p><a href="/en/accounts/individual.php"><img loading="lazy" src="/images/web/acct-type-trust.svg" alt="Trust Accounts" /> Trust Accounts</a></p>
                </div>
                <div class="col-6 col-md-2">
                    <p><a href="/en/accounts/family-account.php"><img loading="lazy" src="/images/web/acct-type-friends-family.svg" alt="Family Accounts" /> Family Accounts</a></p>
                </div>
                <div class="col-6 col-md-2 inst-btn">
                    <p><a href="/en/accounts/institutions.php"><img loading="lazy" src="/images/web/acct-type-institution.svg" alt="Institutional Accounts" /> Institutional Accounts</a></p>
                </div>
            </div>
                    </div>
    </section>
    <!-- THREE STEPS ---------------------------------------------------------------------------------------------------- -->
    <section id="three-steps" class="lazy">
        <div class="container">
            <div class="row margin-bottom-30">
                <div class="col-12 col-md-4">
                    <h5>Step 1</h5>
                    <h3>Complete the Application </h3>
                    <p>It only takes a few minutes</p>
                </div>
                <div class="col-12 col-md-4">
                    <h5>Step 2</h5>
                    <h3>Fund Your Account  </h3>
                    <p>Connect your bank or <span class="d-none d-lg-inline d-xl-none"><br /></span>transfer an account</p>
                </div>
                <div class="col-12 col-md-4">
                    <h5>Step 3</h5>
                    <h3>Get Started Trading </h3>
                    <p>Take your investing to <span class="d-none d-lg-inline d-xl-none"><br /></span>the next level</p>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                    <p><a href="https://www.interactivebrokers.co.uk/Universal/Application" target="_self" class="btn btn-primary btn-open-account" data-type="cta">Open Account</a></p>
                </div>
            </div>
        </div>
    </section>	<!-- DISCLOSURE ---------------------------------------------------------------------------------------------------- -->
	<section class="disclosure" id="disclosures">
		<div class="container">
			<div class="row">
				<div class="col-12">
                    <ol class="disclosure-list-page">
                                                <li id="d-rate-margin-lowest-3p">According to StockBrokers.com Interactive Brokers Review: <a href="https://www.stockbrokers.com/review/interactivebrokers" target="_blank" rel="noreferrer" class="linkexternal">Read the full article</a> Online Broker Reviews, January 28, 2026. "The industry’s cost leader: Interactive Brokers continues to set the benchmark for cost efficiency, offering margin rates and high yields on idle cash that consistently outperform the competition."<span> </span>View our <a href="/en/whyib/low_cost.php" target="_blank" rel="noopener noreferrer" class="link-generic">margin rates</a> for more information.
</li> 
                        <li id="d-rate-margin-details">Annual Percentage Rate (APR) on USD margin loan balances as of September 18, 2026. Interactive Brokers calculates the interest charged on margin loans using the applicable rates for each interest rate tier listed on its website. Learn more about  
 
	<a href="/en/trading/margin-rates.php">margin loan rates</a>.
</li>
                        <li id="d-rate-interest">Restrictions apply. See additional information on <a href="/en/accounts/fees/pricing-interest-rates.php" target="_blank" rel="noopenner noreferrer">interest rates</a>. Credit interest rate as of September 18, 2026.</li>
                        <li id="d-metrics-ibkr-rating-3p">Interactive Brokers LLC rating by Standard & Poor's. <a href="https://investors.interactivebrokers.com/en/general/about/ratingSandP.php" target="_blank" rel="noreferrer" >View report</a></li>
                        <!--<li id="d-rate-margin-compare">For complete information, see our <a href="/en/whyib/low_cost.php" target="_blank" rel="noopenner noreferrer" class="link-generic">margin rate comparison</a>.
</li>-->
                        <li id="d-accounts-universal-uk"><span class="disclosure-item-inline" id="d-accounts-universal-uk">** </span>Regulations require securities and commodities activities to be conducted in separate accounts.  Universal Account refers to the consolidation of these accounts for display purposes only, enabling clients the ability to use a single platform to conduct trading activity and view consolidated activity and position information for all products and services offered. 
</li>
                        <li id="d-metrics-ibkr-currencies">Available currencies vary by Interactive Brokers affiliate.</li>
                        <li id="d-metrics-ibg-affiliates">Interactive Brokers Group and its affiliates. For additional information view our <a href="https://investors.interactivebrokers.com/ir/main.php" target="_blank" rel="noopener">Investor Relations - Earnings Release</a> section. The number of client accounts displayed includes all account types across all IBG affiliates as of June 2, 2026.</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
    <!-- DISCLOSURE ADJUSTMENT -->
        <style>
        .disclosure-indicator.sup {
            font-weight: var(--fw-400);
            font-size: .625rem;
            color: inherit;
            vertical-align: super;
            inset-block-start: -0.5em;
            position: relative;
            inset-inline-start: 2px;
            line-height: 0;
        }
    </style>
    <script>
        $('span.disclosure-indicator').each(function () {
            $(this).addClass('sup');
        });

        $('.disclosure-item-inline, .disclosure-list-inline').each(function () {
            $(this).css('display', 'none');
        });
        $('.disclosure-list-page > li').each(function (index) {
            $(this).attr('data-sequence', index + 1 );
        });
        $('.disclosure-indicator').each(function () {
            var ariaDetails = $(this).attr('aria-details');
            var disclosureId = $('#' + ariaDetails);
            var disclosureCount = $(disclosureId).attr('data-sequence');
            $(this).empty().append(disclosureCount);  
        });
    </script></div>
<!-- CONTENTS END  -->
<!-- FOOTER  -->
<!-- FOOTER START  -->
 
    <style type="text/css">
    .uk-disclosure {
        background-color:#242424;
    }
    .uk-disclosure p {
        font-size:1.0rem;
        line-height:1.375rem;
        color:#FFFFFF;
    }
    .uk-disclosure p a, .uk-disclosure p a:link, .uk-disclosure p a:visited, .uk-disclosure p a:hover, .uk-disclosure p a:active, .uk-disclosure p a:focus {
        color:#FFFFFF;
        text-decoration:underline;
    }
    .uk-disclosure p a:hover {
        text-decoration:none;
    }
    </style>
        <section class="uk-disclosure" id="uk-disclosure">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <p>The risk of loss in online trading of stocks, options, futures, currencies, foreign equities, and fixed income can be substantial. Options are not suitable for all investors. For more information, read the "<a href="https://www.theocc.com/about/publications/character-risks.jsp" target="_blank">Characteristics and Risks of Standardized Options</a>".</p>
                        <p>Your capital is at risk and your losses may exceed the value of your original investment.</p>
                        <p>Interactive Brokers (U.K.) Limited is authorised and regulated by the <a href="https://www.fca.org.uk/">Financial Conduct Authority</a>. FCA Reference Number 208159.</p>
                        <p>Cryptoassets are unregulated in the UK. Interactive Brokers (U.K) Limited ("IBUK") is registered with the Financial Conduct Authority as a cryptoassets firm under the Money Laundering, Terrorist Financing and Transfer of Funds (Information on the Payer) Regulations 2017.</p>
                        <p>Interactive Brokers LLC is regulated by the US SEC and CFTC and is a <a href="/en/index.php?f=ibgStrength&p=acc" target="_self">member of the SIPC</a> (www.sipc.org) compensation scheme; 
                            products are only covered by the UK FSCS in limited circumstances.</p>
                        <p class="fw-600">Before trading, clients must read the relevant risk disclosure statements on our <a href="/en/accounts/forms-and-disclosures-services-guide.php#invest" target="_self">IBUK Services Guide – Investing with IBKR</a> page.</p>
                        <p>For a list of IBG memberships worldwide, <a href="/en/general/about/exchange_memberships.php" target="_self">see our exchange listings</a>.</p>
                        
                                            </div>
                </div>
            </div>
        </section>
        <footer class="footer noprint" id="footer" role="contentinfo">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p>Interactive Brokers®, IB<sup>SM</sup>, InteractiveBrokers.com®, Interactive Analytics®, IB Options Analytics<sup>SM</sup>, IB SmartRouting<sup>SM</sup>, BestX<sup>SM</sup>, PortfolioAnalyst®, IB Trader Workstation<sup>SM</sup> and One World, One Account<sup>SM</sup> are service marks and/or trademarks of Interactive Brokers LLC. Supporting documentation for any claims and statistical information will be provided upon request. Any trading symbols displayed are for illustrative purposes only and are not intended to portray recommendations.</p>
                    <p>The risk of loss in online trading of stocks, options, futures, currencies, foreign equities, and fixed income can be substantial.</p>
                    <p>Trading on margin is only for experienced investors with high risk tolerance. You may lose more than your initial investment. For additional information about rates on margin loans, please see <a href="/en/trading/margin-rates.php" target="_self">Margin Loan Rates</a>. Security futures involve a high degree of risk and are not suitable for all investors. The amount you may lose may be greater than your initial investment. Structured products and fixed income products such as bonds are complex products that are riskier and not suitable for all investors. </p>
                    <p>For information on the IBKR ATS and IBKR Eos ATS, please <a href="https://www.sec.gov/divisions/marketreg/form-ats-n-filings.htm#ats-n" rel="noreferrer noopener" target="_blank">visit the SEC site</a>.</p>
                    <p>40 countries include both countries and territories.</p>
                    <p>IBKR charges no custody fees but custody fees may be charged by third parties. A minimum activity fee applies to ISA/JISA accounts.</p>
                                    </div>
            </div>
            <div class="footer-site-links" id="footerSiteLinks">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <p>Account</p>
                        <ul>
                        <li><a href="https://www.interactivebrokers.co.uk/sso/Login?RL=1" target="_self">Log In</a></li>
                        <li><a href="https://www.interactivebrokers.co.uk/Universal/Application" target="_self" data-type="cta">Open an Account</a></li>
                        <li><a href="https://www.interactivebrokers.co.uk/sso/Login?c=t" target="_self">Finish an Application</a></li>
                        <li><a href="/en/accounts/account-guide.php" target="_self">Account Types</a></li>
                        <li><a href="https://www.interactivebrokers.co.uk/Universal/Application?ft=T" target="_self" data-type="cta">Free Trial</a></li>
                        </ul>
                        <p>Software & Downloads</p>
                        <ul>
                        <li><a href="/en/trading/tws.php#tws-software" target="_self">Trader Workstation</a></li>
                        <li><a href="/en/trading/ibkr-desktop.php" target="_self">IBKR Desktop</a></li>
                        <li><a href="/en/trading/tws-mobile.php#trytoday" target="_self">IBKR Mobile</a></li>
                        <li><a href="/en/trading/ib-api.php#api-software" target="_self">APIs</a></li>
                        </ul>    
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <p>Support</p>
                        <ul>
                        <li><a href="/en/support/fund-my-account.php" target="_self">Fund Your Account</a></li>
                        <li><a href="/en/support/individuals.php" target="_self">For Individuals</a></li>
                        <li><a href="/en/support/institutions.php" target="_self">For Institutions</a></li>
                        <li><a href="/en/support/institutional-sales-contacts.php?p=uk" target="_self">Institutional Sales Contacts</a></li>
                        <li><a href="/en/general/contact/ibot-container.php" target="_self">Browse our FAQs</a></li>
			<li><a href="/en/software/systemStatus.php" target="_self">System Status</a></li>
                        </ul>
                        <p>Vendor Support</p>
                        <ul>
                        <li><a href="/en/general/about/supplier-information.php" target="_self">Supplier Information</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <p>About Us</p>
                        <ul>
                        <li><a href="/en/general/awards.php" target="_self">Awards</a></li>
                        <li><a href="/en/general/about/careers-splash.php" target="_self">Careers</a></li>
                        <li><a href="/en/general/about/about.php" target="_self">Information and History</a></li>
                        <li><a href="https://investors.interactivebrokers.com/ir/main.php" target="_blank" rel="noreferrer noopener">Investor Relations</a></li>
                        <li><a href="/en/about/news-at-ibkr.php" target="_self">News @ IBKR</a></li>
                        <li><a href="/en/general/about/press-and-media.php" target="_self">Press and Media</a></li>
                        <li><a href="/en/accounts/legalDocuments/brokerPerformanceReports.php	" target="_self">Regulatory Reports</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <p>Forms and Disclosures</p>
                        <ul>
                            <li><a href="/en/accounts/forms-and-disclosures-services-guide.php" target="_self">IBUK Services Guide </a></li>
                            <li><a href="/en/accounts/forms-and-disclosures-client-agreements.php" target="_self">Client Agreements</a></li>
                            <li><a href="/en/accounts/forms-and-disclosures-disclosures.php" target="_self">Disclosures</a></li>
                            <li><a href="/en/accounts/forms-and-disclosures-mifid.php" target="_self">MiFID II Disclosures</a></li>
                            <li><a href="/en/accounts/forms-and-disclosures-client-service.php" target="_self">Client Services Forms</a></li>
                            <li><a href="/en/accounts/forms-and-disclosures-market-data.php" target="_self">Market Data Agreements</a></li>
                        </ul>
                        <p>Connect with Us</p>
                        <ul>
                            <li><a href="/en/general/ibkr-on-social-media.php" target="_self">Discover IBKR on Social Media</a></li>
                            <li><a href="https://www.facebook.com/InteractiveBrokersEurope/" target="_blank" rel="noreferrer noopener"><i class="fab fa-facebook"></i> Facebook</a></li>
                            <li><a href="https://www.instagram.com/interactivebrokers_europe" target="_blank" rel="noreferrer noopener"><i class="fab fa-instagram"></i> Instagram</a></li>
                            <li><a href="https://www.reddit.com/r/IBKR_Official/" target="_blank" rel="noreferrer noopener"><i class="fab fa-reddit"></i> Reddit</a></li>
                            <li><a href="https://twitter.com/IBKR_Europe" target="_blank" rel="noreferrer noopener"><i class="fab fa-x-twitter"></i> X (Twitter)</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-disclosure-links" id="footerDisclosureLinks">
                <div class="row">
                    <div class="col">
                        <ul>
                        <li><a href="/en/accounts/legalDocuments/anti-fraud-notice.php" target="_self">Anti-Fraud Notice</a></li>
                        <li><a href="/en/accounts/legalDocuments/custIdentificationNotice.php" target="_self">Customer Identification Program Notice</a></li>
                        <li><a href="/en/general/warnings-on-frauds-and-scams.php" target="_self">Warning on Frauds and Scams</a></li>
                        <li><a href="https://gdcdyn.interactivebrokers.com/Universal/servlet/Registration_v2.formSampleView?formdb=4476" target="_self">Modern Slavery Statement</a></li>
                                                     <li><a href="/en/accounts/legalDocuments/privacy.php" target="_self">Privacy</a></li>
                        <li><a href="/en/sitemap/index.php" target="_self">Site Map</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-entities" id="footerEntities">
                <div class="row">
                    <div class="col">
                        <div class="footer-entity">
                            <div class="row">
                                <div class="col-12 col-md-6">
                                    <!-- IBKR UK -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.co.uk/en/home.php" target="_self">Interactive Brokers (U.K.) Limited</a></p>
                                    <p>Is authorised and regulated by the <a href="https://www.fca.org.uk" target="_blank" rel="noreferrer noopener">Financial Conduct Authority</a>. FCA register entry number 208159. Incorporated in England & Wales under company number 03958476. <a href="https://www.fca.org.uk/firms/financial-services-register" target="_blank" rel="noreferrer noopener">[https://www.fca.org.uk/firms/financial-services-register]</a>
                                     <strong>Registered Office:</strong> 20 Fenchurch Street, Floor 12, London EC3M 3BY.
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.co.uk/en/home.php" target="_self">www.interactivebrokers.co.uk</a></p>
                                </div>
                                <div class="col-12 col-md-6">
                                    <!-- IBKR UK DIFC BRANCH-->
<p class="entity-name"><a href="https://www.interactivebrokers.co.uk/en/general/about/difc-branch.php" target="_blank" target="_self">Interactive Brokers (U.K.) Limited (DIFC Branch)</a></p>
<p>Is regulated by the Dubai Financial Services Authority (DFSA) to carry in and from the DIFC the financial services of Arranging Deals in Investments and Arranging Custody as defined under the DFSA Rules. DFSA register number F008423 DIFC registration number CL8717.<br> <strong>Registered Office:</strong> Floor 5, Unit 507, Index Tower, Dubai International Financial Centre, Dubai, United Arab Emirates.<br> <strong>Website:</strong> <a href="https://www.interactivebrokers.co.uk/en/general/about/difc-branch.php" target="_self">DIFC Branch</a></p>                                </div>
                            </div>
                            <p class="footer-entities-link"><a href="#collapseEntities" target="_self" class="collapsed" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="collapseEntities">Information on Other Interactive Brokers Affiliates</a></p>
                        </div>
                        <div class="footer-entities-list collapse" id="collapseEntities">
                            <div class="row">
                                <div class="col-12 col-md-6">
                                    <!-- IBKR LLC -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.com/en/home.php?nored=t" target="_self">Interactive Brokers LLC</a></p>
                                    <p>Is a member <a  rel="noreferrer noopener" target="_blank"  href="https://www.nyse.com">NYSE</a> - <a href="https://www.finra.org" rel="noreferrer noopener"  target="_blank">FINRA</a> - <a href="https://www.sipc.org" rel=" noreferrer noopener" target="_blank">SIPC</a> and regulated by the US Securities and Exchange Commission and the Commodity Futures Trading Commission.
                                     <strong>Headquarters:</strong> One Pickwick Plaza, Greenwich, CT 06830 USA
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.com/en/home.php?nored=t" target="_self">www.interactivebrokers.com</a></p>
                                    <!-- IBKR CA -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.ca/en/home.php?nored=t" target="_self">Interactive Brokers Canada Inc.</a></p>
                                    <p>Is a member of the                                     <a href="https://www.ciro.ca" target="_blank" rel="noreferrer noopener">Canadian Investment Regulatory Organization (CIRO)</a> 
                                     
                                    and Member - <a href="https://www.cipf.ca" target="_blank" rel="noreferrer noopener">Canadian Investor Protection Fund.</a>
                                     <strong>Registered Office:</strong> 1800 McGill College Avenue, Suite 2106, Montreal, Quebec, H3A 3J6, Canada.
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.ca/en/home.php?nored=t" target="_self">www.interactivebrokers.ca</a></p>
                                    <!-- IBKR IE -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.ie/en/home.php?nored=t" target="_self">Interactive Brokers Ireland Limited</a></p>
                                    <p>Is regulated by the <a href="https://www.centralbank.ie" target="_blank" rel="noreferrer noopener">Central Bank of Ireland</a> (CBI, reference number C423427), registered with the Companies Registration Office (CRO, registration number 657406), and is a member of the Irish Investor Compensation Scheme (ICS).
                                     <strong>Registered Office:</strong> North Dock One, 91/92 North Wall Quay, Dublin 1 D01 H7V7, Ireland.
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.ie/en/home.php?nored=t" target="_self">www.interactivebrokers.ie</a></p>
                                    <!-- IBKR AUS -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.com.au/en/home.php?nored=t" target="_self">Interactive Brokers Australia Pty. Ltd.</a></p>
                                    <p>ABN 98 166 929 568 is licensed and regulated by the <a href="https://asic.gov.au/" target="_blank" rel="noreferrer noopener">Australian Securities and Investments Commission</a> (AFSL: 453554) and is a participant of <a href="https://www.asx.com.au/" target="_blank" rel="noreferrer noopener">ASX</a>, <a href="https://www.asx.com.au/" target="_blank" rel="noreferrer noopener">ASX 24</a> and <a href="https://www.cboe.com.au/" target="_blank" rel="noreferrer noopener">Cboe Australia</a>.
                                     <strong>Registered Office:</strong> Level 11, 175 Pitt Street, Sydney, New South Wales 2000, Australia.
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.com.au/en/home.php?nored=t" target="_self">www.interactivebrokers.com.au </a></p>
                                </div>
                                <div class="col-12 col-md-6">
                                    <!-- IBKR HK -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.com.hk/en/home.php?nored=t" target="_self">Interactive Brokers Hong Kong Limited</a></p>
                                    <p>Is regulated by the Hong Kong Securities and Futures Commission, and is a member of the <a href="https://www.hkex.com.hk" target="_blank" rel="noreferrer noopener">SEHK</a> and the <a href="https://www.hkex.com.hk" target="_blank" rel="noreferrer noopener">HKFE</a>.
                                     <strong>Registered Office:</strong> Suite 1512, Two Pacific Place, 88 Queensway, Admiralty, Hong Kong SAR.
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.com.hk/en/home.php?nored=t" target="_self">www.interactivebrokers.com.hk</a></p>
                                    <!-- IBKR IN -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.co.in/en/home.php?nored=t" target="_self">Interactive Brokers India Pvt. Ltd.</a></p>
                                    <p>Is a trading member of <a href="https://www.nseindia.com/" target="_blank" rel="noreferrer noopener">NSE</a>, <a href="https://www.bseindia.com/" target="_blank" rel="noreferrer noopener">BSE</a>, and depository participant of <a href="https://nsdl.co.in/" target="_blank" rel="noreferrer noopener">NSDL</a>. <a href="https://www.sebi.gov.in" target="_blank" rel="noreferrer noopener">SEBI</a> Registration No. INZ000217730; NSDL: IN-DP-602-2021. CIN-U67120MH2007FTC170004.
                                     <strong>Registered Office:</strong> 401-404, 4th Floor, Waterstones, Off International Airport Road, Andheri East, Mumbai 400059, Maharashtra, India.
                                     <strong>Phone:</strong> +91-22-61289888 <span class="pipe">|</span> <strong>Fax:</strong> +91-22-61289898.
                                     <strong>Website:</strong> <a href="https://www.interactivebrokers.co.in/en/home.php?nored=t" target="_self">www.interactivebrokers.co.in</a></p>
                                    <!-- IBKR JP -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.co.jp/en/home.php?nored=t" target="_self">Interactive Brokers Securities Japan Inc.</a></p>
                                    <p>Is regulated by Kanto Local Finance Bureau (Registration No.187) and is a member of <a href="https://www.jsda.or.jp/" target="_blank" rel="noreferrer noopener">Japan Securities Dealers Association</a> and <a href="https://www.nisshokyo.or.jp" target="_blank" rel="noreferrer noopener">The Commodity Futures Association of Japan</a>.
                                     <strong>Registered Office:</strong> Kasumigaseki Building 25F, 2-5 Kasumigaseki 3-chome, Chiyoda-ku, Tokyo, 100-6025 Japan.
                                     <strong>Phone:</strong> +81 03-4590-0711 <em>(On business days from 8:30-17:30 JST)</em>.
                                     <strong>Website:</strong>  <a href="https://www.interactivebrokers.co.jp/en/home.php?nored=t" target="_self">www.interactivebrokers.co.jp</a></p>
                                    <!-- IBKR SG -->
                                    <p class="entity-name"><a href="https://www.interactivebrokers.com.sg/en/home.php" target="_self">Interactive Brokers Singapore Pte. Ltd.</a></p>
                                    <p>Is licensed and regulated by the Monetary Authority of Singapore (Licence No. CMS100917).
                                     <strong>Registered Office:</strong> 
                                                                        1 Harbourfront Place #12-01/03, Harbourfront Tower 1, Singapore 098633.
                                                                         <strong>Website:</strong>  <a href="https://www.interactivebrokers.com.sg/en/home.php" target="_self">www.interactivebrokers.com.sg</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- FOOTER END  -->
<!-- MODAL START | ABOUT IB GROUP ---------------------------------------------------------------------------------------------------- -->
<div class="modal fade" id="modalAlert" tabindex="-1" role="dialog" aria-labelledby="modalAboutIBGroup">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content modal-primary">
			<div class="modal-header">
				<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
				<h4 class="modal-title" ><i class="fas fa-exclamation-circle"></i> Notice</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col">
						<p class="message">message</p><!-- You will be brought to the website of our affiliate-->
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<div class="row">
					<div class="col-12 col-sm-3 order-2 order-sm-1">
						<div class="panel-btn-left"><a href="javascript:void(0);" data-bs-dismiss="modal" class="btn btn-secondary">Stay</a></div>
					</div>
					<div class="col-12 col-sm-9 order-1 order-sm-2">
						<div class="panel-btn-right goto"><a href="javascript:void(0);" onclick=""  data-bs-dismiss="modal"  class="btn btn-primary">Go</a></div> 
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	$('#modalAlert').on('show.bs.modal', function (event) {
	  var button = $(event.relatedTarget) // Button that triggered the modal
      let myMessage = button.data('mymessage');
      /*let myLink = "location.href='"+button.data('mytargetlink')+"'"; */
      let myLink = "window.open('"+button.data('mytargetlink')+"')"; 
	  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
	  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
	  var modal = $(this)
	  modal.find('.modal-body .message').text( myMessage );
	  modal.find('.modal-footer .goto a').attr( "onclick", myLink );

	})
});
</script><script>
if(window.location.href.includes('conf=am')) {
document.querySelector("#ibkr-header").style.display = "none";
document.querySelector("#footer").style.display = "none";
}
</script>
<!-- SCRIPTS FOOTER ---------------------------------------------------------------------------------------------------- -->
<script type="text/javascript" src="/scripts/common/js/zeynep-2.2.0/zeynep.js"></script>
<script type="text/javascript" src="/scripts/common/js/lazyload/lazyload.min.js"></script>
<script type="text/javascript" src="/search/conversions.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    
    // GATHER HEIGHT OF HEADER
    var headerHeight = $("div#ibkr-header").outerHeight();
    // GATHER HEIGHT OF DISCLOSURES
    var disclosureHeight = $("section#UKProductDisclosure, section#TurbosDisclosure").outerHeight();
    $("section#UKProductDisclosure").css("top", headerHeight);
    $("section#TurbosDisclosure").css("top", headerHeight);
    // SET CONTENTS DIV PADDING TOP
    $("div#contents").css("padding-top", disclosureHeight);
    // OVERRIDE TOP OF DISCLOSURE AND PADDING-TOP OF CONTENTS ON WINDOW RESIZE
    $(window).resize(function() {
        var headerHeight = $("div#ibkr-header").outerHeight();
        var disclosureHeight = $("section#UKProductDisclosure, section#TurbosDisclosure").outerHeight();
        var headerHeightDelta = headerHeight - disclosureHeight;
        $("section#UKProductDisclosure").css("top", disclosureHeight + headerHeightDelta);
        $("section#TurbosDisclosure").css("top", disclosureHeight + headerHeightDelta);
        $("div#contents").css("padding-top", disclosureHeight);
    });
    // OVERRIDE TOP OF DISCLOSURE AND PADDING-TOP OF CONTENTS ON BANNER CLOSE
    $("#bannerRegionSelector a.btn-close").click(function() {
        setTimeout(function() {
            var headerHeight = $("div#ibkr-header").outerHeight();
            $("section#UKProductDisclosure").css("top", headerHeight);
            $("section#TurbosDisclosure").css("top", headerHeight);
            $("div#contents").css("padding-top", disclosureHeight);
        },500);
    });
    //ADDING UNIQUE ATTRIBUTE FOR ELEMENTS WITH "data-type=cta"
    const ctaElements = document.querySelectorAll("[data-type='cta']");
    for (let i = 0; i < ctaElements.length; i++) {
        const tagType     = ctaElements[i].tagName.toLowerCase();
        const elementText = ctaElements[i].innerText.trim().substring(0, 10).replace(/\s+/g, "_").toLowerCase();
        const attributeValue = `${tagType}_${elementText}_${i}`;
        ctaElements[i].setAttribute("data-cta-btn", attributeValue);
    }
    // MOBILE MENU
    $(function() {
        // Initilize mobile menu
        var zeynep = $('.menu-mobile').zeynep({
            opened: function () {
        },
        closed: function () {
            }
        })
        // Dynamically bind closing event
        zeynep.on('closing', function () {
        })
        // Mobile menu close on overlay click
        $('.website-overlay').on('click', function () {
            zeynep.close()
        })
        // Mobile menu close on button click
        $('.btn-close').on('click', function () {
            zeynep.close()
        })
        // Mobile menu open on navbar-toggler click
        $('.navbar-toggler').on('click', function () {
            zeynep.open()
        })
    })
});
</script>
<script type="text/javascript">
function loadUtmsParam() {
  const payload = {
      src:            "",
      utm_ibsource:   "",
      w:              "",
      c:              "",
      gad_campaignid: "",
      device:         ""  };
  fetch('/mkt/ibkrutmtracking.php', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
      },
      credentials: 'same-origin',
      body: JSON.stringify(payload)
  })
  .then(function (response) {
      if (!response.ok) {
          throw new Error('Network response was not ok: ' + response.status);
      }
      return response.json();
  })
  .then(function (data) {
      if (data && data.utm_params) {
          reloadWithUtmParams(data.utm_params);
      }
  })
  .catch(function (error) {
      console.error('UTM tracking request failed:', error);
  });
}
function reloadWithUtmParams(utmParams) {
    const url = new URL(window.location.href);
    const hasSrc = url.searchParams.has('src') && url.searchParams.get('src') !== '';
    const hasIbSource = url.searchParams.has('utm_ibsource') && url.searchParams.get('utm_ibsource') !== '';
    if (!utmParams.utm_source || utmParams.utm_source === '') {
        console.warn('utm_source missing from API response, skipping reload.');
        return;
    }
    if (hasSrc) {
      url.searchParams.delete('src');
    }
    if (hasIbSource) {
      url.searchParams.delete('utm_ibsource');
    }
    Object.keys(utmParams).forEach(function (key) {
        const value = utmParams[key];
        const isUtmParam = key.indexOf('utm_') === 0;
        const alreadySetInUrl = url.searchParams.has(key) && url.searchParams.get(key) !== '';
        if (isUtmParam && alreadySetInUrl) {
            return;
        }
        
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, value);
        }
    });
    url.searchParams.set('utm_applied', '1');
    window.history.replaceState(null, '', url.toString());
}
</script>
 <script>var ibdmn='interactivebrokers.co.in';(function(d,c){let s=d.createElement('script');s.src='https://www.interactivebrokers.co.in/mkt/ibgtag.js?wbst='+c;s.id='_ib_tag';s.async=true;d.getElementsByTagName('head')[0].appendChild(s);})(document,'IN');</script><!-- STYLES FOOTER ---------------------------------------------------------------------------------------------------- -->
<link rel="preload" as="font" type="font/woff2" href="/fonts/fontawesome-7.1.0/webfonts/fa-brands-400.woff2" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="/fonts/fontawesome-7.1.0/webfonts/fa-regular-400.woff2" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="/fonts/fontawesome-7.1.0/webfonts/fa-solid-900.woff2" crossorigin>
<link rel="preload" as="style" href="/css/ibkr/main-print.min.css">
<link rel="stylesheet" type="text/css" media="print" href="/css/ibkr/main-print.min.css">
<style type="text/css">
@import url('/css/fontawesome-7.1.0/all.min.css') layer(vendors);
@import url('/css/animate-3.7.2/animate.min.css') layer(vendors);
@import url('/css/bootstrap-switch-3.3.2/bootstrap-switch.min.css') layer(vendors);
@import url('/css/icheck-1.0.2/icheck.css') layer(vendors);
</style><!-- PAGE SCRIPTS  -->
<script type="text/javascript">
// SET HEIGHT OF HERO IMAGE FOR RESIZE WITH BANNER
var setHeroHeight = function() {
	var headerHeight = $("div#ibkr-header").outerHeight();
	var droplinkHeight = $( window ).width() > 991 ? $("section#droplinks").outerHeight() : 0;
	var heightOffset = headerHeight + droplinkHeight;
	var windowHeight = $(window).height();
	// SET HEIGHT OF HERO
	$("section#hero-carousel").css("height", windowHeight - heightOffset);
}
// SET MATCH MEDIA BREAKPOINT
var mqSm = window.matchMedia( "(max-width:767.98px)" );
var mqLg = window.matchMedia( "(min-width:768px) and (max-height:1299.98px)" );
var mqV = window.matchMedia( "(min-width:768px) and (min-height:1300px)" );
$(document).ready(function () {
	var checkBootstrap = setInterval(heroSize,500);
	function heroSize(){
		var bootstrap_enabled = (typeof $().carousel == 'function');
		if (bootstrap_enabled = true){
			// HERO IMAGE RESIZE
			if (mqSm.matches) {
				// Smaller than tablet
				// DEACTIVE HERO BANNER		
				$('#carouselBannerAds').removeClass('carousel slide');
				$('#carouselBannerAds').removeAttr('data-bs-ride', 'carousel');
				$('#carouselBannerAds').carousel('pause');
			} else if (mqLg.matches) {
				// tablet size and larger
				setHeroHeight();
			} else if (mqV.matches) {
				$('#carouselBannerAds').addClass('carousel slide');
				$('#carouselBannerAds').attr('data-bs-ride', 'carousel');
				$('#carouselBannerAds').carousel('cycle');
				$('#hero-carousel').removeAttr('style');
			}
			// Clear Set Interval Once bootstrap_enabled returns true
			clearInterval(checkBootstrap);
			checkBootstrap = null; 
		}
	}
	$(window).resize(function() {	    
		// ACTIVATE/DEACTIVE HERO BANNER
		if (mqSm.matches) {
			$('#carouselBannerAds').removeClass('carousel slide');
			$('#carouselBannerAds').removeAttr('data-bs-ride', 'carousel');
			$('#carouselBannerAds').carousel('pause');
			$('#hero-carousel').removeAttr('style');
		} else if (mqLg.matches) {
			$('#carouselBannerAds').addClass('carousel slide');
			$('#carouselBannerAds').attr('data-bs-ride', 'carousel');
			$('#carouselBannerAds').carousel('cycle');
			setHeroHeight();
		} else if (mqV.matches) {
			$('#carouselBannerAds').addClass('carousel slide');
			$('#carouselBannerAds').attr('data-bs-ride', 'carousel');
			$('#carouselBannerAds').carousel('cycle');
			$('#hero-carousel').removeAttr('style');
		}
	});
});
	var login = document.querySelector("#nav-log-in");
	var portal = document.querySelector("a.btn-log-in");
	function setCookie(cname,cvalue, exdays) {
	  var d = new Date();
	  d.setTime(d.getTime() + (exdays*24*60*60*1000));
	  var expires = "expires="+d.toUTCString();
	  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	}
	login.addEventListener("click", function() { setCookie("IB_LGN", "T", 365); });
	portal.addEventListener("click", function() { setCookie("IB_LGN", "T", 365); });
</script>
</body>
</html>

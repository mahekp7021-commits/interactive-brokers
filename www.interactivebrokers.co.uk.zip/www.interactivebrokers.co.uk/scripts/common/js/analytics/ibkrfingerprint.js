// Check if a value is numeric (helper function)
function isNumeric(value) {
    return !isNaN(parseFloat(value)) && isFinite(value);
}

var IBKRFingerprint = (function() {
    function IBKRFingerprint(cookie) {
        if (!cookie) {
            var cookieId = this.getCookie("web");
            /*MKTINGSYS-5415 if (typeof cookieId !== "string" && !isNumeric(cookieId)) {
              throw new Error('Invalid cookie id');
            }*/
            this.cookieId = cookieId;
        } else {
            this.cookieId = cookie;
        }
        this.components = IBKRFingerprint.getComponents();
        this.calculateHashes();
    }
    // Static property - converted to variable
    IBKRFingerprint.debug_mode = false;
    // Instance methods
    IBKRFingerprint.prototype.getComponents = function() {
        return this.components;
    };
    IBKRFingerprint.prototype.getCookie = function(name) {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Check if this cookie starts with the name we're looking for
            if (cookie.indexOf(name + '=') === 0) {
                // Return everything after "name="
                return cookie.substring(name.length + 1);
            }
        }
        return null;
    }
    IBKRFingerprint.prototype.calculateHashes = function() {
        var commonComponents = [
            this.components['languages'] || '',
            this.components['screen-size'] || '',
            this.components['is-mobile'] || ''
        ].join('');
        // Low entropy components
        var lowEntropy = [
            this.components['browser'] || '',
            this.components['operating-system'] || '',
            commonComponents
        ].join('');
        // Med entropy components
        var medEntropy = [
            this.components['user-agent'] || '',
            commonComponents
        ].join('');
        // High entropy components
        var highEntropy = [
            medEntropy,
            this.components['canvas'] || '',
            this.components['wgl-vendor'] || '',
            this.components['wgl-renderer'] || '',
            this.components['timezone-offset']
        ].join('');
        // Calculate hashes
        this.lowEntrophyFP = IBKRFingerprint.getSHA256Hash(lowEntropy);
        this.medEntrophyFP = IBKRFingerprint.getSHA256Hash(medEntropy);
        this.highEntropyFP = IBKRFingerprint.getSHA256Hash(highEntropy);
    };
    IBKRFingerprint.prototype.toString = function() {
        return "{Low Entropy:" + this.lowEntrophyFP + ",Med Entropy:" + this.medEntrophyFP + ",High Entropy:" + this.highEntropyFP + "}";
    };
    // Static methods
    IBKRFingerprint.getSHA256Hash = function(str) {
        var md = forge.md.sha256.create();
        md.update(str);
        return md.digest().toHex();
    };
    IBKRFingerprint.displayConsole = function(msg) {
        if (IBKRFingerprint.debug_mode) {
            console.log(msg);
        }
    };
    IBKRFingerprint.getComponents = function() {
        var components = {};
        // User and browser information 
        IBKRFingerprint.getUserAgent(components);
        IBKRFingerprint.getBrowser(components);
        IBKRFingerprint.getLanguages(components);
        // Device capabilities
        IBKRFingerprint.getHardwareConcurrency(components);
        IBKRFingerprint.getBlueTooth(components);
        IBKRFingerprint.getCookieEnabled(components);
        IBKRFingerprint.getMaxTouchPoints(components);
        IBKRFingerprint.isMobileDevice(components);
        IBKRFingerprint.getDeviceMemory(components);
        // Display information 
        IBKRFingerprint.getColorDepth(components);
        IBKRFingerprint.getScreenSize(components);
        IBKRFingerprint.getAvailScreenSize(components);
        // Time and connection 
        IBKRFingerprint.getTimezoneOffset(components);
        IBKRFingerprint.getConnectionEffectiveType(components);
        // Graphics and plugin
        // Graphics and plugin
        IBKRFingerprint.getCanvas(components);
        IBKRFingerprint.getPlugins(components);
        IBKRFingerprint.getFontsKey(components);
        return components;
    };
    IBKRFingerprint.getBrowser = function(components) {
        var ua = components['user-agent'].toLowerCase();
        components['browser'] = "n/a";
        var browserDetectionRules = [{
                pattern: /\sedg/i,
                name: "Microsoft Edge"
            },
            {
                pattern: /(chrome|crios|crmo)/i,
                exclude: /chromium|edg/i,
                name: "Google Chrome"
            },
            {
                pattern: /(firefox|iceweasel|fxios)/i,
                name: "Mozilla Firefox"
            },
            {
                pattern: /(safari|applewebkit)/i,
                exclude: /(chrome|chromium)/i,
                name: "Safari"
            },
            {
                pattern: /(msie|trident)/i,
                name: "Internet Explorer"
            },
            {
                pattern: /(opera|opr\/|opis)/i,
                name: "Opera"
            },
            {
                pattern: /seamonkey/i,
                name: "SeaMonkey"
            },
            {
                pattern: /silk/i,
                name: "Silk"
            }
        ];
        // Find the first matching browser rule
        for (var i = 0; i < browserDetectionRules.length; i++) {
            var rule = browserDetectionRules[i];
            if (rule.pattern.test(ua) && (!rule.exclude || !rule.exclude.test(ua))) {
                components['browser'] = rule.name;
                break;
            }
        }
        IBKRFingerprint.displayConsole(components['browser']);
    };
    IBKRFingerprint.getUserAgent = function(components) {
        IBKRFingerprint.displayConsole("User Agent is:" + navigator.userAgent);
        components['user-agent'] = navigator.userAgent;
        components['operating-system'] = IBKRFingerprint.getOS(navigator.userAgent);
        IBKRFingerprint.displayConsole("OS:" + components['operating-system']);
    };
    IBKRFingerprint.getLanguages = function(components) {
        IBKRFingerprint.displayConsole("Languages:" + navigator.languages);
        components['languages'] = navigator.languages || navigator.language || '';
    };
    IBKRFingerprint.getHardwareConcurrency = function(components) {
        components['hardware-concur'] = navigator.hardwareConcurrency ? navigator.hardwareConcurrency : '';
        IBKRFingerprint.displayConsole("Hardware Concurrency:" + components['hardware-concur']);
    };
    IBKRFingerprint.getBlueTooth = function(components) {
        components['bluetooth'] = navigator.bluetooth ? true : '';
        IBKRFingerprint.displayConsole("Bluetooth: " + components['bluetooth']);
    };
    IBKRFingerprint.getCookieEnabled = function(components) {
        components['cookie-enabled'] = navigator.cookieEnabled ? navigator.cookieEnabled : '';
        IBKRFingerprint.displayConsole("Cookie Enabled: " + components['cookie-enabled']);
    };
    IBKRFingerprint.getMaxTouchPoints = function(components) {
        components['max-touch-points'] = navigator.maxTouchPoints > 0 ? navigator.maxTouchPoints : '';
        IBKRFingerprint.displayConsole("Max touch points:" + components['max-touch-points']);
    };
    IBKRFingerprint.getColorDepth = function(components) {
        components['color-depth'] = screen.colorDepth > 0 ? screen.colorDepth : '';
        IBKRFingerprint.displayConsole("Color depth:" + components['color-depth']);
    };
    IBKRFingerprint.getScreenSize = function(components) {
        components['screen-size'] = screen.height + 'x' + screen.width;
        IBKRFingerprint.displayConsole("Screen size:" + components['screen-size']);
    };
    IBKRFingerprint.getAvailScreenSize = function(components) {
        components['avail-screen-size'] = screen.availHeight + 'x' + screen.availWidth;
        IBKRFingerprint.displayConsole("Avail screen size:" + components['avail-screen-size']);
    };
    IBKRFingerprint.getTimezoneOffset = function(components) {
        components['timezone-offset'] = new Date().getTimezoneOffset();
        IBKRFingerprint.displayConsole("Timezone Offset:" + components['timezone-offset']);
    };
    IBKRFingerprint.isMobileDevice = function(components) {
        if (/Mobi|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            components['is-mobile'] = 'T';
        }
        IBKRFingerprint.displayConsole("Is mobile:" + components['is-mobile']);
    };
    IBKRFingerprint.getPlugins = function(components) {
        var plugins = '';
        if (navigator.plugins) {
            var pluginsArray = [];
            for (var i = 0; i < navigator.plugins.length; i++) {
                pluginsArray.push(navigator.plugins[i].name);
            }
            plugins = pluginsArray.sort().join(",");
        }
        components['plugins'] = plugins;
        IBKRFingerprint.displayConsole("Plugins:" + components['plugins']);
    };
    IBKRFingerprint.getConnectionEffectiveType = function(components) {
        components['conn-effective-type'] = navigator.connection ? navigator.connection.effectiveType : '';
        IBKRFingerprint.displayConsole("Connection Effective Type:" + components['conn-effective-type']);
    };
    IBKRFingerprint.getDeviceMemory = function(components) {
        components['device-memory'] = navigator.deviceMemory ? navigator.deviceMemory : '';
        IBKRFingerprint.displayConsole("Device Memory:" + components['device-memory']);
    };
    IBKRFingerprint.isTouchDevice = function(components) {
        if ('ontouchstart' in window || (navigator.maxTouchPoints > 0)) {
            components['is_touch_device'] = 'T';
            IBKRFingerprint.displayConsole("Touchscreen");
        }
    };
    IBKRFingerprint.getOS = function(userAgent) {
        // Create a lowercase version for case-insensitive matching
        var ua = userAgent.toLowerCase();
        // Use specific OS patterns with ordered checks (more specific first)
        if (/android/.test(ua)) return "Android";
        if (/iphone|ipad|ipod|ios/.test(ua)) return "iOS";
        if (/mac os x/.test(ua)) return "macOS";
        if (/windows nt 10\.0/.test(ua)) return "Windows 10";
        if (/windows nt 6\.3/.test(ua)) return "Windows 8.1";
        if (/windows nt 6\.2/.test(ua)) return "Windows 8";
        if (/windows nt 6\.1/.test(ua)) return "Windows 7";
        if (/windows nt/.test(ua)) return "Windows";
        if (/linux/.test(ua)) return "Linux";
        if (/cros/.test(ua)) return "ChromeOS";
        if (/windows phone/.test(ua)) return "Windows Phone";
        // If we can't determine the OS, return Unknown
        return "Unknown";
    };
    IBKRFingerprint.getCanvas = function(components) {
        // Check for DNT or user preferences
        if (navigator.doNotTrack === "1") {
            components['canvas'] = 'opt-out';
            return;
        }
        // Create and configure canvas with explicit size
        var canvas = document.createElement('canvas');
        canvas.width = 250;
        canvas.height = 30;
        var ctx = canvas.getContext('2d');
        if (!ctx) { // 2D Canvas not supported
            return;
        }
        ctx.font = "14px 'Arial'";
        ctx.textBaseline = "alphabetic";
        ctx.fillStyle = "#f60";
        ctx.fillRect(125, 1, 62, 20);
        ctx.fillStyle = "#069";
        ctx.fillText("IBKR", 2, 15);
        ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
        ctx.fillText("IBKR", 4, 17);
        /*
        // Add some extra entropy with a custom shape
           ctx.beginPath();
           ctx.arc(210, 10, 8, 0, Math.PI * 2);
           ctx.fillStyle = "rgba(255, 0, 255, 0.5)";
           ctx.fill();
        */
        components['canvas'] = canvas.toDataURL();
        IBKRFingerprint.displayConsole("Canvas:" + components['canvas']);
        try {
            var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            if (gl) {
                components['wgl-vendor'] = gl.getParameter(gl.VENDOR) ? gl.getParameter(gl.VENDOR) : '';
                components['wgl-renderer'] = gl.getParameter(gl.RENDERER) ? gl.getParameter(gl.RENDERER) : '';
                IBKRFingerprint.displayConsole("GL Vendor:" + components['wgl-vendor']);
                IBKRFingerprint.displayConsole("GL Renderer:" + components['wgl-renderer']);
            } else {
                IBKRFingerprint.displayConsole('No WebGL');
            }
        } catch (e) {
            IBKRFingerprint.displayConsole('webgl-error');
        }
    };
    IBKRFingerprint.getFontsKey = function(components) {
        // a font will be compared against all the three default fonts.
        // and if it doesn't match all 3 then that font is not available.
        var baseFonts = ["monospace", "sans-serif", "serif"];
        var fontList = [
            "Andale Mono", "Arial", "Arial Black", "Arial Hebrew", "Arial MT", "Arial Narrow", "Arial Rounded MT Bold", "Arial Unicode MS",
            "Bitstream Vera Sans Mono", "Book Antiqua", "Bookman Old Style",
            "Calibri", "Cambria", "Cambria Math", "Century", "Century Gothic", "Century Schoolbook", "Comic Sans", "Comic Sans MS", "Consolas", "Courier", "Courier New",
            "Garamond", "Geneva", "Georgia",
            "Helvetica", "Helvetica Neue",
            "Impact",
            "Lucida Bright", "Lucida Calligraphy", "Lucida Console", "Lucida Fax", "LUCIDA GRANDE", "Lucida Handwriting", "Lucida Sans", "Lucida Sans Typewriter", "Lucida Sans Unicode",
            "Microsoft Sans Serif", "Monaco", "Monotype Corsiva", "MS Gothic", "MS Outlook", "MS PGothic", "MS Reference Sans Serif", "MS Sans Serif", "MS Serif", "MYRIAD", "MYRIAD PRO",
            "Palatino", "Palatino Linotype",
            "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Light", "Segoe UI Semibold", "Segoe UI Symbol",
            "Tahoma", "Times", "Times New Roman", "Times New Roman PS", "Trebuchet MS",
            "Verdana", "Wingdings", "Wingdings 2", "Wingdings 3",
            "Abadi MT Condensed Light", "Academy Engraved LET", "ADOBE CASLON PRO", "Adobe Garamond", "ADOBE GARAMOND PRO", "Agency FB", "Aharoni", "Albertus Extra Bold", "Albertus Medium", "Algerian", "Amazone BT", "American Typewriter",
            "American Typewriter Condensed", "AmerType Md BT", "Andalus", "Angsana New", "AngsanaUPC", "Antique Olive", "Aparajita", "Apple Chancery", "Apple Color Emoji", "Apple SD Gothic Neo", "Arabic Typesetting", "ARCHER",
            "ARNO PRO", "Arrus BT", "Aurora Cn BT", "AvantGarde Bk BT", "AvantGarde Md BT", "AVENIR", "Ayuthaya", "Bandy", "Bangla Sangam MN", "Bank Gothic", "BankGothic Md BT", "Baskerville",
            "Baskerville Old Face", "Batang", "BatangChe", "Bauer Bodoni", "Bauhaus 93", "Bazooka", "Bell MT", "Bembo", "Benguiat Bk BT", "Berlin Sans FB", "Berlin Sans FB Demi", "Bernard MT Condensed", "BernhardFashion BT", "BernhardMod BT", "Big Caslon", "BinnerD",
            "Blackadder ITC", "BlairMdITC TT", "Bodoni 72", "Bodoni 72 Oldstyle", "Bodoni 72 Smallcaps", "Bodoni MT", "Bodoni MT Black", "Bodoni MT Condensed", "Bodoni MT Poster Compressed",
            "Bookshelf Symbol 7", "Boulder", "Bradley Hand", "Bradley Hand ITC", "Bremen Bd BT", "Britannic Bold", "Broadway", "Browallia New", "BrowalliaUPC", "Brush Script MT", "Californian FB", "Calisto MT", "Calligrapher", "Candara",
            "CaslonOpnface BT", "Castellar", "Centaur", "Cezanne", "CG Omega", "CG Times", "Chalkboard", "Chalkboard SE", "Chalkduster", "Charlesworth", "Charter Bd BT", "Charter BT", "Chaucer",
            "ChelthmITC Bk BT", "Chiller", "Clarendon", "Clarendon Condensed", "CloisterBlack BT", "Cochin", "Colonna MT", "Constantia", "Cooper Black", "Copperplate", "Copperplate Gothic", "Copperplate Gothic Bold",
            "Copperplate Gothic Light", "CopperplGoth Bd BT", "Corbel", "Cordia New", "CordiaUPC", "Cornerstone", "Coronet", "Cuckoo", "Curlz MT", "DaunPenh", "Dauphin", "David", "DB LCD Temp", "DELICIOUS", "Denmark",
            "DFKai-SB", "Didot", "DilleniaUPC", "DIN", "DokChampa", "Dotum", "DotumChe", "Ebrima", "Edwardian Script ITC", "Elephant", "English 111 Vivace BT", "Engravers MT", "EngraversGothic BT", "Eras Bold ITC", "Eras Demi ITC", "Eras Light ITC", "Eras Medium ITC",
            "EucrosiaUPC", "Euphemia", "Euphemia UCAS", "EUROSTILE", "Exotc350 Bd BT", "FangSong", "Felix Titling", "Fixedsys", "FONTIN", "Footlight MT Light", "Forte",
            "FrankRuehl", "Fransiscan", "Freefrm721 Blk BT", "FreesiaUPC", "Freestyle Script", "French Script MT", "FrnkGothITC Bk BT", "Fruitger", "FRUTIGER",
            "Futura", "Futura Bk BT", "Futura Lt BT", "Futura Md BT", "Futura ZBlk BT", "FuturaBlack BT", "Gabriola", "Galliard BT", "Gautami", "Geeza Pro", "Geometr231 BT", "Geometr231 Hv BT", "Geometr231 Lt BT", "GeoSlab 703 Lt BT",
            "GeoSlab 703 XBd BT", "Gigi", "Gill Sans", "Gill Sans MT", "Gill Sans MT Condensed", "Gill Sans MT Ext Condensed Bold", "Gill Sans Ultra Bold", "Gill Sans Ultra Bold Condensed", "Gisha", "Gloucester MT Extra Condensed", "GOTHAM", "GOTHAM BOLD",
            "Goudy Old Style", "Goudy Stout", "GoudyHandtooled BT", "GoudyOLSt BT", "Gujarati Sangam MN", "Gulim", "GulimChe", "Gungsuh", "GungsuhChe", "Gurmukhi MN", "Haettenschweiler", "Harlow Solid Italic", "Harrington", "Heather", "Heiti SC", "Heiti TC", "HELV",
            "Herald", "High Tower Text", "Hiragino Kaku Gothic ProN", "Hiragino Mincho ProN", "Hoefler Text", "Humanst 521 Cn BT", "Humanst521 BT", "Humanst521 Lt BT", "Imprint MT Shadow", "Incised901 Bd BT", "Incised901 BT",
            "Incised901 Lt BT", "INCONSOLATA", "Informal Roman", "Informal011 BT", "INTERSTATE", "IrisUPC", "Iskoola Pota", "JasmineUPC", "Jazz LET", "Jenson", "Jester", "Jokerman", "Juice ITC", "Kabel Bk BT", "Kabel Ult BT", "Kailasa", "KaiTi", "Kalinga", "Kannada Sangam MN",
            "Kartika", "Kaufmann Bd BT", "Kaufmann BT", "Khmer UI", "KodchiangUPC", "Kokila", "Korinna BT", "Kristen ITC", "Krungthep", "Kunstler Script", "Lao UI", "Latha", "Leelawadee", "Letter Gothic", "Levenim MT", "LilyUPC", "Lithograph", "Lithograph Light", "Long Island",
            "Lydian BT", "Magneto", "Maiandra GD", "Malayalam Sangam MN", "Malgun Gothic",
            "Mangal", "Marigold", "Marion", "Marker Felt", "Market", "Marlett", "Matisse ITC", "Matura MT Script Capitals", "Meiryo", "Meiryo UI", "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le",
            "Microsoft Uighur", "Microsoft YaHei", "Microsoft Yi Baiti", "MingLiU", "MingLiU_HKSCS", "MingLiU_HKSCS-ExtB", "MingLiU-ExtB", "Minion", "Minion Pro", "Miriam", "Miriam Fixed", "Mistral", "Modern", "Modern No. 20", "Mona Lisa Solid ITC TT", "Mongolian Baiti",
            "MONO", "MoolBoran", "Mrs Eaves", "MS LineDraw", "MS Mincho", "MS PMincho", "MS Reference Specialty", "MS UI Gothic", "MT Extra", "MUSEO", "MV Boli",
            "Nadeem", "Narkisim", "NEVIS", "News Gothic", "News GothicMT", "NewsGoth BT", "Niagara Engraved", "Niagara Solid", "Noteworthy", "NSimSun", "Nyala", "OCR A Extended", "Old Century", "Old English Text MT", "Onyx", "Onyx BT", "OPTIMA", "Oriya Sangam MN",
            "OSAKA", "OzHandicraft BT", "Palace Script MT", "Papyrus", "Parchment", "Party LET", "Pegasus", "Perpetua", "Perpetua Titling MT", "PetitaBold", "Pickwick", "Plantagenet Cherokee", "Playbill", "PMingLiU", "PMingLiU-ExtB",
            "Poor Richard", "Poster", "PosterBodoni BT", "PRINCETOWN LET", "Pristina", "PTBarnum BT", "Pythagoras", "Raavi", "Rage Italic", "Ravie", "Ribbon131 Bd BT", "Rockwell", "Rockwell Condensed", "Rockwell Extra Bold", "Rod", "Roman", "Sakkal Majalla",
            "Santa Fe LET", "Savoye LET", "Sceptre", "Script", "Script MT Bold", "SCRIPTINA", "Serifa", "Serifa BT", "Serifa Th BT", "ShelleyVolante BT", "Sherwood",
            "Shonar Bangla", "Showcard Gothic", "Shruti", "Signboard", "SILKSCREEN", "SimHei", "Simplified Arabic", "Simplified Arabic Fixed", "SimSun", "SimSun-ExtB", "Sinhala Sangam MN", "Sketch Rockwell", "Skia", "Small Fonts", "Snap ITC", "Snell Roundhand", "Socket",
            "Souvenir Lt BT", "Staccato222 BT", "Steamer", "Stencil", "Storybook", "Styllo", "Subway", "Swis721 BlkEx BT", "Swiss911 XCm BT", "Sylfaen", "Synchro LET", "System", "Tamil Sangam MN", "Technical", "Teletype", "Telugu Sangam MN", "Tempus Sans ITC",
            "Terminal", "Thonburi", "Traditional Arabic", "Trajan", "TRAJAN PRO", "Tristan", "Tubular", "Tunga", "Tw Cen MT", "Tw Cen MT Condensed", "Tw Cen MT Condensed Extra Bold",
            "TypoUpright BT", "Unicorn", "Univers", "Univers CE 55 Medium", "Univers Condensed", "Utsaah", "Vagabond", "Vani", "Vijaya", "Viner Hand ITC", "VisualUI", "Vivaldi", "Vladimir Script", "Vrinda", "Westminster", "WHITNEY", "Wide Latin",
            "ZapfEllipt BT", "ZapfHumnst BT", "ZapfHumnst Dm BT", "Zapfino", "Zurich BlkEx BT", "Zurich Ex BT", "ZWAdobeF"
        ];
        //we use m or w because these two characters take up the maximum width.
        // And we use a LLi so that the same matching fonts can get separated
        var testString = "mmmmmmmmmmlli";
        //we test using 72px font size, we may use any size. I guess larger the better.
        var testSize = "72px";
        var h = document.getElementsByTagName("body")[0];
        // div to load spans for the base fonts
        var baseFontsDiv = document.createElement("div");
        // div to load spans for the fonts to detect
        var fontsDiv = document.createElement("div");
        var defaultWidth = {};
        var defaultHeight = {};
        // creates a span where the fonts will be loaded
        var createSpan = function() {
            var s = document.createElement("span");
            /*
             * We need this css as in some weird browser this
             * span elements shows up for a microSec which creates a
             * bad user experience
             */
            s.style.position = "absolute";
            s.style.left = "-9999px";
            s.style.fontSize = testSize;
            s.style.lineHeight = "normal";
            s.innerHTML = testString;
            return s;
        };
        // creates a span and load the font to detect and a base font for fallback
        var createSpanWithFonts = function(fontToDetect, baseFont) {
            var s = createSpan();
            s.style.fontFamily = "'" + fontToDetect + "'," + baseFont;
            return s;
        };
        // creates spans for the base fonts and adds them to baseFontsDiv
        var initializeBaseFontsSpans = function() {
            var spans = [];
            for (var index = 0, length = baseFonts.length; index < length; index++) {
                var s = createSpan();
                s.style.fontFamily = baseFonts[index];
                baseFontsDiv.appendChild(s);
                spans.push(s);
            }
            return spans;
        };
        // creates spans for the fonts to detect and adds them to fontsDiv
        var initializeFontsSpans = function() {
            var spans = {};
            for (var i = 0, l = fontList.length; i < l; i++) {
                var fontSpans = [];
                for (var j = 0, numDefaultFonts = baseFonts.length; j < numDefaultFonts; j++) {
                    var s = createSpanWithFonts(fontList[i], baseFonts[j]);
                    fontsDiv.appendChild(s);
                    fontSpans.push(s);
                }
                spans[fontList[i]] = fontSpans; // Stores {fontName : [spans for that font]}
            }
            return spans;
        };
        // checks if a font is available
        var isFontAvailable = function(fontSpans) {
            var detected = false;
            for (var i = 0; i < baseFonts.length; i++) {
                detected = (fontSpans[i].offsetWidth !== defaultWidth[baseFonts[i]] || fontSpans[i].offsetHeight !== defaultHeight[baseFonts[i]]);
                if (detected) {
                    return detected;
                }
            }
            return detected;
        };
        // create spans for base fonts
        var baseFontsSpans = initializeBaseFontsSpans();
        // add the spans to the DOM
        h.appendChild(baseFontsDiv);
        // get the default width for the three base fonts
        for (var index = 0, length = baseFonts.length; index < length; index++) {
            defaultWidth[baseFonts[index]] = baseFontsSpans[index].offsetWidth; // width for the default font
            defaultHeight[baseFonts[index]] = baseFontsSpans[index].offsetHeight; // height for the default font
        }
        // create spans for fonts to detect
        var fontsSpans = initializeFontsSpans();
        // add all the spans to the DOM
        h.appendChild(fontsDiv);
        // check available fonts
        var available = [];
        for (var i = 0, l = fontList.length; i < l; i++) {
            if (isFontAvailable(fontsSpans[fontList[i]])) {
                available.push(fontList[i]);
            }
        }
        // remove spans from DOM
        h.removeChild(fontsDiv);
        h.removeChild(baseFontsDiv);
        components['js_fonts'] = available;
    };
    // Return constructor to make it accessible
    return IBKRFingerprint;
})();
// Add this line right here, after the IIFE closes
window.IBKRFingerprint = IBKRFingerprint;
(() => {
    var e = {
            6173: function(e, t, n) {
                var i;
                e.exports = (i = i || function(e, t) {
                    var i;
                    if ("undefined" != typeof window && window.crypto && (i = window.crypto), "undefined" != typeof self && self.crypto && (i = self.crypto), "undefined" != typeof globalThis && globalThis.crypto && (i = globalThis.crypto), !i && "undefined" != typeof window && window.msCrypto && (i = window.msCrypto), !i && void 0 !== n.g && n.g.crypto && (i = n.g.crypto), !i) try {
                        i = n(2480)
                    } catch (e) {}
                    var r = function() {
                            if (i) {
                                if ("function" == typeof i.getRandomValues) try {
                                    return i.getRandomValues(new Uint32Array(1))[0]
                                } catch (e) {}
                                if ("function" == typeof i.randomBytes) try {
                                    return i.randomBytes(4).readInt32LE()
                                } catch (e) {}
                            }
                            throw new Error("Native crypto module could not be used to get secure random number.")
                        },
                        o = Object.create || function() {
                            function e() {}
                            return function(t) {
                                var n;
                                return e.prototype = t, n = new e, e.prototype = null, n
                            }
                        }(),
                        s = {},
                        a = s.lib = {},
                        c = a.Base = {
                            extend: function(e) {
                                var t = o(this);
                                return e && t.mixIn(e), t.hasOwnProperty("init") && this.init !== t.init || (t.init = function() {
                                    t.$super.init.apply(this, arguments)
                                }), t.init.prototype = t, t.$super = this, t
                            },
                            create: function() {
                                var e = this.extend();
                                return e.init.apply(e, arguments), e
                            },
                            init: function() {},
                            mixIn: function(e) {
                                for (var t in e) e.hasOwnProperty(t) && (this[t] = e[t]);
                                e.hasOwnProperty("toString") && (this.toString = e.toString)
                            },
                            clone: function() {
                                return this.init.prototype.extend(this)
                            }
                        },
                        u = a.WordArray = c.extend({
                            init: function(e, t) {
                                e = this.words = e || [], this.sigBytes = null != t ? t : 4 * e.length
                            },
                            toString: function(e) {
                                return (e || d).stringify(this)
                            },
                            concat: function(e) {
                                var t = this.words,
                                    n = e.words,
                                    i = this.sigBytes,
                                    r = e.sigBytes;
                                if (this.clamp(), i % 4)
                                    for (var o = 0; o < r; o++) {
                                        var s = n[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                                        t[i + o >>> 2] |= s << 24 - (i + o) % 4 * 8
                                    } else
                                        for (var a = 0; a < r; a += 4) t[i + a >>> 2] = n[a >>> 2];
                                return this.sigBytes += r, this
                            },
                            clamp: function() {
                                var t = this.words,
                                    n = this.sigBytes;
                                t[n >>> 2] &= 4294967295 << 32 - n % 4 * 8, t.length = e.ceil(n / 4)
                            },
                            clone: function() {
                                var e = c.clone.call(this);
                                return e.words = this.words.slice(0), e
                            },
                            random: function(e) {
                                for (var t = [], n = 0; n < e; n += 4) t.push(r());
                                return new u.init(t, e)
                            }
                        }),
                        l = s.enc = {},
                        d = l.Hex = {
                            stringify: function(e) {
                                for (var t = e.words, n = e.sigBytes, i = [], r = 0; r < n; r++) {
                                    var o = t[r >>> 2] >>> 24 - r % 4 * 8 & 255;
                                    i.push((o >>> 4).toString(16)), i.push((15 & o).toString(16))
                                }
                                return i.join("")
                            },
                            parse: function(e) {
                                for (var t = e.length, n = [], i = 0; i < t; i += 2) n[i >>> 3] |= parseInt(e.substr(i, 2), 16) << 24 - i % 8 * 4;
                                return new u.init(n, t / 2)
                            }
                        },
                        f = l.Latin1 = {
                            stringify: function(e) {
                                for (var t = e.words, n = e.sigBytes, i = [], r = 0; r < n; r++) {
                                    var o = t[r >>> 2] >>> 24 - r % 4 * 8 & 255;
                                    i.push(String.fromCharCode(o))
                                }
                                return i.join("")
                            },
                            parse: function(e) {
                                for (var t = e.length, n = [], i = 0; i < t; i++) n[i >>> 2] |= (255 & e.charCodeAt(i)) << 24 - i % 4 * 8;
                                return new u.init(n, t)
                            }
                        },
                        _ = l.Utf8 = {
                            stringify: function(e) {
                                try {
                                    return decodeURIComponent(escape(f.stringify(e)))
                                } catch (e) {
                                    throw new Error("Malformed UTF-8 data")
                                }
                            },
                            parse: function(e) {
                                return f.parse(unescape(encodeURIComponent(e)))
                            }
                        },
                        m = a.BufferedBlockAlgorithm = c.extend({
                            reset: function() {
                                this._data = new u.init, this._nDataBytes = 0
                            },
                            _append: function(e) {
                                "string" == typeof e && (e = _.parse(e)), this._data.concat(e), this._nDataBytes += e.sigBytes
                            },
                            _process: function(t) {
                                var n, i = this._data,
                                    r = i.words,
                                    o = i.sigBytes,
                                    s = this.blockSize,
                                    a = o / (4 * s),
                                    c = (a = t ? e.ceil(a) : e.max((0 | a) - this._minBufferSize, 0)) * s,
                                    l = e.min(4 * c, o);
                                if (c) {
                                    for (var d = 0; d < c; d += s) this._doProcessBlock(r, d);
                                    n = r.splice(0, c), i.sigBytes -= l
                                }
                                return new u.init(n, l)
                            },
                            clone: function() {
                                var e = c.clone.call(this);
                                return e._data = this._data.clone(), e
                            },
                            _minBufferSize: 0
                        }),
                        p = (a.Hasher = m.extend({
                            cfg: c.extend(),
                            init: function(e) {
                                this.cfg = this.cfg.extend(e), this.reset()
                            },
                            reset: function() {
                                m.reset.call(this), this._doReset()
                            },
                            update: function(e) {
                                return this._append(e), this._process(), this
                            },
                            finalize: function(e) {
                                return e && this._append(e), this._doFinalize()
                            },
                            blockSize: 16,
                            _createHelper: function(e) {
                                return function(t, n) {
                                    return new e.init(n).finalize(t)
                                }
                            },
                            _createHmacHelper: function(e) {
                                return function(t, n) {
                                    return new p.HMAC.init(e, n).finalize(t)
                                }
                            }
                        }), s.algo = {});
                    return s
                }(Math), i)
            },
            7219: function(e, t, n) {
                var i;
                e.exports = (i = n(6173), function(e) {
                    var t = i,
                        n = t.lib,
                        r = n.WordArray,
                        o = n.Hasher,
                        s = t.algo,
                        a = [],
                        c = [];
                    ! function() {
                        function t(t) {
                            for (var n = e.sqrt(t), i = 2; i <= n; i++)
                                if (!(t % i)) return !1;
                            return !0
                        }

                        function n(e) {
                            return 4294967296 * (e - (0 | e)) | 0
                        }
                        for (var i = 2, r = 0; r < 64;) t(i) && (r < 8 && (a[r] = n(e.pow(i, .5))), c[r] = n(e.pow(i, 1 / 3)), r++), i++
                    }();
                    var u = [],
                        l = s.SHA256 = o.extend({
                            _doReset: function() {
                                this._hash = new r.init(a.slice(0))
                            },
                            _doProcessBlock: function(e, t) {
                                for (var n = this._hash.words, i = n[0], r = n[1], o = n[2], s = n[3], a = n[4], l = n[5], d = n[6], f = n[7], _ = 0; _ < 64; _++) {
                                    if (_ < 16) u[_] = 0 | e[t + _];
                                    else {
                                        var m = u[_ - 15],
                                            p = (m << 25 | m >>> 7) ^ (m << 14 | m >>> 18) ^ m >>> 3,
                                            h = u[_ - 2],
                                            g = (h << 15 | h >>> 17) ^ (h << 13 | h >>> 19) ^ h >>> 10;
                                        u[_] = p + u[_ - 7] + g + u[_ - 16]
                                    }
                                    var v = i & r ^ i & o ^ r & o,
                                        E = (i << 30 | i >>> 2) ^ (i << 19 | i >>> 13) ^ (i << 10 | i >>> 22),
                                        y = f + ((a << 26 | a >>> 6) ^ (a << 21 | a >>> 11) ^ (a << 7 | a >>> 25)) + (a & l ^ ~a & d) + c[_] + u[_];
                                    f = d, d = l, l = a, a = s + y | 0, s = o, o = r, r = i, i = y + (E + v) | 0
                                }
                                n[0] = n[0] + i | 0, n[1] = n[1] + r | 0, n[2] = n[2] + o | 0, n[3] = n[3] + s | 0, n[4] = n[4] + a | 0, n[5] = n[5] + l | 0, n[6] = n[6] + d | 0, n[7] = n[7] + f | 0
                            },
                            _doFinalize: function() {
                                var t = this._data,
                                    n = t.words,
                                    i = 8 * this._nDataBytes,
                                    r = 8 * t.sigBytes;
                                return n[r >>> 5] |= 128 << 24 - r % 32, n[14 + (r + 64 >>> 9 << 4)] = e.floor(i / 4294967296), n[15 + (r + 64 >>> 9 << 4)] = i, t.sigBytes = 4 * n.length, this._process(), this._hash
                            },
                            clone: function() {
                                var e = o.clone.call(this);
                                return e._hash = this._hash.clone(), e
                            }
                        });
                    t.SHA256 = o._createHelper(l), t.HmacSHA256 = o._createHmacHelper(l)
                }(Math), i.SHA256)
            },
            2404: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t._resetForTesting = t.isPlausibleName = t.extractFormPII = t.getAutoMatchedParams = t.isEnabledForPixel = t.disableForPixel = t.registerPixel = t.AAM_EXCLUDED_PIXEL_IDS = t.MAX_SCANNED_ELEMENTS = void 0;
                const i = n(4654);
                t.MAX_SCANNED_ELEMENTS = 500, t.AAM_EXCLUDED_PIXEL_IDS = new Set(["nve7z", "o9ezl", "nxcql", "o1oqd", "rcduz", "nvgnf", "rcdx3", "rd2g8", "o5sl8", "of6sy", "rd9rc", "nuhro", "rcqm2", "nwf4w", "nuoqf", "rd38e", "rdr3w", "o6q0r", "rc35s", "plut9", "r98yx", "oeq9n", "nxcrn", "rc37l", "on97f"]);
                const r = ["email", "emailaddress", "email_address", "email-address", "useremail", "user_email", "user-email", "emailaddr", "e-mail", "e_mail", "mail"],
                    o = ["phone", "phonenumber", "phone_number", "phone-number", "mobile", "mobilenumber", "mobile_number", "mobile-number", "telephone", "tel", "cellphone", "cell_phone", "cell-phone", "primaryphone", "primary_phone", "contact"],
                    s = ["firstname", "fname", "givenname", "forename", "fn"],
                    a = ["lastname", "lname", "surname", "familyname", "ln"],
                    c = ["fullname", "yourname", "name"],
                    u = ["username", "nickname", "screenname", "displayname", "login", "company", "business", "organization", "organisation", "cardholder", "nameoncard"],
                    l = ["password", "pass", "passwd", "pwd", "ssn", "social", "socialsecurity", "cc", "card", "creditcard", "credit_card", "credit-card", "cvv", "cvc", "cvn", "securitycode", "security_code", "billing", "cardnumber", "card_number", "secret", "token", "otp", "pin", "hidden"],
                    d = new Set(["password", "hidden", "search", "file", "image", "reset", "submit", "button", "range", "color"]),
                    f = new Set(["email"]),
                    _ = new Set(["tel"]),
                    m = new Set(["email"]),
                    p = new Set(["tel", "tel-national", "tel-local"]),
                    h = new Set(["given-name"]),
                    g = new Set(["family-name"]),
                    v = new Set(["name"]),
                    E = /^[\w!#$%&'*+/=?^`{|}~-]+(?:\.[\w!#$%&'*+/=?^`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i,
                    y = /^\+\d{7,15}$/,
                    w = /^[^\d@<>/\\]{1,100}$/,
                    P = ["email_address", "phone_number", "first_name", "last_name"],
                    b = new Set,
                    T = new Set;

                function O(e) {
                    return b.has(e) && !T.has(e) && !t.AAM_EXCLUDED_PIXEL_IDS.has((e || "").toLowerCase())
                }
                t.registerPixel = function(e) {
                    b.add(e)
                }, t.disableForPixel = function(e) {
                    T.add(e)
                }, t.isEnabledForPixel = O, t.getAutoMatchedParams = function(e, t) {
                    if (!O(e)) return {};
                    const n = {},
                        i = I();
                    for (const e of P) i[e] && !t[e] && (n[e] = i[e]);
                    return n
                };

                function A(e) {
                    const t = e.split(/\s+/).filter(e => "" !== e);
                    return t.length > 1 && "webauthn" === t[t.length - 1] && t.pop(), t.length > 0 ? t[t.length - 1] : ""
                }

                function C(e) {
                    const t = t => (e.getAttribute(t) || "").trim().toLowerCase();
                    return {
                        name: t("name"),
                        id: t("id"),
                        placeholder: t("placeholder"),
                        inputType: t("type"),
                        autocomplete: A(t("autocomplete")),
                        value: (e.value || "").trim()
                    }
                }

                function I() {
                    const e = {};
                    let n;
                    try {
                        n = document.querySelectorAll("input, select, textarea")
                    } catch (t) {
                        return e
                    }
                    const i = Math.min(n.length, t.MAX_SCANNED_ELEMENTS);
                    for (let t = 0; t < i && !P.every(t => !!e[t]); t++) {
                        const i = n[t];
                        if (!i.value || "" === i.value.trim()) continue;
                        const r = C(i);
                        if (!L(r)) {
                            if (!e.email_address) {
                                const t = D(r);
                                if (t) {
                                    e.email_address = t;
                                    continue
                                }
                            }
                            if (!e.phone_number) {
                                const t = M(r);
                                if (t) {
                                    e.phone_number = t;
                                    continue
                                }
                            }
                            if (!e.first_name) {
                                const t = j(r, h, s);
                                if (t) {
                                    e.first_name = t;
                                    continue
                                }
                            }
                            if (!e.last_name) {
                                const t = j(r, g, a);
                                if (t) {
                                    e.last_name = t;
                                    continue
                                }
                            }
                            if (!e.first_name && !e.last_name) {
                                const t = R(r);
                                t && (e.first_name = t.first_name, e.last_name = t.last_name)
                            }
                        }
                    }
                    return e
                }

                function S(e, t) {
                    for (const n of t)
                        if (n.length <= 3) {
                            if (e.name === n || e.id === n || e.placeholder === n) return !0
                        } else if (e.name.includes(n) || e.id.includes(n) || e.placeholder.includes(n)) return !0;
                    return !1
                }

                function L(e) {
                    return !!d.has(e.inputType) || S(e, l)
                }

                function D(e) {
                    if (!(f.has(e.inputType) || m.has(e.autocomplete) || S(e, r))) return E.test(e.value) ? k(e.value) : null;
                    const t = k(e.value);
                    return t && E.test(t) ? t : null
                }

                function M(e) {
                    if (!(_.has(e.inputType) || p.has(e.autocomplete) || S(e, o))) return null;
                    const t = function(e) {
                        let t = e.trim();
                        const n = t.startsWith("+");
                        t = t.replace(/\D/g, ""), !n && t.startsWith("00") && (t = t.slice(2));
                        n || 10 !== t.length || "1" === t[0] || (t = "1" + t);
                        return "+" + t
                    }(e.value);
                    return y.test(t) ? t : null
                }

                function x(e) {
                    return e.replace(/[^a-z0-9]/g, "")
                }

                function N(e, t) {
                    const n = [x(e.name), x(e.id), x(e.placeholder)];
                    for (const e of t) {
                        const t = e.length <= 5;
                        for (const i of n)
                            if (t ? i === e : i.includes(e)) return !0
                    }
                    return !1
                }

                function j(e, t, n) {
                    return !(t.has(e.autocomplete) || N(e, n)) || N(e, u) ? null : F(e.value)
                }

                function R(e) {
                    if (!(v.has(e.autocomplete) || N(e, c)) || N(e, u)) return null;
                    const t = F(e.value);
                    if (!t) return null;
                    const n = t.split(/\s+/);
                    return n.length < 2 ? null : {
                        first_name: n[0],
                        last_name: n.slice(1).join(" ")
                    }
                }

                function k(e) {
                    return e.trim().toLowerCase()
                }

                function F(e) {
                    const t = e.trim().toLowerCase();
                    return w.test(t) ? t : null
                }
                t.extractFormPII = I, t.isPlausibleName = function(e) {
                    if ("string" != typeof e) return !1;
                    const t = e.trim();
                    return i.utilities.isSha256Hash(t) || w.test(t)
                }, t._resetForTesting = function() {
                    b.clear(), T.clear()
                }
            },
            6527: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.UWT = t.SET = t.OneTag = void 0;
                const s = o(n(6057)),
                    a = o(n(510));
                t.OneTag = a;
                const c = o(n(3324));
                t.SET = c;
                const u = o(n(1454));
                t.UWT = u;
                const l = {
                    track: s.track_DEPRECATED,
                    trackPid: c.trackPid,
                    buildPixel: s.buildPixel_DEPRECATED,
                    buildScript: s.buildScript_DEPRECATED,
                    buildIframe: s.buildIframe_DEPRECATED
                };
                t.default = l
            },
            6057: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.track_DEPRECATED = t.buildScript_DEPRECATED = t.buildPixel_DEPRECATED = t.buildIframe_DEPRECATED = void 0;
                const s = o(n(1952)),
                    a = o(n(8352)),
                    c = o(n(3257)),
                    u = n(4654);
                t.track_DEPRECATED = (e, t, n) => {
                    if (!e) throw new Error(u.utilities.LogPrefix + ": Cannot track event without pixel ID");
                    if (!t) throw new Error(u.utilities.LogPrefix + ": Cannot track event without event name");
                    const i = new s.AccountParams({
                            merch_id: e
                        }),
                        r = new s.EventParams(Object.assign({
                            merch_id: e,
                            events: t,
                            eci: u.utilities.EventCodeImpl.DEPRECATED_TRACK
                        }, n ? {
                            value: n.toString()
                        } : {}));
                    c.track({
                        accountParams: i,
                        eventParams: r,
                        adsApiVersion: u.utilities.AdsApiVersion.v0
                    })
                };
                t.buildPixel_DEPRECATED = e => {
                    a.buildImagePixel(u.utilities.addQueries(e, {
                        bci: s.globalParams.get().bci,
                        eci: u.utilities.EventCodeImpl.DEPRECATED_BUILD_PIXEL
                    }))
                };
                t.buildScript_DEPRECATED = e => {
                    a.buildScriptPixel(u.utilities.addQueries(e, {
                        bci: s.globalParams.get().bci,
                        eci: u.utilities.EventCodeImpl.DEPRECATED_BUILD_SCRIPT
                    }))
                };
                t.buildIframe_DEPRECATED = e => {
                    a.buildIFramePixel(u.utilities.addQueries(e, {
                        bci: s.globalParams.get().bci,
                        eci: u.utilities.EventCodeImpl.DEPRECATED_BUILD_IFRAME
                    }))
                }
            },
            510: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.set = t.event = t.config = void 0;
                const s = o(n(2404)),
                    a = o(n(7939)),
                    c = o(n(9115)),
                    u = o(n(7686)),
                    l = o(n(2243)),
                    d = o(n(1952)),
                    f = o(n(3257)),
                    _ = n(4654),
                    m = o(n(1454)),
                    p = {};
                t.set = (e = {}, t, n) => {
                    if ("string" == typeof e) return "autoConfig" === e && "false" === t && n && a.disableForPixel(n), "autoAdvancedMatching" === e && "false" === t && n && s.disableForPixel(n), "dataLayerTracking" === e && "false" === t && n && c.disableForPixel(n), void("autoDwellTracking" === e && "false" === t && n && u.disableForPixel(n));
                    d.globalParams.set(e || {})
                };
                t.config = (e, t = {}) => {
                    if (!e || "string" != typeof e) throw new Error(_.utilities.LogPrefix + ": Config is missing required Advertiser Id");
                    t = t && _.utilities.isObject(t) ? t : {};
                    const n = p[e] = new d.AccountParams(Object.assign(Object.assign({}, t), {
                        txn_id: e
                    }));
                    f.init(n), d.globalParams.calledConfig();
                    const [i, r] = _.utilities.splitObjectByPropNames(t, d.NonEventParameterKeys), o = new d.EventParams(Object.assign(Object.assign({}, i), {
                        txn_id: e,
                        event: JSON.stringify(r),
                        eci: _.utilities.EventCodeImpl.ONETAG_CONFIG
                    }));
                    f.track({
                        accountParams: n,
                        eventParams: o,
                        adsApiVersion: _.utilities.AdsApiVersion.v1,
                        forceAsync: !0
                    }), m.setDefaultAccountParams(e), _.utilities.enableExperimentOverrideForPixel(e), a.registerPixel(e), s.registerPixel(e), "restrict_optimization" === String(t.restricted_data_use || "").toLowerCase() && s.disableForPixel(e), c.registerPixel(e), u.registerPixel(e), l.registerPixel(e)
                };
                t.event = (e, t = {}) => {
                    if (!e) throw new Error(_.utilities.LogPrefix + ": Event cannot send event without an Event Code Id");
                    t = t && _.utilities.isObject(t) ? t : {};
                    const [n, i] = _.utilities.parseEventCodeId(e);
                    let r;
                    n && (r = p[n] || new d.AccountParams({
                        txn_id: n
                    }), f.init(r));
                    const [o, s] = _.utilities.splitObjectByPropNames(t, d.NonEventParameterKeys), a = new d.EventParams(Object.assign(Object.assign({}, o), {
                        txn_id: e,
                        event: JSON.stringify(s),
                        eci: _.utilities.EventCodeImpl.ONETAG_EVENT
                    }));
                    f.track({
                        accountParams: r,
                        eventParams: a,
                        adsApiVersion: _.utilities.AdsApiVersion.v1
                    })
                }
            },
            3324: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.trackPid = void 0;
                const s = o(n(1952)),
                    a = o(n(3257)),
                    c = n(4654);
                t.trackPid = (e, t = {}) => {
                    if (!e) throw new Error(c.utilities.LogPrefix + ": No Pixel ID Found");
                    t = t || {};
                    const n = new s.AccountParams({
                            txn_id: e
                        }),
                        i = new s.EventParams(Object.assign(Object.assign(Object.assign({}, c.utilities.getLegacyParams(t)), t), {
                            txn_id: e,
                            eci: c.utilities.EventCodeImpl.SET_TRACK_PID
                        }));
                    a.track({
                        accountParams: n,
                        eventParams: i,
                        adsApiVersion: c.utilities.AdsApiVersion.v0,
                        forceAsync: !0
                    })
                }
            },
            1454: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.track = t.setDefaultAccountParams = t.init = t.defaultAccountParams = void 0;
                const s = o(n(2404)),
                    a = o(n(7939)),
                    c = o(n(9115)),
                    u = o(n(7686)),
                    l = o(n(2243)),
                    d = o(n(1952)),
                    f = o(n(3257)),
                    _ = n(4654);
                let m;
                t.defaultAccountParams = m;
                const p = e => {
                    t.defaultAccountParams = m = new d.AccountParams({
                        txn_id: e
                    }), f.init(m)
                };
                t.setDefaultAccountParams = p;
                t.init = e => {
                    if (!e || "string" != typeof e) throw new Error(_.utilities.LogPrefix + ": Init is missing required Pixel Id");
                    p(e), d.globalParams.calledInit(), _.utilities.enableExperimentOverrideForPixel(e), a.registerPixel(e), s.registerPixel(e), c.registerPixel(e), u.registerPixel(e), l.registerPixel(e)
                };
                t.track = (e, t = {}) => {
                    if (!e || "string" != typeof e) throw new Error(_.utilities.LogPrefix + ": Track is missing required event name");
                    if (!m.getPixelId()) throw new Error(_.utilities.LogPrefix + ": No Pixel ID Found");
                    t = t && _.utilities.isObject(t) ? t : {}, e = e.trim().toLowerCase();
                    const [n, i] = _.utilities.splitObjectByPropNames(t, d.NonEventParameterKeys), r = new d.EventParams(Object.assign(Object.assign(Object.assign({}, n), _.utilities.getLegacyParams(t)), {
                        txn_id: m.getPixelId(),
                        events: JSON.stringify([
                            [e, i]
                        ]),
                        eci: _.utilities.EventCodeImpl.UWT_TRACK
                    }));
                    f.track({
                        accountParams: m,
                        eventParams: r,
                        adsApiVersion: _.utilities.AdsApiVersion.v0
                    })
                }
            },
            7939: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t._resetForTesting = t.registerPixel = t.disableForPixel = t.MAX_EVENTS_PER_PAGE = t.THROTTLE_MS = void 0;
                const s = o(n(1952)),
                    a = o(n(3257)),
                    c = n(4654);
                t.THROTTLE_MS = 1e3, t.MAX_EVENTS_PER_PAGE = 10;
                const u = new Set,
                    l = new Set;
                let d = !1,
                    f = 0,
                    _ = 0;

                function m(e) {
                    if (_ >= t.MAX_EVENTS_PER_PAGE) return void h();
                    const n = Date.now();
                    if (n - f < t.THROTTLE_MS) return;
                    const i = function(e) {
                        var t;
                        let n = e,
                            i = 0;
                        for (; n && i < 10;) {
                            const e = n.tagName;
                            if ("BUTTON" === e) return n;
                            if ("INPUT" === e) {
                                const e = null === (t = n.type) || void 0 === t ? void 0 : t.toLowerCase();
                                if ("button" === e || "submit" === e || "reset" === e) return n
                            }
                            n = n.parentElement, i++
                        }
                        return null
                    }(e.target);
                    if (!i) return;
                    const r = function(e) {
                        let t = "";
                        return t = e instanceof HTMLInputElement ? e.value || "" : e.innerText || e.textContent || "", t = t.trim().replace(/\s+/g, " "), t.length > 200 && (t = t.slice(0, 200)), t
                    }(i);
                    if (!r || 0 === r.length) return;
                    if (! function(e) {
                            for (let t = 0; t < e.length; t++) {
                                const n = e.charCodeAt(t);
                                if (n >= 65 && n <= 90 || n >= 97 && n <= 122) return !0
                            }
                            return !1
                        }(r)) return;
                    f = n, _++;
                    let o = {
                        value: r
                    };
                    u.forEach(e => {
                        if (l.has(e)) return;
                        const t = new s.AccountParams({
                                txn_id: e
                            }),
                            [n, i] = c.utilities.splitObjectByPropNames(o, s.NonEventParameterKeys),
                            r = new s.EventParams(Object.assign(Object.assign({}, n), {
                                txn_id: e,
                                events: JSON.stringify([
                                    ["autobuttonclick", i]
                                ]),
                                eci: c.utilities.EventCodeImpl.UWT_TRACK
                            }));
                        a.track({
                            accountParams: t,
                            eventParams: r,
                            adsApiVersion: c.utilities.AdsApiVersion.v0
                        })
                    }), _ >= t.MAX_EVENTS_PER_PAGE && h()
                }
                t.disableForPixel = function(e) {
                    l.add(e)
                }, t.registerPixel = function(e) {
                    u.add(e), !d && function() {
                        for (const e of u)
                            if (!l.has(e)) return !0;
                        return !1
                    }() && (d = !0, document.addEventListener("click", m, p))
                };
                const p = {
                    capture: !0,
                    once: !1,
                    passive: !0
                };

                function h() {
                    if (d) {
                        d = !1;
                        try {
                            document.removeEventListener("click", m, p)
                        } catch (e) {}
                    }
                }
                t._resetForTesting = function() {
                    u.clear(), l.clear(), f = 0, _ = 0, h()
                }
            },
            9115: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t._getEventCount = t._resetForTesting = t.ALLOWED_EVENTS = t.enqueueCurrentDataLayer = t.hookDataLayerPush = t.interceptDataLayer = t.tryProxyDataLayer = t.isEnabledForPixel = t.disableForPixel = t.registerPixel = t.MAX_EVENTS_PER_PAGE = void 0;
                const s = o(n(2404)),
                    a = o(n(1952)),
                    c = o(n(3257)),
                    u = n(4654);
                t.MAX_EVENTS_PER_PAGE = 100;
                const l = new Set,
                    d = new Set;
                let f = !1;
                const _ = new WeakSet;
                let m, p = 0;

                function h() {
                    for (const e of l)
                        if (!d.has(e)) return !0;
                    return !1
                }

                function g() {
                    try {
                        return Array.isArray(window.dataLayer)
                    } catch (e) {
                        return !1
                    }
                }

                function v() {
                    g() ? E() : setTimeout(() => {
                        g() && E()
                    }, 3e3)
                }

                function E() {
                    f || (y(), P())
                }

                function y() {
                    if (f) return;
                    const e = window;
                    let t;
                    try {
                        t = e.dataLayer
                    } catch (e) {
                        return
                    }
                    if (Array.isArray(t)) {
                        f = !0, m = t, w(m);
                        try {
                            Object.defineProperty(e, "dataLayer", {
                                configurable: !0,
                                enumerable: !0,
                                get: () => m,
                                set(e) {
                                    m = e, Array.isArray(e) && w(m)
                                }
                            })
                        } catch (e) {
                            w(m)
                        }
                    }
                }

                function w(e) {
                    if (!Array.isArray(e)) return;
                    if (_.has(e)) return;
                    const t = e.push.bind(e),
                        n = Object.getOwnPropertyDescriptor(e, "push");
                    if (!n || n.writable) e.push = function(...e) {
                        const n = t(...e);
                        return e.forEach(e => {
                            b(e, {
                                path: "dataLayer.push",
                                source: "push"
                            })
                        }), n
                    };
                    else if (n.configurable) {
                        let i = t;
                        Object.defineProperty(e, "push", {
                            configurable: !0,
                            enumerable: n.enumerable,
                            get: () => function(...e) {
                                const t = i(...e);
                                return e.forEach(e => {
                                    b(e, {
                                        path: "dataLayer.push",
                                        source: "push"
                                    })
                                }), t
                            },
                            set(e) {
                                i = e
                            }
                        })
                    }
                    _.add(e)
                }

                function P() {
                    const e = m;
                    if (Array.isArray(e))
                        for (let t = 0; t < e.length; t++) {
                            const n = e[t];
                            Array.isArray(n) ? b(n, {
                                path: `dataLayer[${t}]`,
                                source: "initial"
                            }) : n && "object" == typeof n && b(n, {
                                path: "dataLayer",
                                source: "initial"
                            })
                        }
                }

                function b(e, n) {
                    if (!e || "object" != typeof e) return;
                    let i = "",
                        r = {};
                    if (function(e) {
                            if (Array.isArray(e)) return !0;
                            if (e && "object" == typeof e && "number" == typeof e.length && e.length >= 0) return 0 === e.length || 0 in e;
                            return !1
                        }(e)) {
                        const t = e[0];
                        if ("consent" === t) return;
                        if ("set" === t && e[1] && "object" == typeof e[1]) return void z(e[1], n);
                        if ("config" === t && "string" == typeof e[1]) {
                            return void z(e[2] && "object" == typeof e[2] ? e[2] : {}, n)
                        }
                        "event" === t && "string" == typeof e[1] && (i = e[1], r = e[2] && "object" == typeof e[2] ? e[2] : {})
                    } else "string" == typeof e.event && (i = e.event, r = e);
                    if (!i) return;
                    if (p >= t.MAX_EVENTS_PER_PAGE) return;
                    if (! function(e) {
                            return t.ALLOWED_EVENTS.has(e.trim().toLowerCase())
                        }(i)) return;
                    ! function(e, n, i) {
                        var r, o;
                        if (!h()) return;
                        if (p >= t.MAX_EVENTS_PER_PAGE) return;
                        const s = "gtm_" + e.trim().toLowerCase(),
                            f = {};
                        void 0 !== n.value && (f.value = n.value);
                        n.currency && (f.currency = n.currency);
                        n.contents && (f.contents = n.contents);
                        (n.transactionId || n.orderId) && (f.order_id = n.transactionId || n.orderId);
                        J(n), n.email && (f.email_address = n.email);
                        n.phone && (f.phone_number = n.phone);
                        n.firstName && (f.first_name = n.firstName);
                        n.lastName && (f.last_name = n.lastName);
                        if (i.ecommerce) {
                            const e = i.ecommerce;
                            if (void 0 !== e.value && void 0 === f.value && (f.value = e.value), e.currency && !f.currency && (f.currency = e.currency), e.transaction_id && !f.order_id && (f.order_id = e.transaction_id), e.items && !f.contents && (f.contents = e.items), null === (r = e.purchase) || void 0 === r ? void 0 : r.actionField) {
                                const t = e.purchase.actionField;
                                void 0 !== t.revenue && void 0 === f.value && (f.value = t.revenue), t.id && !f.order_id && (f.order_id = t.id)
                            }(null === (o = e.purchase) || void 0 === o ? void 0 : o.products) && !f.contents && (f.contents = e.purchase.products)
                        }
                        p++, l.forEach(e => {
                            if (d.has(e)) return;
                            const t = new a.AccountParams({
                                    txn_id: e
                                }),
                                [n, i] = u.utilities.splitObjectByPropNames(f, a.NonEventParameterKeys),
                                r = new a.EventParams(Object.assign(Object.assign({}, n), {
                                    txn_id: e,
                                    events: JSON.stringify([
                                        [s, i]
                                    ]),
                                    eci: u.utilities.EventCodeImpl.UWT_TRACK
                                }));
                            c.track({
                                accountParams: t,
                                eventParams: r,
                                adsApiVersion: u.utilities.AdsApiVersion.v0,
                                forceAsync: !0
                            })
                        })
                    }(i, T(r, {
                        depth: 0,
                        path: n.path,
                        source: n.source,
                        budget: {
                            value: 1e3
                        },
                        eventName: i
                    }), r)
                }

                function T(e, t) {
                    const {
                        depth: n,
                        path: i,
                        budget: r
                    } = t, o = {};
                    if (n > 10) return o;
                    if (r.value <= 0) return o;
                    if (!O(e)) return o;
                    try {
                        const a = Object.entries(e);
                        for (const [e, c] of a) {
                            if (r.value--, r.value <= 0) break;
                            const a = i ? `${i}.${e}` : e,
                                u = e.toLowerCase();
                            if (R(u) && G(c) && (o.email = String(c)), k(u) && X(c) && (o.phone = String(c)), V(u) && s.isPlausibleName(c) && (o.firstName = c), B(u) && s.isPlausibleName(c) && (o.lastName = c), W(u, a) && c && (o.transactionId = String(c)), H(u, a) && c && (o.orderId = String(c)), U(u) && q(c) && (o.value = c), K(u) && "string" == typeof c && (o.currency = c.toUpperCase()), $(u) && Array.isArray(c) && (o.contents = A(c)), O(c)) {
                                const e = T(c, Object.assign(Object.assign({}, t), {
                                    depth: n + 1,
                                    path: a
                                }));
                                Object.keys(e).forEach(t => {
                                    void 0 === o[t] && (o[t] = e[t])
                                })
                            }
                        }
                    } catch (e) {}
                    return o
                }

                function O(e) {
                    return !(!e || "object" != typeof e) && (!("undefined" != typeof Node && e instanceof Node) && e !== window)
                }

                function A(e) {
                    var t, n;
                    const i = [];
                    for (const r of e) {
                        if (!r || "object" != typeof r) continue;
                        const e = {},
                            o = null !== (t = r.item_id) && void 0 !== t ? t : r.id;
                        null != o && (e.content_id = String(o));
                        const s = null !== (n = r.item_name) && void 0 !== n ? n : r.name;
                        null != s && (e.content_name = String(s)), Object.keys(e).length > 0 && i.push(e)
                    }
                    return i
                }
                t.registerPixel = function(e) {
                    l.add(e), !f && h() && v()
                }, t.disableForPixel = function(e) {
                    d.add(e)
                }, t.isEnabledForPixel = function(e) {
                    return l.has(e) && !d.has(e)
                }, t.tryProxyDataLayer = v, t.interceptDataLayer = y, t.hookDataLayerPush = w, t.enqueueCurrentDataLayer = P, t.ALLOWED_EVENTS = new Set(["add_to_cart", "purchase", "begin_checkout", "add_payment_info", "login", "search", "sign_up", "share"]);
                const C = ["email", "emailaddress", "email_address", "user_email", "useremail", "sha256_email_address"],
                    I = ["phone", "phonenumber", "phone_number", "telephone", "tel", "mobile", "sha256_phone_number"],
                    S = ["firstname", "givenname", "forename"],
                    L = ["lastname", "surname", "familyname"],
                    D = ["username", "nickname", "screenname", "displayname", "company", "business", "cardholder"],
                    M = ["transaction_id", "transactionid", "order_id", "orderid"],
                    x = ["value", "revenue", "total", "amount", "price"],
                    N = ["currency", "currencycode", "currency_code"],
                    j = ["contents", "products", "items", "content"];

                function R(e) {
                    return C.some(t => e.includes(t))
                }

                function k(e) {
                    return I.some(t => e.includes(t))
                }

                function F(e, t) {
                    const n = e.replace(/[_-]/g, "");
                    return t.some(e => n.includes(e)) && !D.some(e => n.includes(e))
                }

                function V(e) {
                    return F(e, S)
                }

                function B(e) {
                    return F(e, L)
                }

                function W(e, t) {
                    return !!M.some(t => e.includes(t)) || !!t.includes("ecommerce.purchase.actionField.id")
                }

                function H(e, t) {
                    return "id" === e && (t.includes("ecommerce") || t.includes("order"))
                }

                function U(e) {
                    return x.some(t => e === t)
                }

                function K(e) {
                    return N.some(t => e === t)
                }

                function $(e) {
                    return j.some(t => e === t)
                }

                function G(e) {
                    return "string" == typeof e && (e.includes("@") || 64 === e.length && /^[a-f0-9]+$/i.test(e))
                }

                function X(e) {
                    if ("string" != typeof e && "number" != typeof e) return !1;
                    return String(e).replace(/\D/g, "").length >= 7
                }

                function q(e) {
                    return "number" == typeof e || "string" == typeof e && !isNaN(parseFloat(e))
                }

                function z(e, t) {
                    if (!e || "object" != typeof e) return;
                    J(T(e, {
                        depth: 0,
                        path: t.path,
                        source: t.source,
                        budget: {
                            value: 1e3
                        },
                        eventName: ""
                    }))
                }

                function J(e) {
                    const t = a.globalParams.get();
                    e.email && !t.email_address && a.globalParams.set({
                        email_address: e.email
                    }), e.phone && !t.phone_number && a.globalParams.set({
                        phone_number: e.phone
                    }), e.firstName && !t.first_name && a.globalParams.set({
                        first_name: e.firstName
                    }), e.lastName && !t.last_name && a.globalParams.set({
                        last_name: e.lastName
                    })
                }
                t._resetForTesting = function() {
                    l.clear(), d.clear(), f = !1, p = 0, m = void 0
                }, t._getEventCount = function() {
                    return p
                }
            },
            7686: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t._resetForTesting = t.registerPixel = t.disableForPixel = t.DWELL_EVENT_NAME = t.DWELL_THRESHOLD_MS = void 0;
                const s = o(n(1952)),
                    a = o(n(3257)),
                    c = n(4654);
                t.DWELL_THRESHOLD_MS = 1e4, t.DWELL_EVENT_NAME = "auto_long_site_dwell";
                const u = new Set;
                let l = !1,
                    d = !1;

                function f() {
                    d || "undefined" == typeof document || "hidden" === document.visibilityState || (d = !0, function() {
                        for (const e of u)
                            if (!c.foreground.isDisabledForPixel(e)) return !0;
                        return !1
                    }() && u.forEach(e => {
                        if (c.foreground.isDisabledForPixel(e)) return;
                        const n = new s.AccountParams({
                                txn_id: e
                            }),
                            i = new s.EventParams({
                                txn_id: e,
                                events: JSON.stringify([
                                    [t.DWELL_EVENT_NAME, {}]
                                ]),
                                eci: c.utilities.EventCodeImpl.UWT_TRACK
                            });
                        a.track({
                            accountParams: n,
                            eventParams: i,
                            adsApiVersion: c.utilities.AdsApiVersion.v0
                        })
                    }))
                }
                t.disableForPixel = function(e) {
                    c.foreground.disableForPixel(e)
                }, t.registerPixel = function(e) {
                    d || (u.add(e), l || (l = !0, c.foreground.onVisibleThreshold(t.DWELL_THRESHOLD_MS, f)))
                }, t._resetForTesting = function() {
                    c.foreground._resetForTesting(), u.clear(), l = !1, d = !1
                }
            },
            2243: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t._resetForTesting = t.registerPixel = t.MAX_LEAVE_EVENTS_PER_PAGE = t.MAX_HIDDEN_LEAVE_EVENTS_PER_PAGE = t.MIN_ENGAGED_DELTA_AFTER_DWELL_MS = t.MIN_ENGAGED_DELTA_MS = t.LEAVE_EVENT_NAME = void 0;
                const s = n(7686),
                    a = o(n(1952)),
                    c = o(n(3257)),
                    u = n(4654);
                t.LEAVE_EVENT_NAME = "auto_page_leave", t.MIN_ENGAGED_DELTA_MS = 1e3, t.MIN_ENGAGED_DELTA_AFTER_DWELL_MS = 5e3, t.MAX_HIDDEN_LEAVE_EVENTS_PER_PAGE = 3, t.MAX_LEAVE_EVENTS_PER_PAGE = 10;
                const l = new Set;
                let d = !1,
                    f = 0,
                    _ = 0;

                function m(e, n) {
                    if (f >= t.MAX_LEAVE_EVENTS_PER_PAGE) return;
                    if ("hidden" === n && _ >= t.MAX_HIDDEN_LEAVE_EVENTS_PER_PAGE) return;
                    const i = e < s.DWELL_THRESHOLD_MS ? t.MIN_ENGAGED_DELTA_MS : t.MIN_ENGAGED_DELTA_AFTER_DWELL_MS,
                        r = function() {
                            const e = [];
                            return l.forEach(t => {
                                u.foreground.isDisabledForPixel(t) || e.push(t)
                            }), e
                        }().filter(t => e - u.foreground.getReportedMs(t) >= i);
                    0 !== r.length && (f++, "hidden" === n && _++, r.forEach(n => {
                        u.foreground.markReported(n, e);
                        const i = new a.AccountParams({
                                txn_id: n
                            }),
                            r = new a.EventParams({
                                txn_id: n,
                                events: JSON.stringify([
                                    [t.LEAVE_EVENT_NAME, {}]
                                ]),
                                eci: u.utilities.EventCodeImpl.UWT_TRACK
                            });
                        c.track({
                            accountParams: i,
                            eventParams: r,
                            adsApiVersion: u.utilities.AdsApiVersion.v0,
                            unload: !0,
                            analyticsOnly: !0
                        })
                    }))
                }
                t.registerPixel = function(e) {
                    l.add(e), u.foreground.start(), d || (d = !0, u.foreground.onLeave(m))
                }, t._resetForTesting = function() {
                    u.foreground._resetForTesting(), l.clear(), d = !1, f = 0, _ = 0
                }
            },
            1952: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.setLocation = t.setIframe = t.Parameters = t.NonEventParameterKeys = t.merge = t.globalParams = t.GlobalParams = t.EventParams = t.AccountParams = void 0;
                const i = n(4654),
                    r = ["email_address", "phone_number", "external_id", "first_name", "last_name"],
                    o = {
                        first_name: s,
                        last_name: s
                    };

                function s(e) {
                    return null == e ? "" : String(e).trim().toLowerCase()
                }
                const a = ["page_location", "hide_page_location"],
                    c = a.concat(r).concat(["bci", "eci", "event_id", "event", "events", "oct_p_id", "p_id", "p_user_id", "pl_id", "restricted_data_use", "tw_ch_fvl", "tw_ch_model", "tw_ch_pv", "tw_clid_src", "twclid", "tw_document_href", "tw_document_referrer", "tw_engaged_ms", "tw_iframe_status", "tw_session_id", "tw_session_count", "tw_session_start", "tw_order_quantity", "tw_sale_amount", "tw_product_id", "txn_id", "type", "version"]);
                t.NonEventParameterKeys = c;
                class u {
                    constructor(e) {
                        this.paramKVs = {}, this.set(e)
                    }
                    set(e) {
                        const [t, n] = i.utilities.splitObjectByPropNames(e || {}, r), s = {}, a = Object.keys(t);
                        for (let e = 0; e < a.length; e++) {
                            const n = a[e],
                                r = n.trim().toLowerCase(),
                                c = o[r],
                                u = c ? c(t[n]) : t[n];
                            c && "" === u || (s[r] = i.utilities.hashParameter(u))
                        }
                        i.utilities.mergeObjects(this.paramKVs, s, n)
                    }
                    get() {
                        return Object.assign({}, this.paramKVs)
                    }
                    getPixelId() {
                        var e, t;
                        const n = (null === (e = this.paramKVs) || void 0 === e ? void 0 : e.txn_id) || (null === (t = this.paramKVs) || void 0 === t ? void 0 : t.merch_id);
                        if (!n) throw new Error(i.utilities.LogPrefix + ": Pixel Id doesn't exist.");
                        return n
                    }
                }
                t.Parameters = u;
                class l extends u {
                    constructor() {
                        var e;
                        super({
                            pl_id: i.utilities.generatePageLoadId(),
                            type: "javascript",
                            version: "2.4.11",
                            p_id: "Twitter",
                            p_user_id: "0",
                            integration: (null === (e = window.twq) || void 0 === e ? void 0 : e.integration) || "advertiser"
                        }), this.bciLoader = window.twq ? 2 : 1, this.bciCmd = 0
                    }
                    calledInit() {
                        this.bciCmd |= 1
                    }
                    calledConfig() {
                        this.bciCmd |= 2
                    }
                    get() {
                        return Object.assign({
                            bci: this.bciLoader + this.bciCmd
                        }, this.paramKVs)
                    }
                }
                t.GlobalParams = l;
                t.AccountParams = class extends u {
                    constructor(e) {
                        super(e)
                    }
                };
                t.EventParams = class extends u {
                    constructor(e) {
                        super(Object.assign(Object.assign({
                            eci: i.utilities.EventCodeImpl.UNKNOWN
                        }, e), {
                            event_id: i.utilities.generateEventId()
                        }))
                    }
                };
                const d = new l;

                function f() {
                    try {
                        const e = i.environment.getReportingWindow();
                        return e.location.href, e.document.referrer, e
                    } catch (e) {
                        return window
                    }
                }

                function _(e) {
                    const t = i.environment.isInIFrame();
                    e.tw_iframe_status = Number(t).toString();
                    const n = f().document.referrer;
                    "" !== n && (e.tw_document_referrer = n)
                }

                function m(e, t) {
                    t.tw_document_href = f().location.href;
                    const n = e.hide_page_location ? "" : e.page_location;
                    void 0 !== n && (t.tw_document_href = n, t.tw_document_referrer && (t.tw_document_referrer = n))
                }
                t.globalParams = d, t.setIframe = _, t.setLocation = m, t.merge = function({
                    accountParams: e,
                    eventParams: t
                }) {
                    const n = i.utilities.mergeObjects({}, d.get(), (null == e ? void 0 : e.get()) || {}, t.get()),
                        [r, o] = i.utilities.splitObjectByPropNames(n, a);
                    return _(o), m(r, o), o
                }
            },
            8352: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.TWITTER_BASE_POST = t.TWITTER_BASE = t.trackPid = t.TCO_BASE_POST = t.TCO_BASE = t.buildScriptPixel = t.buildImagePixel = t.buildIFramePixel = t.VISIBILITY_TIMEOUT_MS = void 0;
                const i = n(4654);
                t.VISIBILITY_TIMEOUT_MS = 5e3;
                const r = (e = i.utilities.AdsApiVersion.v0) => `https://t.co/${e}/adsct`;
                t.TCO_BASE = r;
                const o = (e = i.utilities.AdsApiVersion.v0) => `https://t.co/${e}/adsctp`;
                t.TCO_BASE_POST = o;
                const s = /^(\S+\.)?x\.com/.test(document.location.host) ? "analytics.x.com" : "analytics.twitter.com",
                    a = (e = i.utilities.AdsApiVersion.v0) => `https://${s}/${e}/adsct`;
                t.TWITTER_BASE = a;
                const c = (e = i.utilities.AdsApiVersion.v0) => `https://${s}/${e}/adsctp`;
                t.TWITTER_BASE_POST = c;
                t.trackPid = (e, t) => {
                    var n, s;
                    const l = null !== (n = (t = Object.assign({
                            adsApiVersion: i.utilities.AdsApiVersion.v1
                        }, t)).unload) && void 0 !== n && n,
                        d = l || null !== (s = t.sync) && void 0 !== s && s;
                    return t.analyticsOnly || u(r(t.adsApiVersion), o(t.adsApiVersion), e, d, l), u(a(t.adsApiVersion), c(t.adsApiVersion), e, d, l)
                };
                const u = async (e, t, n = {}, r = !1, o = !1) => {
                    const s = Object.keys(n).sort();
                    let a = "";
                    for (let e = 0; e < s.length; e++) e > 0 && (a += "&"), a += `${s[e]}=${encodeURIComponent(n[s[e]])}`;
                    r || await i.environment.documentVisible();
                    const c = n.pl_id || "",
                        u = `${e}?${a}`,
                        d = () => {
                            l(u)
                        };
                    if (!i.beacon.sendBeacon(t, c, a, o ? {
                            force: !0,
                            onBlocked: d
                        } : {
                            onBlocked: d
                        })) return l(u)
                };
                t.buildScriptPixel = e => {
                    const t = document.createElement("script");
                    t.src = e, t.setAttribute("type", "text/javascript"), document.body ? document.body.appendChild(t) : document.addEventListener("DOMContentLoaded", () => document.body.appendChild(t))
                };
                t.buildIFramePixel = e => {
                    const t = document.createElement("iframe");
                    t.src = e, t.hidden = !0, document.body ? document.body.appendChild(t) : document.addEventListener("DOMContentLoaded", () => document.body.appendChild(t))
                };
                const l = e => {
                    const t = new Image;
                    t.src = e, t.height = 1, t.width = 1, t.style.display = "none", "fetchPriority" in t && (t.fetchPriority = "high"), document.body ? document.body.appendChild(t) : document.addEventListener("DOMContentLoaded", () => document.body.appendChild(t))
                };
                t.buildImagePixel = l
            },
            3257: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.track = t.init = t._resetClientHintsForTesting = t.CLIENT_HINTS_FIRST_FIRE_WAIT_MS = void 0;
                const s = o(n(2404)),
                    a = o(n(1952)),
                    c = o(n(8352)),
                    u = n(4654),
                    l = o(n(1304));
                t.CLIENT_HINTS_FIRST_FIRE_WAIT_MS = 200;
                let d = !1;
                t._resetClientHintsForTesting = function() {
                    d = !1
                }, t.init = function(e) {
                    try {
                        l.prefetchBatteryInfo(), u.clientHints.prefetchClientHints()
                    } catch (e) {}
                }, t.track = async function({
                    accountParams: e,
                    eventParams: n,
                    adsApiVersion: i,
                    forceAsync: r,
                    unload: o,
                    analyticsOnly: f
                }) {
                    const _ = o || !r;
                    if (_ || await Promise.resolve(), e) {
                        const t = u.twclid.getTwclidParams(e.getPixelId());
                        n.set(t)
                    }
                    const m = u.twpid.getTwpidParams();
                    n.set(m);
                    try {
                        n.set(u.twsid.getSessionParams())
                    } catch (e) {}
                    try {
                        n.set(function(e, t) {
                            var n, i;
                            const r = null !== (n = null == e ? void 0 : e.getPixelId()) && void 0 !== n ? n : String(null !== (i = t.get().txn_id) && void 0 !== i ? i : "");
                            if (u.foreground.isDisabledForPixel(r)) return {};
                            const o = Math.round(u.foreground.getForegroundMs());
                            return u.foreground.markReported(r, o), {
                                tw_engaged_ms: o
                            }
                        }(e, n))
                    } catch (e) {}
                    try {
                        l.prefetchBatteryInfo()
                    } catch (e) {}
                    const p = l.getDeviceSettings();
                    if (n.set(p), e) try {
                        const t = e.getPixelId(),
                            i = u.utilities.mergeObjects({}, a.globalParams.get(), e.get(), n.get());
                        if ("restrict_optimization" !== String(i.restricted_data_use || "").toLowerCase()) {
                            const e = s.getAutoMatchedParams(t, i);
                            Object.keys(e).length > 0 && n.set(e)
                        }
                    } catch (e) {}
                    const h = l.getCachedBatteryInfo();
                    n.set(h);
                    try {
                        u.twclid.saveTwclidIntoCookie()
                    } catch (e) {}
                    try {
                        u.twpid.saveTwpidIntoCookie()
                    } catch (e) {}
                    const g = a.merge({
                            accountParams: e,
                            eventParams: n
                        }),
                        v = {
                            adsApiVersion: i,
                            sync: _
                        };
                    o && (v.unload = !0), f && (v.analyticsOnly = !0);
                    let E = {};
                    try {
                        const e = function(e) {
                            return d || e ? u.clientHints.getClientHintParams() : (d = !0, u.clientHints.awaitClientHints(t.CLIENT_HINTS_FIRST_FIRE_WAIT_MS))
                        }(o);
                        e instanceof Promise ? (E = await e, u.clientHints.isDocumentHidden() && (v.unload = !0, v.sync = !0)) : E = e
                    } catch (e) {}
                    c.trackPid(u.utilities.mergeObjects(g, E), v)
                }
            },
            2345: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                const i = n(6527),
                    r = n(4654);
                ! function() {
                    if (!window.twq) return;
                    const e = window.twq;
                    e.exe = async function(...e) {
                        const [t, ...n] = e;
                        let o;
                        switch (t) {
                            case "init":
                                o = i.UWT.init;
                                break;
                            case "track":
                                o = i.UWT.track;
                                break;
                            case "config":
                                o = i.OneTag.config;
                                break;
                            case "event":
                                o = i.OneTag.event;
                                break;
                            case "set":
                                o = i.OneTag.set
                        }
                        try {
                            "function" == typeof o && await o.apply(null, n)
                        } catch (e) {
                            r.utilities.logError(e)
                        }
                    };
                    for (let t = 0; t < e.queue.length; t++) e.exe.apply(null, e.queue[t])
                }()
            },
            2735: function(e, t, n) {
                "use strict";
                var i = this && this.__importDefault || function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                const r = i(n(6527));
                window.twttr = window.twttr || {}, window.twttr.conversion || (window.twttr.conversion = r.default, n(2345))
            },
            6575: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.Cookies = t.COOKIE_TTL = void 0;
                const i = n(3532);
                t.COOKIE_TTL = 33696e3;
                class r {}
                t.Cookies = r, r.setCookie = (e, t, n = {}) => {
                    if (!e) throw new Error(`${i.LogPrefix} Missing key for ${e} cookie`);
                    if (!t) throw new Error(`${i.LogPrefix} Missing value for ${e} cookie`);
                    const o = `${e}=${encodeURIComponent(t)}${r.convertCookieOptionsToString(n)}`;
                    document.cookie = o
                }, r.getCookie = e => {
                    if (!e) throw new Error(i.LogPrefix + ": getCookie is missing cookieName");
                    const t = e.toLowerCase();
                    let n;
                    for (const e of document.cookie.split(";")) {
                        const i = e.indexOf("=");
                        (-1 === i ? e : e.slice(0, i)).trim().toLowerCase() === t && (n = -1 === i ? "" : e.slice(i + 1).trim())
                    }
                    if (void 0 !== n) try {
                        return decodeURIComponent(n)
                    } catch (e) {
                        return n
                    }
                }, r.convertCookieOptionsToString = e => {
                    if (!e) throw new Error(i.LogPrefix + ": convertCookieOptionsToString is missing options");
                    let t = "";
                    for (const n in e) i.hasOwnPropertyCi(e, n) && ("secure" === n && e[n] ? t += ";" + n : t += `;${n}=${e[n]}`);
                    return i.hasOwnPropertyCi(e, "path") || (t += ";path=/"), t
                }
            },
            7696: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.sendBeacon = t._resetCspBlockedForTesting = t.isBeaconSupported = t.isChrome = t.isInBeaconRollout = t.hashForRollout = t._resetTestModeForTesting = t.isTestModeEnabled = t.TEST_MODE_PARAM = t.BEACON_ROLLOUT_PERCENT = void 0;
                const i = n(3532);
                let r;

                function o() {
                    if (void 0 === r) try {
                        const e = new URLSearchParams(window.location.search);
                        r = "1" === e.get(t.TEST_MODE_PARAM)
                    } catch (e) {
                        r = !1
                    }
                    return r
                }

                function s(e) {
                    let t = 5381;
                    for (let n = 0; n < e.length; n++) t = (t << 5) + t + e.charCodeAt(n) | 0;
                    return Math.abs(t) % 100
                }

                function a(e) {
                    return !!e && (!!i.isExperimentOverrideEnabled() || s(e) < t.BEACON_ROLLOUT_PERCENT)
                }

                function c() {
                    var e;
                    const t = null !== (e = null === navigator || void 0 === navigator ? void 0 : navigator.userAgent) && void 0 !== e ? e : "";
                    return /Chrome\/|Chromium\//.test(t)
                }

                function u() {
                    return "undefined" != typeof navigator && "function" == typeof navigator.sendBeacon
                }
                t.BEACON_ROLLOUT_PERCENT = 100, t.TEST_MODE_PARAM = "_twq_test_mode", t.isTestModeEnabled = o, t._resetTestModeForTesting = function() {
                    r = void 0
                }, t.hashForRollout = s, t.isInBeaconRollout = a, t.isChrome = c, t.isBeaconSupported = u;
                let l = new Set,
                    d = [];
                let f = !1;

                function _(e) {
                    const t = /^https?:\/\/([^/?#:]+)/i.exec(e);
                    return t ? t[1].toLowerCase() : ""
                }

                function m(e) {
                    const t = e;
                    if ("report" === t.disposition) return;
                    const n = t.effectiveDirective || t.violatedDirective || "";
                    if (0 !== n.indexOf("connect-src") && 0 !== n.indexOf("default-src")) return;
                    const i = _(t.blockedURI || "");
                    if (!i) return;
                    l.add(i);
                    const r = d.filter(e => e.host === i);
                    d = d.filter(e => e.host !== i), r.forEach(e => e.onBlocked())
                }
                t._resetCspBlockedForTesting = function() {
                    l = new Set, d = []
                }, t.sendBeacon = function(e, t, n, i) {
                    if (o() || !u()) return !1;
                    if (!(null == i ? void 0 : i.force) && (c() || !a(t))) return !1;
                    const r = _(e);
                    if (l.has(r)) return !1;
                    try {
                        (null == i ? void 0 : i.onBlocked) && function() {
                            if (!f) {
                                f = !0;
                                try {
                                    document.addEventListener("securitypolicyviolation", m)
                                } catch (e) {}
                            }
                        }();
                        const t = new Blob([n], {
                                type: "application/x-www-form-urlencoded"
                            }),
                            o = navigator.sendBeacon(e, t);
                        return o && (null == i ? void 0 : i.onBlocked) && (d.length >= 20 && d.shift(), d.push({
                            host: r,
                            onBlocked: i.onBlocked
                        })), o
                    } catch (e) {
                        return !1
                    }
                }
            },
            4758: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.formatClientHints = t.getClientHints = t._resetClientHintsForTesting = t.isDocumentHidden = t.awaitClientHints = t.getClientHintParams = t.prefetchClientHints = t.MAX_FULL_VERSION_LIST_CHARS = t.MAX_PLATFORM_VERSION_CHARS = t.MAX_MODEL_CHARS = t.CLIENT_HINT_FIELDS = void 0;
                t.CLIENT_HINT_FIELDS = ["model", "platformVersion", "fullVersionList"], t.MAX_MODEL_CHARS = 64, t.MAX_PLATFORM_VERSION_CHARS = 32, t.MAX_FULL_VERSION_LIST_CHARS = 256;
                let n, i = {};

                function r() {
                    return n || (n = s().then(e => (i = e, e))), n
                }

                function o() {
                    try {
                        return "hidden" === document.visibilityState
                    } catch (e) {
                        return !1
                    }
                }
                async function s() {
                    try {
                        const e = navigator.userAgentData;
                        if (!e || "function" != typeof e.getHighEntropyValues) return {};
                        return a(await Promise.race([e.getHighEntropyValues(t.CLIENT_HINT_FIELDS), new Promise((e, t) => setTimeout(() => t(new Error("timeout")), 1e3))]))
                    } catch (e) {
                        return {}
                    }
                }

                function a(e) {
                    const n = {};
                    if (!e || "object" != typeof e) return n;
                    const i = c(e.model);
                    i && (n.tw_ch_model = i.slice(0, t.MAX_MODEL_CHARS));
                    const r = c(e.platformVersion);
                    r && (n.tw_ch_pv = r.slice(0, t.MAX_PLATFORM_VERSION_CHARS));
                    const o = function(e) {
                        if (!Array.isArray(e)) return "";
                        return e.map(e => {
                            const t = c(null == e ? void 0 : e.brand),
                                n = c(null == e ? void 0 : e.version);
                            return t && n ? `${t}/${n}` : ""
                        }).filter(e => "" !== e).join(",")
                    }(e.fullVersionList);
                    return o && (n.tw_ch_fvl = o.slice(0, t.MAX_FULL_VERSION_LIST_CHARS)), n
                }

                function c(e) {
                    return "string" == typeof e ? e.trim() : ""
                }
                t.prefetchClientHints = r, t.getClientHintParams = function() {
                    return i
                }, t.awaitClientHints = function(e) {
                    return new Promise(t => {
                        let n = !1;
                        const s = () => {
                                o() && a()
                            },
                            a = () => {
                                if (!n) {
                                    n = !0, clearTimeout(c);
                                    try {
                                        window.removeEventListener("pagehide", a), document.removeEventListener("visibilitychange", s)
                                    } catch (e) {}
                                    t(i)
                                }
                            },
                            c = setTimeout(a, e);
                        try {
                            window.addEventListener("pagehide", a), document.addEventListener("visibilitychange", s)
                        } catch (e) {}
                        r().then(a, a)
                    })
                }, t.isDocumentHidden = o, t._resetClientHintsForTesting = function() {
                    i = {}, n = void 0
                }, t.getClientHints = s, t.formatClientHints = a
            },
            618: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.isInIFrame = t.getReportingWindow = t.documentVisible = t.contentLoaded = void 0;
                t.contentLoaded = async () => new Promise((e, t) => {
                    "undefined" == typeof document && t(), "complete" !== document.readyState && "interactive" !== document.readyState || e(), document.addEventListener("DOMContentLoaded", () => e())
                });
                t.documentVisible = async () => "hidden" !== document.visibilityState ? Promise.resolve() : new Promise(e => {
                    const t = () => {
                        e(), document.removeEventListener("visibilitychange", t, !1)
                    };
                    document.addEventListener("visibilitychange", t, !1)
                });
                const n = () => window.self !== window.top;
                t.isInIFrame = n;
                t.getReportingWindow = () => {
                    if (n()) try {
                        if (window.top && window.top.location.href) return window.top
                    } catch (e) {}
                    return window
                }
            },
            7344: (e, t) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                class n {
                    constructor(e) {
                        this.json = () => new Promise((e, t) => {
                            try {
                                e(JSON.parse(this.xhr.responseText))
                            } catch (e) {
                                t(e)
                            }
                        }), this.xhr = e, this.status = e.status, this.statusText = e.statusText, this.ok = e.status >= 200 && e.status < 300, this.redirected = e.status >= 300 && e.status < 400
                    }
                }
                t.default = function(e) {
                    const t = new XMLHttpRequest;
                    t.withCredentials = !0, t.timeout = 2e3;
                    const i = new Promise((e, i) => {
                        t.onreadystatechange = () => {
                            if (t.readyState !== XMLHttpRequest.DONE) return;
                            const r = new n(t);
                            r.ok || r.redirected ? e(r) : i(r)
                        }
                    });
                    return t.open("GET", e), t.send(), i
                }
            },
            4620: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t._resetForTesting = t.getReportedMs = t.markReported = t.isDisabledForPixel = t.disableForPixel = t.onLeave = t.onVisibleThreshold = t.getForegroundMs = t.getVisibleMs = t.start = t.IFRAME_FOCUS_POLL_MS = void 0;
                const i = n(618);
                t.IFRAME_FOCUS_POLL_MS = 1e3;
                let r, o, s = !1,
                    a = !1,
                    c = !0,
                    u = !1;
                const l = {
                        total: 0
                    },
                    d = {
                        total: 0
                    },
                    f = [],
                    _ = [],
                    m = new Set,
                    p = new Map;

                function h() {
                    return "undefined" != typeof document && !u && "hidden" !== document.visibilityState
                }

                function g() {
                    try {
                        return "function" != typeof document.hasFocus || document.hasFocus()
                    } catch (e) {
                        return !0
                    }
                }

                function v() {
                    try {
                        const e = document.activeElement;
                        return !!e && "IFRAME" === e.tagName
                    } catch (e) {
                        return !1
                    }
                }

                function E(e, t, n) {
                    t ? void 0 === e.since && (e.since = n) : void 0 !== e.since && (e.total += Math.max(n - e.since, 0), e.since = void 0)
                }

                function y(e, t) {
                    return e.total + (void 0 !== e.since ? Math.max(t - e.since, 0) : 0)
                }

                function w() {
                    f.forEach(e => {
                        void 0 !== e.timeoutId && (clearTimeout(e.timeoutId), e.timeoutId = void 0)
                    })
                }

                function P() {
                    if (w(), void 0 === l.since) return;
                    const e = y(l, Date.now());
                    f.forEach(t => {
                        t.fired || (t.timeoutId = setTimeout(() => {
                            t.timeoutId = void 0, h() && (t.fired = !0, t.callback())
                        }, Math.max(t.ms - e, 0)))
                    })
                }

                function b() {
                    const e = Date.now();
                    E(l, h(), e), E(d, h() && (!a || c), e), P()
                }

                function T(e) {
                    const t = d.total;
                    _.forEach(n => {
                        try {
                            n(t, e)
                        } catch (e) {}
                    })
                }

                function O() {
                    void 0 !== r && (clearTimeout(r), r = void 0)
                }

                function A() {
                    void 0 !== o && (clearInterval(o), o = void 0)
                }

                function C() {
                    void 0 === o && (o = setInterval(() => {
                        c = g(), v() || A(), b()
                    }, t.IFRAME_FOCUS_POLL_MS))
                }

                function I() {
                    b(), h() || T("hidden")
                }

                function S() {
                    O(), u = !0, b(), T("pagehide")
                }

                function L() {
                    v() ? C() : A()
                }

                function D() {
                    O(), u = !1, a && (c = g(), L()), b()
                }

                function M() {
                    O(), c = !0, L(), b()
                }

                function x() {
                    O(), r = setTimeout(() => {
                        r = void 0, v() ? (c = g(), C()) : c = !1, b()
                    }, 0)
                }

                function N() {
                    s || "undefined" == typeof document || (s = !0, a = !i.isInIFrame(), c = !a || g(), document.addEventListener("visibilitychange", I, !1), window.addEventListener("pagehide", S, !1), window.addEventListener("pageshow", D, !1), a && (window.addEventListener("focus", M, !1), window.addEventListener("blur", x, !1), L()), b())
                }
                t.start = N, t.getVisibleMs = function() {
                    return y(l, Date.now())
                }, t.getForegroundMs = function() {
                    return y(d, Date.now())
                }, t.onVisibleThreshold = function(e, t) {
                    f.push({
                        ms: e,
                        callback: t,
                        fired: !1
                    }), N(), P()
                }, t.onLeave = function(e) {
                    _.push(e), N()
                }, t.disableForPixel = function(e) {
                    m.add(e)
                }, t.isDisabledForPixel = function(e) {
                    return m.has(e)
                }, t.markReported = function(e, t) {
                    var n;
                    t > (null !== (n = p.get(e)) && void 0 !== n ? n : 0) && p.set(e, t)
                }, t.getReportedMs = function(e) {
                    var t;
                    return null !== (t = p.get(e)) && void 0 !== t ? t : 0
                }, t._resetForTesting = function() {
                    if (w(), O(), A(), s) try {
                        document.removeEventListener("visibilitychange", I, !1), window.removeEventListener("pagehide", S, !1), window.removeEventListener("pageshow", D, !1), window.removeEventListener("focus", M, !1), window.removeEventListener("blur", x, !1)
                    } catch (e) {}
                    s = !1, a = !1, c = !0, u = !1, l.total = 0, l.since = void 0, d.total = 0, d.since = void 0, f.length = 0, _.length = 0, m.clear(), p.clear()
                }
            },
            4654: function(e, t, n) {
                "use strict";
                var i = this && this.__createBinding || (Object.create ? function(e, t, n, i) {
                        void 0 === i && (i = n), Object.defineProperty(e, i, {
                            enumerable: !0,
                            get: function() {
                                return t[n]
                            }
                        })
                    } : function(e, t, n, i) {
                        void 0 === i && (i = n), e[i] = t[n]
                    }),
                    r = this && this.__setModuleDefault || (Object.create ? function(e, t) {
                        Object.defineProperty(e, "default", {
                            enumerable: !0,
                            value: t
                        })
                    } : function(e, t) {
                        e.default = t
                    }),
                    o = this && this.__importStar || function(e) {
                        if (e && e.__esModule) return e;
                        var t = {};
                        if (null != e)
                            for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && i(t, e, n);
                        return r(t, e), t
                    },
                    s = this && this.__importDefault || function(e) {
                        return e && e.__esModule ? e : {
                            default: e
                        }
                    };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.utilities = t.twsid = t.twpid = t.twclid = t.foreground = t.fetch = t.environment = t.Cookies = t.clientHints = t.beacon = void 0;
                const a = o(n(7696));
                t.beacon = a;
                const c = o(n(4758));
                t.clientHints = c;
                const u = n(6575);
                Object.defineProperty(t, "Cookies", {
                    enumerable: !0,
                    get: function() {
                        return u.Cookies
                    }
                });
                const l = o(n(618));
                t.environment = l;
                const d = s(n(7344));
                t.fetch = d.default;
                const f = o(n(4620));
                t.foreground = f;
                const _ = o(n(8974));
                t.twclid = _;
                const m = o(n(9109));
                t.twpid = m;
                const p = o(n(2405));
                t.twsid = p;
                const h = o(n(3532));
                t.utilities = h
            },
            1304: (e, t) => {
                "use strict";

                function n() {
                    const e = new Float32Array(1),
                        t = new Uint8Array(e.buffer);
                    return e[0] = 1 / 0, e[0] = e[0] - e[0], t[3]
                }

                function i(e) {
                    const t = parseFloat(String(e));
                    return isNaN(t) ? 0 : t
                }

                function r() {
                    var e;
                    try {
                        const t = null === (e = window.Intl) || void 0 === e ? void 0 : e.DateTimeFormat;
                        if (t) {
                            const e = (new t).resolvedOptions().timeZone;
                            if (e) return e
                        }
                        const n = - function() {
                            const e = (new Date).getFullYear();
                            return Math.max(i(new Date(e, 0, 1).getTimezoneOffset()), i(new Date(e, 6, 1).getTimezoneOffset()))
                        }();
                        return `UTC${n>=0?"+":""}${n}`
                    } catch (e) {
                        return ""
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.getBatteryInfo = t._resetBatteryInfoCacheForTesting = t.getCachedBatteryInfo = t.prefetchBatteryInfo = t.getDeviceSettings = t.getTimezone = t.getArchitecture = void 0, t.getArchitecture = n, t.getTimezone = r, t.getDeviceSettings = function() {
                    const e = window.screen || {},
                        t = window.navigator || {},
                        i = n(),
                        o = `${e.width||0}&${e.height||0}`,
                        s = e.colorDepth || 0,
                        a = e.availWidth || 0,
                        u = e.availHeight || 0,
                        l = Array.isArray(t.languages) ? t.languages.join(",") : t.language || "na",
                        d = t.doNotTrack || "na",
                        f = t.maxTouchPoints || 0,
                        _ = t.hardwareConcurrency || 0,
                        m = c("platform"),
                        p = c("vendor"),
                        h = [r(), l, p, m, i, o, _, s, a, u, f, d].join("&");
                    return {
                        dv: h.length < 1e3 ? h : h.slice(0, 1e3) + "&end"
                    }
                };
                let o, s = {};
                async function a() {
                    try {
                        if ("function" != typeof navigator.getBattery) return {};
                        const e = await Promise.race([navigator.getBattery(), new Promise((e, t) => setTimeout(() => t(new Error("timeout")), 1e3))]),
                            t = Math.round(100 * e.level);
                        return {
                            cv: `${t}&${e.charging?1:0}`
                        }
                    } catch (e) {
                        return {}
                    }
                }

                function c(e) {
                    try {
                        return navigator[e] || "na"
                    } catch (e) {
                        return "na"
                    }
                }
                t.prefetchBatteryInfo = function() {
                    return o || (o = a().then(e => (s = e, e))), o
                }, t.getCachedBatteryInfo = function() {
                    return s
                }, t._resetBatteryInfoCacheForTesting = function() {
                    s = {}, o = void 0
                }, t.getBatteryInfo = a
            },
            8974: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.saveTwclidIntoCookie = t.getTwclidParams = t.getTwclid = t.extractTwclid = t.getTwclidFromReferrer = t.getTwclidFromHref = t.getTwclidFromCookie = t.TWCLID_QUERY_PARAM = t.TWCLID_COOKIE_TTL = t.TWCLID_COOKIE_NAME = t.TWCLIDSource = void 0;
                const i = n(6575),
                    r = n(3532);
                var o;
                ! function(e) {
                    e[e.Href = 1] = "Href", e[e.Cookie = 2] = "Cookie", e[e.Referrer = 4] = "Referrer"
                }(o = t.TWCLIDSource || (t.TWCLIDSource = {})), t.TWCLID_COOKIE_NAME = "_twclid", t.TWCLID_COOKIE_TTL = i.COOKIE_TTL, t.TWCLID_QUERY_PARAM = "twclid";
                t.getTwclidFromCookie = () => {
                    try {
                        return JSON.parse(decodeURIComponent(i.Cookies.getCookie(t.TWCLID_COOKIE_NAME) || "")).twclid
                    } catch (e) {
                        return
                    }
                };
                const s = e => {
                    const [n] = e.slice(1).split("&").map(e => e.split("=")).filter(([e, n]) => e === t.TWCLID_QUERY_PARAM);
                    return n && n[1]
                };
                t.getTwclidFromHref = () => s(location.search);
                t.getTwclidFromReferrer = () => {
                    try {
                        const e = document.referrer;
                        if (!e) return;
                        const t = e.split("#")[0].split("?")[1];
                        if (!t) return;
                        return s("?" + t)
                    } catch (e) {
                        return
                    }
                };
                t.extractTwclid = () => {
                    let e = t.getTwclidFromHref();
                    return e ? {
                        twclid: e,
                        source: o.Href
                    } : (e = t.getTwclidFromReferrer(), e ? {
                        twclid: e,
                        source: o.Referrer
                    } : void 0)
                };
                t.getTwclid = e => {
                    const n = t.extractTwclid();
                    if (n) return n;
                    const i = t.getTwclidFromCookie();
                    return i ? {
                        twclid: i,
                        source: o.Cookie
                    } : void 0
                };
                t.getTwclidParams = e => {
                    const n = t.getTwclid(e);
                    return n ? {
                        twclid: n.twclid,
                        tw_clid_src: n.source
                    } : {}
                };
                const a = (e, n) => {
                    const o = {
                            pixelVersion: "2.4.11",
                            timestamp: Date.now().toString(),
                            twclid: e,
                            source: n
                        },
                        s = r.getWildcardDomains(),
                        a = JSON.stringify(o);
                    for (const e of s)
                        if (i.Cookies.setCookie(t.TWCLID_COOKIE_NAME, a, {
                                domain: e,
                                "max-age": t.TWCLID_COOKIE_TTL,
                                secure: !0,
                                samesite: "Strict"
                            }), i.Cookies.getCookie(t.TWCLID_COOKIE_NAME) === a) return !0;
                    return !1
                };
                t.saveTwclidIntoCookie = () => {
                    var e;
                    if (null === (e = window.twq) || void 0 === e ? void 0 : e.dontSetCookie) return;
                    const n = t.extractTwclid();
                    if (!n) return;
                    const i = t.getTwclidFromCookie();
                    n.twclid !== i && (a(n.twclid, n.source), (() => {
                        const e = t.extractTwclid();
                        if (!e) return;
                        const n = () => {
                                t.getTwclidFromCookie() || a(e.twclid, e.source)
                            },
                            i = () => {
                                "hidden" === document.visibilityState && n()
                            };
                        document.addEventListener("visibilitychange", i), setTimeout(n, 5e3);
                        let r = 0;
                        const o = setInterval(() => {
                            r += 1e4, n(), r >= 12e4 && (clearInterval(o), document.removeEventListener("visibilitychange", i))
                        }, 1e4)
                    })())
                }
            },
            9109: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.saveTwpidIntoCookie = t.getTwpidParams = t.getTwpid = t._resetCache = t.getTwpidFromCookie = t.buildTwpidValue = t.generateBrowserId = t.TWPID_COOKIE_TTL = t.TWPID_COOKIE_NAME = t.TWPIDSource = void 0;
                const i = n(6575),
                    r = n(3532);
                var o;
                ! function(e) {
                    e[e.Generated = 1] = "Generated", e[e.Cookie = 2] = "Cookie"
                }(o = t.TWPIDSource || (t.TWPIDSource = {})), t.TWPID_COOKIE_NAME = "_twpid", t.TWPID_COOKIE_TTL = i.COOKIE_TTL;
                t.generateBrowserId = () => {
                    const e = Math.floor(999999e3 * Math.random()),
                        t = Math.floor(999999e3 * Math.random());
                    return e.toString() + t.toString()
                };
                t.buildTwpidValue = () => `tw.${Date.now()}.${t.generateBrowserId()}`;
                let s;
                t.getTwpidFromCookie = () => {
                    try {
                        return i.Cookies.getCookie(t.TWPID_COOKIE_NAME) || void 0
                    } catch (e) {
                        return
                    }
                };
                t._resetCache = () => {
                    s = void 0
                };
                t.getTwpid = () => {
                    if (s) return s;
                    const e = t.getTwpidFromCookie();
                    return s = e ? {
                        twpid: e,
                        source: o.Cookie
                    } : {
                        twpid: t.buildTwpidValue(),
                        source: o.Generated
                    }, s
                };
                t.getTwpidParams = () => {
                    const {
                        twpid: e,
                        source: n
                    } = t.getTwpid();
                    return {
                        twpid: e,
                        tw_pid_src: n
                    }
                };
                t.saveTwpidIntoCookie = () => {
                    var e;
                    if (null === (e = window.twq) || void 0 === e ? void 0 : e.dontSetCookie) return;
                    const n = t.getTwpid();
                    if (n.source === o.Cookie) return;
                    const s = r.getWildcardDomains();
                    for (const e of s) {
                        const r = {
                            domain: e,
                            "max-age": t.TWPID_COOKIE_TTL,
                            secure: !0,
                            samesite: "Strict"
                        };
                        if (i.Cookies.setCookie(t.TWPID_COOKIE_NAME, n.twpid, r), i.Cookies.getCookie(t.TWPID_COOKIE_NAME)) break
                    }
                }
            },
            2405: (e, t, n) => {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.getSessionParams = t.touchSession = t.saveSessionIntoCookie = t.getSessionFromCookie = t.parseRecord = t.serializeRecord = t._resetCache = t.buildSessionId = t.SESSION_INACTIVITY_WINDOW_MS = t.TWSID_COOKIE_TTL = t.TWSID_COOKIE_NAME = void 0;
                const i = n(6575),
                    r = n(3532);
                t.TWSID_COOKIE_NAME = "_twsid", t.TWSID_COOKIE_TTL = i.COOKIE_TTL, t.SESSION_INACTIVITY_WINDOW_MS = 18e5;
                let o;
                t.buildSessionId = e => `${e}-${Math.floor(999999e3*Math.random())}`;
                t._resetCache = () => {
                    o = void 0
                };
                const s = e => !!e && "object" == typeof e && "string" == typeof e.id && e.id.length > 0 && "number" == typeof e.ct && isFinite(e.ct) && e.ct >= 1 && "number" == typeof e.ts && isFinite(e.ts) && e.ts > 0;
                t.serializeRecord = e => [e.id, e.ct, e.ts].join(".");
                t.parseRecord = e => {
                    const t = e.split(".");
                    if (3 !== t.length) return;
                    const n = {
                        id: t[0],
                        ct: Number(t[1]),
                        ts: Number(t[2])
                    };
                    return s(n) ? n : void 0
                };
                t.getSessionFromCookie = () => {
                    try {
                        const e = i.Cookies.getCookie(t.TWSID_COOKIE_NAME);
                        if (!e) return;
                        return "{" === e.charAt(0) ? (e => {
                            try {
                                const t = JSON.parse(e);
                                return s(t) ? t : void 0
                            } catch (e) {
                                return
                            }
                        })(e) : t.parseRecord(e)
                    } catch (e) {
                        return
                    }
                };
                t.saveSessionIntoCookie = e => {
                    var n;
                    if (null === (n = window.twq) || void 0 === n ? void 0 : n.dontSetCookie) return;
                    const o = r.getWildcardDomains(),
                        s = t.serializeRecord(e);
                    for (const e of o) {
                        const n = {
                            domain: e,
                            "max-age": t.TWSID_COOKIE_TTL,
                            secure: !0,
                            samesite: "Strict"
                        };
                        if (i.Cookies.setCookie(t.TWSID_COOKIE_NAME, s, n), i.Cookies.getCookie(t.TWSID_COOKIE_NAME) === s) break
                    }
                };
                t.touchSession = (e = Date.now()) => {
                    const n = t.getSessionFromCookie() || o;
                    let i, r;
                    return n ? e - n.ts > t.SESSION_INACTIVITY_WINDOW_MS ? (i = {
                        id: t.buildSessionId(e),
                        ct: n.ct + 1,
                        ts: e
                    }, r = !0) : (i = Object.assign(Object.assign({}, n), {
                        ts: e
                    }), r = !1) : (i = {
                        id: t.buildSessionId(e),
                        ct: 1,
                        ts: e
                    }, r = !0), o = i, t.saveSessionIntoCookie(i), {
                        record: i,
                        isStart: r
                    }
                };
                t.getSessionParams = () => {
                    const {
                        record: e,
                        isStart: n
                    } = t.touchSession();
                    return Object.assign({
                        tw_session_id: e.id,
                        tw_session_count: e.ct
                    }, n ? {
                        tw_session_start: "1"
                    } : {})
                }
            },
            3532: function(e, t, n) {
                "use strict";
                var i = this && this.__importDefault || function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                };
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.splitObjectByPropNames = t.splitObjectBy = t.parseEventCodeId = t.mergeObjects = t.logError = t.isObject = t.hashParameter = t.isSha256Hash = t.hasOwnPropertyCi = t.generatePageLoadId = t.generateEventId = t.getWildcardDomains = t.getPropertyCi = t.getLegacyParams = t._resetExperimentOverrideForTesting = t.isExperimentOverrideEnabled = t.enableExperimentOverrideForPixel = t.addQueries = t.LogPrefix = t.EventCodeImpl = t.AdsApiVersion = void 0;
                const r = i(n(7219));

                function o() {
                    if ("undefined" != typeof crypto && "function" == typeof crypto.randomUUID) return crypto.randomUUID();
                    const e = new Uint8Array(16);
                    crypto.getRandomValues(e), e[6] = 15 & e[6] | 64, e[8] = 63 & e[8] | 128;
                    const t = Array.from(e, e => e.toString(16).padStart(2, "0")).join("");
                    return `${t.slice(0,8)}-${t.slice(8,12)}-${t.slice(12,16)}-${t.slice(16,20)}-${t.slice(20)}`
                }! function(e) {
                    e.v0 = "i", e.v1 = "1/i"
                }(t.AdsApiVersion || (t.AdsApiVersion = {})),
                function(e) {
                    e[e.UNKNOWN = 0] = "UNKNOWN", e[e.SET_TRACK_PID = 1] = "SET_TRACK_PID", e[e.UWT_TRACK = 2] = "UWT_TRACK", e[e.ONETAG_CONFIG = 3] = "ONETAG_CONFIG", e[e.ONETAG_EVENT = 4] = "ONETAG_EVENT", e[e.DEPRECATED_TRACK = 5] = "DEPRECATED_TRACK", e[e.DEPRECATED_BUILD_PIXEL = 6] = "DEPRECATED_BUILD_PIXEL", e[e.DEPRECATED_BUILD_SCRIPT = 7] = "DEPRECATED_BUILD_SCRIPT", e[e.DEPRECATED_BUILD_IFRAME = 8] = "DEPRECATED_BUILD_IFRAME"
                }(t.EventCodeImpl || (t.EventCodeImpl = {})), t.LogPrefix = "[Twitter Pixel Tag]", t.addQueries = function(e, t) {
                    const n = document.createElement("a");
                    n.href = e;
                    const i = n.origin,
                        r = n.pathname,
                        o = n.search,
                        s = n.hash,
                        a = o.slice(1).split("&").map(e => e.split("=")).reduce((e, [t, n]) => Object.assign({
                            [t]: n
                        }, e), Object.assign({}, t));
                    return `${i}${r}?${Object.keys(a).sort().map(e=>`${e}=${e in t?encodeURIComponent(a[e]):a[e]}`).join("&")}${s}`
                };
                const s = new Set(["oh71u", "oka17"]);
                let a = !1;
                t.enableExperimentOverrideForPixel = function(e) {
                    s.has(e) && (a = !0)
                }, t.isExperimentOverrideEnabled = function() {
                    return a
                }, t._resetExperimentOverrideForTesting = function() {
                    a = !1
                };

                function c(e, t) {
                    const n = t.toLowerCase();
                    for (const t in e)
                        if (t.toLowerCase() === n && e.hasOwnProperty(t)) return e[t]
                }
                t.getLegacyParams = e => {
                    if (!d(e)) return {};
                    const t = {
                        tw_sale_amount: c(e, "tw_sale_amount") || 0,
                        tw_order_quantity: c(e, "tw_order_quantity") || 0
                    };
                    return delete e.tw_sale_amount, delete e.tw_order_quantity, u(e, "value") && (t.tw_sale_amount = c(e, "value")), u(e, "num_items") && (t.tw_order_quantity = c(e, "num_items")), Array.isArray(c(e, "content_ids")) && (t.tw_product_id = c(e, "content_ids")[0]), u(e, "partner_id") && (t.oct_p_id = c(e, "partner_id")), t
                }, t.getPropertyCi = c;
                t.getWildcardDomains = () => {
                    const e = location.hostname.split("."),
                        t = [];
                    for (let n = 2; n <= e.length; n++) t.push("." + e.slice(-1 * n).join("."));
                    return t
                };
                t.generateEventId = () => o();

                function u(e, t) {
                    const n = t.toLowerCase();
                    for (const t in e)
                        if (t.toLowerCase() === n && e.hasOwnProperty(t)) return !0;
                    return !1
                }

                function l(e) {
                    return "string" == typeof e && 64 === e.length && /^[a-f0-9]+$/i.test(e)
                }

                function d(e) {
                    var t = typeof e;
                    return "function" === t || "object" === t && !!e
                }

                function f(e, t) {
                    e = e || {};
                    const [n, i] = [{}, {}];
                    for (let r in e) t(r, e[r]) ? n[r] = e[r] : i[r] = e[r];
                    return [n, i]
                }
                t.generatePageLoadId = () => o(), t.hasOwnPropertyCi = u, t.isSha256Hash = l, t.hashParameter = function(e) {
                    return "string" == typeof e && l(e) ? e.toLowerCase() : r.default(e).toString()
                }, t.isObject = d, t.logError = function(e) {}, t.mergeObjects = function(...e) {
                    const [t, ...n] = e;
                    return n.forEach(e => {
                        e = e || {}, Object.keys(e).forEach(n => {
                            t[n] = e[n]
                        })
                    }), t
                }, t.parseEventCodeId = function(e) {
                    if ("string" != typeof e) return ["", e];
                    const t = e.toLowerCase().split("-");
                    return 3 !== t.length || "tw" !== t[0] || "" === t[1] || "" === t[2] ? ["", e] : [t[1], t[2]]
                }, t.splitObjectBy = f, t.splitObjectByPropNames = function(e, t) {
                    return f(e, e => t.indexOf(e.trim().toLowerCase()) >= 0)
                }
            },
            2480: () => {}
        },
        t = {};

    function n(i) {
        var r = t[i];
        if (void 0 !== r) return r.exports;
        var o = t[i] = {
            exports: {}
        };
        return e[i].call(o.exports, o, o.exports, n), o.exports
    }
    n.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }();
    (() => {
        "use strict";
        n(2735)
    })()
})();
(function() {
    var n, aa, ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ca(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var da = ca(this),
        ha = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        q = {},
        ia = {};

    function u(a, b, c) {
        if (!c || a != null) {
            c = ia[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function v(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in q ? f = q : f = da;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ha && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ba(q, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ia[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ia[d] = ha ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, ia[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }

    function ja(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function w(a) {
        var b = typeof q.Symbol != "undefined" && u(q.Symbol, "iterator") && a[u(q.Symbol, "iterator")];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: ja(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function ka(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    }

    function la(a) {
        return ma(a, a)
    }

    function ma(a, b) {
        a.raw = b;
        Object.freeze && (Object.freeze(a), Object.freeze(b));
        return a
    }

    function C(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    }
    var na = ha && typeof u(Object, "assign") == "function" ? u(Object, "assign") : function(a, b) {
        if (a == null) throw new TypeError("No nullish arg");
        a = Object(a);
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) C(d, e) && (a[e] = d[e])
        }
        return a
    };
    v("Object.assign", function(a) {
        return a || na
    }, "es6");

    function oa() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    v("globalThis", function(a) {
        return a || da
    }, "es_2020");
    v("Symbol", function(a) {
        function b(f) {
            if (this instanceof b) throw new TypeError("Symbol is not a constructor");
            return new c(d + (f || "") + "_" + e++, f)
        }

        function c(f, g) {
            this.v = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        }
        if (a) return a;
        c.prototype.toString = function() {
            return this.v
        };
        var d = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            e = 0;
        return b
    }, "es6");
    v("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, q.Symbol)("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return qa(ja(this))
            }
        });
        return a
    }, "es6");

    function qa(a) {
        a = {
            next: a
        };
        a[u(q.Symbol, "iterator")] = function() {
            return this
        };
        return a
    }
    v("WeakMap", function(a) {
        function b(g) {
            this.v = (f += Math.random() + 1).toString();
            if (g) {
                g = w(g);
                for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
            }
        }

        function c() {}

        function d(g) {
            var h = typeof g;
            return h === "object" && g !== null || h === "function"
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (k.get(g) != 2 || k.get(h) != 3) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && k.get(h) == 4
                } catch (l) {
                    return !1
                }
            }()) return a;
        var e = "$jscomp_hidden_" + Math.random(),
            f = 0;
        b.prototype.set = function(g, h) {
            if (!d(g)) throw Error("Invalid WeakMap key");
            if (!C(g, e)) {
                var k = new c;
                ba(g, e, {
                    value: k
                })
            }
            if (!C(g, e)) throw Error("WeakMap key fail: " + g);
            g[e][this.v] = h;
            return this
        };
        b.prototype.get = function(g) {
            return d(g) && C(g, e) ? g[e][this.v] : void 0
        };
        b.prototype.has = function(g) {
            return d(g) && C(g, e) && C(g[e], this.v)
        };
        b.prototype.delete = function(g) {
            return d(g) && C(g, e) && C(g[e], this.v) ? delete g[e][this.v] : !1
        };
        return b
    }, "es6");
    v("Map", function(a) {
        function b() {
            var h = {};
            return h.G = h.next = h.head = h
        }

        function c(h, k) {
            var l = h[1];
            return qa(function() {
                if (l) {
                    for (; l.head != h[1];) l = l.G;
                    for (; l.next != l.head;) return l = l.next, {
                        done: !1,
                        value: k(l)
                    };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        }

        function d(h, k) {
            var l = k && typeof k;
            l == "object" || l == "function" ? f.has(k) ? l = f.get(k) : (l = "" + ++g, f.set(k, l)) : l = "p_" + k;
            var m = h[0][l];
            if (m && C(h[0], l))
                for (h = 0; h < m.length; h++) {
                    var p = m[h];
                    if (k !== k && p.key !== p.key || k === p.key) return {
                        id: l,
                        list: m,
                        index: h,
                        entry: p
                    }
                }
            return {
                id: l,
                list: m,
                index: -1,
                entry: void 0
            }
        }

        function e(h) {
            this[0] = {};
            this[1] = b();
            this.size = 0;
            if (h) {
                h = w(h);
                for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        }
        if (function() {
                if (!a || typeof a != "function" || !u(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(w([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = u(k, "entries").call(k),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done ||
                        m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (p) {
                    return !1
                }
            }()) return a;
        var f = new q.WeakMap;
        e.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                G: this[1].G,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].G.next = l.entry, this[1].G = l.entry, this.size++);
            return this
        };
        e.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id],
                h.entry.G.next = h.entry.next, h.entry.next.G = h.entry.G, h.entry.head = null, this.size--, !0) : !1
        };
        e.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].G = b();
            this.size = 0
        };
        e.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        e.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        e.prototype.entries = function() {
            return c(this, function(h) {
                return [h.key, h.value]
            })
        };
        e.prototype.keys = function() {
            return c(this, function(h) {
                return h.key
            })
        };
        e.prototype.values = function() {
            return c(this, function(h) {
                return h.value
            })
        };
        e.prototype.forEach = function(h, k) {
            for (var l = u(this, "entries").call(this), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
        };
        e.prototype[u(q.Symbol, "iterator")] = u(e.prototype, "entries");
        var g = 0;
        return e
    }, "es6");

    function sa(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[u(q.Symbol, "iterator")] = function() {
            return e
        };
        return e
    }
    v("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return sa(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    v("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return sa(this, function(b) {
                return b
            })
        }
    }, "es6");
    v("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) C(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    v("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    v("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || u(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    v("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            if (this == null) throw new TypeError("The 'this' value for String.prototype.includes must not be null or undefined");
            if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.includes must not be a regular expression");
            return this.indexOf(b, c || 0) !== -1
        }
    }, "es6");
    v("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) C(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    v("Array.prototype.values", function(a) {
        return a ? a : function() {
            return sa(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    v("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    }, "es6");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var ta = this || self;

    function ua(a) {
        a = parseFloat(a);
        return isNaN(a) || a > 1 || a < 0 ? 0 : a
    };

    function xa(a) {
        xa[" "](a);
        return a
    }
    xa[" "] = function() {};

    function ya(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    xa(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    };

    function za(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };

    function Aa() {
        var a = ta.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Ba = q.globalThis.trustedTypes,
        Ca;

    function Da() {
        var a = null;
        if (!Ba) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Ba.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function Ea() {
        Ca === void 0 && (Ca = Da());
        return Ca
    };

    function Fa(a) {
        this.v = a
    }
    Fa.prototype.toString = function() {
        return this.v + ""
    };

    function Ga(a) {
        var b = Ea();
        a = b ? b.createScriptURL(a) : a;
        return new Fa(a)
    }

    function Ha(a) {
        if (a instanceof Fa) return a.v;
        throw Error("");
    };
    var Ia = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Ja(a) {
        this.v = a
    }
    Ja.prototype.toString = function() {
        return this.v + ""
    };

    function La(a) {
        var b = Ea();
        a = b ? b.createHTML(a) : a;
        return new Ja(a)
    }

    function Ma(a) {
        if (a instanceof Ja) return a.v;
        throw Error("");
    };

    function Na(a, b) {
        a.src = Ha(b);
        var c;
        b = a.ownerDocument;
        b = b === void 0 ? document : b;
        var d;
        b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
        (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", c)
    };
    var Oa = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };

    function Pa(a, b) {
        a.write(Ma(b))
    };
    var Qa = za(function() {
        return Aa().indexOf("MSIE") != -1
    });

    function Ra(a) {
        return Aa().indexOf(a) != -1
    }
    var Sa = za(function() {
        var a = Math.random;
        return ["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"].some(Ra) || a() < 1E-4
    });

    function Ta(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Ua() {
        if (!q.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            q.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };

    function Va(a) {
        return a instanceof Ja ? a : La(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
    }

    function Wa(a) {
        return Xa(a)
    }

    function Xa(a) {
        var b = Va("");
        return La(a.map(function(c) {
            return Ma(Va(c))
        }).join(Ma(b).toString()))
    }
    var Ya = /^[a-z][a-z\d-]*$/i,
        Za = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" "),
        $a = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" "),
        ab = ["action", "formaction", "href"];

    function bb(a) {
        var b;
        if (!Ya.test("span")) throw Error("");
        if (Za.indexOf("SPAN") !== -1) throw Error("");
        var c = "<span";
        a && (c += db(a));
        Array.isArray(b) || (b = b === void 0 ? [] : [b]);
        $a.indexOf("SPAN") !== -1 ? c += ">" : (a = Wa(b.map(function(d) {
            return d instanceof Ja ? d : Va(String(d))
        })), c += ">" + a.toString() + "</span>");
        return La(c)
    }

    function db(a) {
        for (var b = "", c = u(Object, "keys").call(Object, a), d = 0; d < c.length; d++) {
            var e = c[d],
                f = a[e];
            if (!Ya.test(e)) throw Error("");
            if (f !== void 0 && f !== null) {
                if (/^on./i.test(e)) throw Error("");
                ab.indexOf(e.toLowerCase()) !== -1 && (f = String(f), f = Ia.test(f) ? f : void 0, f = f || "about:invalid#zClosurez");
                e = e + '="' + Va(String(f)) + '"';
                b += " " + e
            }
        }
        return b
    };

    function eb(a) {
        var b = oa.apply(1, arguments);
        if (b.length === 0) return Ga(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Ga(c)
    }

    function fb(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(function(k) {
                return e(k, h)
            }) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = u(Object, "entries").call(Object, d));
        Array.isArray(d) ? d.forEach(function(g) {
            return e(g[1], g[0])
        }) : d.forEach(e);
        return Ga(a + b + c)
    };

    function gb(a) {
        return /^true$/.test(a)
    }

    function hb(a, b) {
        if (!a || !b.head) return null;
        var c = ib("META");
        b.head.appendChild(c);
        c.httpEquiv = "origin-trial";
        c.content = a;
        return c
    }

    function ib(a, b) {
        b = b === void 0 ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    var jb = ua("0.20"),
        kb = ua("0.002"),
        lb = ua("1.0"),
        mb = ua("1.0"),
        nb = ua("1.0"),
        ob = ua("0.00"),
        pb = ua("0.00"),
        qb = gb("false"),
        rb = gb("true"),
        sb = gb("true"),
        tb = gb("true"),
        ub = gb("true"),
        vb = gb("true");
    var wb = null;

    function xb(a) {
        a = a === void 0 ? window : a;
        if (wb === null) {
            wb = "";
            try {
                var b = "";
                try {
                    b = a.top.location.hash
                } catch (d) {
                    b = a.location.hash
                }
                if (b) {
                    var c = b.match(/\bdeid=([\d,]+)/);
                    wb = c ? c[1] : ""
                }
            } catch (d) {}
        }
        return wb
    }

    function G(a, b, c) {
        var d = H;
        if (c ? d.v.hasOwnProperty(c) && d.v[c] === "" : 1) {
            var e = e === void 0 ? ta : e;
            e = (e = xb(e)) ? (e = e.match(new RegExp("\\b(" + a.join("|") + ")\\b"))) ? e[0] : null : null;
            if (e) a = e;
            else a: {
                if (!Qa() && !Sa() && (e = Math.random(), e < b)) {
                    e = Ua();
                    a = a[Math.floor(e * a.length)];
                    break a
                }
                a = null
            }
            a && a !== "" && (c ? d.v.hasOwnProperty(c) && (d.v[c] = a) : d.Z[a] = !0)
        }
    }

    function I(a) {
        var b = H;
        return b.v.hasOwnProperty(a) ? b.v[a] : ""
    }

    function yb() {
        var a = H,
            b = [];
        Ta(a.Z, function(c, d) {
            b.push(d)
        });
        Ta(a.v, function(c) {
            c !== "" && b.push(c)
        });
        return b
    };
    var zb = {
            ya: 2,
            Fa: 13,
            Ea: 14,
            Ba: 16,
            Aa: 17,
            za: 18,
            xa: 19,
            Ha: 20,
            Ga: 21,
            wa: 22,
            sa: 23
        },
        H = null;

    function Ab() {
        return !!H && (I(20) == "466465926" || I(20) == "466465925")
    }

    function Bb() {
        return !!H && I(16) == "592230571"
    }

    function Cb() {
        return !!H && (I(22) == "512247839" || I(22) == "512247838")
    };

    function Db(a) {
        var b = b === void 0 ? ta : b;
        var c, d;
        return ((c = b.performance) == null ? void 0 : (d = c.timing) == null ? void 0 : d[a]) || 0
    };

    function Eb() {
        var a = Fb,
            b = "S";
        if (a.S && a.hasOwnProperty(b)) return a.S;
        b = new a;
        return a.S = b
    };
    var Gb = {
        Ca: 0,
        ta: 1,
        Da: 2,
        va: 3,
        ua: 4
    };

    function Fb() {
        this.v = {}
    }

    function Hb(a, b, c) {
        typeof c === "number" && c > 0 && (a.v[b] = Math.round(c))
    }

    function Jb(a) {
        var b = Eb();
        var c = c === void 0 ? ta : c;
        c = c.performance;
        Hb(b, a, c && c.now ? c.now() : null)
    }

    function Kb() {
        function a() {
            return Hb(b, 0, Db("loadEventStart") - Db("navigationStart"))
        }
        var b = Eb();
        Db("loadEventStart") != 0 ? a() : window.addEventListener("load", a)
    }

    function Lb() {
        var a = Eb();
        return u(Object, "values").call(Object, Gb).map(function(b) {
            return [b, a.v[b] || 0]
        })
    };
    var Mb = gb("false");

    function Nb(a) {
        return typeof a === "function"
    }

    function Pb(a) {
        return typeof a === "string"
    }

    function Qb(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function Rb() {
        return (new Date(Date.now())).getTime()
    }

    function Sb(a, b) {
        return a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    }

    function Tb(a) {
        for (var b = 0; b < 3; ++b) try {
            var c = decodeURIComponent(a).replace(/\+/g, " ");
            if (c === a) break;
            a = c
        } catch (d) {
            return ""
        }
        return a
    };
    var Ub = {};

    function J(a) {
        var b = Ub.TAGGING;
        b || (b = Ub.TAGGING = []);
        b[a] = !0
    };

    function Vb(a) {
        a = Wb(a);
        return La(a)
    }

    function Wb(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var M = window,
        N = document,
        Xb = navigator,
        Yb = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Zb = {
            height: 1,
            onload: 1,
            src: 1,
            style: 1,
            width: 1
        };

    function $b(a, b, c) {
        if (b) {
            b = w(u(Object, "entries").call(Object, b));
            var d = b.next(),
                e;
            try {
                for (; !d.done; d = b.next()) {
                    var f = w(d.value),
                        g = f.next().value,
                        h = f.next().value,
                        k = g,
                        l = h;
                    k = k.toLowerCase();
                    c.hasOwnProperty(k) || a.setAttribute(k, l)
                }
            } finally {
                d && !d.done && (e = b.return) && e.call(b)
            }
        }
    }

    function ac(a, b, c, d, e) {
        var f = N.createElement("script");
        $b(f, d, Yb);
        f.type = "text/javascript";
        f.async = d && d.async === !1 ? !1 : !0;
        a = Ga(Wb(a));
        Na(f, a);
        b && (f.onload = b);
        c && (f.onerror = c);
        e ? e.appendChild(f) : bc.na(f)
    }

    function cc(a, b, c) {
        var d = !1;
        d = d === void 0 ? !0 : d;
        var e = !1;
        c || (c = N.createElement("iframe"), e = !0);
        $b(c, void 0, Zb);
        d && (c.height = "0", c.width = "0", c.style.display = "none", c.style.visibility = "hidden");
        a !== void 0 && (c.src = a);
        e && (a = N.body && N.body.lastChild || N.body || N.head, a.parentNode.insertBefore(c, a));
        b && (c.onload = b)
    }

    function dc() {
        var a = bc.fa,
            b = a.apply;
        var c = oa.apply(0, arguments);
        c = c instanceof Array ? c : ka(w(c));
        b.call(a, bc, c)
    }
    var ec = {
        cache: "no-store",
        credentials: "include",
        keepalive: !0,
        method: "POST",
        mode: "no-cors",
        redirect: "follow"
    };

    function fc(a) {
        if (Nb(M.fetch)) {
            var b = u(Object, "assign").call(Object, {}, ec);
            try {
                var c = M.fetch(a, b);
                if (c) return c.then(function() {}).catch(function() {}), !0
            } catch (d) {}
        }
        bc.ra(a, void 0, void 0);
        return !0
    }

    function hc() {
        var a = M.performance;
        if (a && a.getEntriesByType) try {
            var b = a.getEntriesByType("navigation");
            if (b && b.length > 0) var c = b[0].type
        } catch (d) {
            return "e"
        }
        if (!c) return "u";
        switch (c) {
            case "navigate":
                return "n";
            case "back_forward":
                return "h";
            case "reload":
                return "r";
            case "prerender":
                return "p";
            default:
                return "x"
        }
    }
    var bc = {
        fa: function(a, b, c, d) {
            var e = new Image(1, 1);
            $b(e, d, {});
            e.onload = function() {
                e.onload = null;
                b && b()
            };
            e.onerror = function() {
                e.onerror = null;
                c && c()
            };
            e.src = a;
            return e
        },
        na: function(a) {
            var b = N.getElementsByTagName("script")[0] || N.body || N.head;
            b.parentNode.insertBefore(a, b)
        },
        ra: function(a, b, c) {
            try {
                var d = Xb.sendBeacon && Xb.sendBeacon(a)
            } catch (e) {
                J(15)
            }
            d ? b == null || b() : dc(a, b, c)
        }
    };

    function ic() {
        var a = {};
        var b = M.google_tag_data;
        M.google_tag_data = b === void 0 ? a : b;
        a = M.google_tag_data;
        return a.ics = a.ics || new jc
    }

    function jc() {
        this.entries = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.v = []
    }
    n = jc.prototype;
    n.default = function(a, b, c, d, e, f, g) {
        this.usedDefault || this.usedDeclare || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        J(19);
        b == null ? J(18) : kc(this, a, b === "granted", c, d, e, f, g)
    };
    n.waitForUpdate = function(a, b, c) {
        for (var d = 0; d < a.length; d++) kc(this, a[d], void 0, void 0, "", "", b, c)
    };

    function kc(a, b, c, d, e, f, g, h) {
        var k = u(a, "entries"),
            l = k[b] || {},
            m = l.region;
        d = d && Pb(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (e === "" || d === f || (d === e ? m !== f : !d && !m)) {
            f = !!(g && g > 0 && l.update === void 0);
            var p = {
                region: d,
                declare_region: l.declare_region,
                implicit: l.implicit,
                default: c !== void 0 ? c : l.default,
                declare: l.declare,
                update: l.update,
                quiet: f
            };
            if (e !== "" || l.default !== !1) k[b] = p;
            f && M.setTimeout(function() {
                    k[b] === p && p.quiet && (J(2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0, h), a.notifyListeners())
                },
                g)
        }
    }
    n.clearTimeout = function(a, b, c) {
        var d = [a],
            e = c.delegatedConsentTypes,
            f;
        for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
        e = u(this, "entries")[a] || {};
        a = this.getConsentState(a, c);
        if (e.quiet) {
            e.quiet = !1;
            var g = w(d);
            b = g.next();
            var h;
            try {
                for (; !b.done; b = g.next()) lc(this, b.value)
            } finally {
                b && !b.done && (h = g.return) && h.call(g)
            }
        } else if (b !== void 0 && a !== b) {
            h = w(d);
            b = h.next();
            try {
                for (; !b.done; b = h.next()) lc(this, b.value)
            } finally {
                b && !b.done && (g = h.return) && g.call(h)
            }
        }
    };
    n.update = function(a, b, c) {
        this.usedDefault || this.usedDeclare || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (b != null) {
            var d = this.getConsentState(a, c),
                e = u(this, "entries");
            (e[a] = e[a] || {}).update = b === "granted";
            this.clearTimeout(a, d, c)
        }
    };
    n.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = u(this, "entries"),
            g = f[a] || {},
            h = g.declare_region;
        c = c && Pb(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (d === "" || c === e || (c === d ? h !== e : !c && !h))
            if (b = {
                    region: g.region,
                    declare_region: c,
                    declare: b === "granted",
                    implicit: g.implicit,
                    default: g.default,
                    update: g.update,
                    quiet: g.quiet
                }, d !== "" || g.declare !== !1) f[a] = b
    };
    n.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = u(this, "entries");
        a = c[a] = c[a] || {};
        a.implicit !== !1 && (a.implicit = b === "granted")
    };
    n.getConsentState = function(a, b) {
        var c = u(this, "entries"),
            d = c[a] || {},
            e = d.update;
        if (e !== void 0) return e ? 1 : 2;
        if (b.usedContainerScopedDefaults) {
            e = b.containerScopedDefaults[a];
            if (e === 3) return 1;
            if (e === 2) return 2
        } else if (e = d.default, e !== void 0) return e ? 1 : 2;
        if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
            a = b.delegatedConsentTypes[a];
            c = c[a] || {};
            e = c.update;
            if (e !== void 0) return e ? 1 : 2;
            if (b.usedContainerScopedDefaults) {
                b = b.containerScopedDefaults[a];
                if (b === 3) return 1;
                if (b === 2) return 2
            } else if (e = c.default,
                e !== void 0) return e ? 1 : 2
        }
        e = d.declare;
        if (e !== void 0) return e ? 1 : 2;
        e = d.implicit;
        return e !== void 0 ? e ? 3 : 4 : 0
    };
    n.addListener = function(a, b) {
        this.v.push({
            consentTypes: a,
            ia: b
        })
    };

    function lc(a, b) {
        for (var c = 0; c < a.v.length; ++c) {
            var d = a.v[c];
            Array.isArray(d.consentTypes) && d.consentTypes.indexOf(b) !== -1 && (d.ca = !0)
        }
    }
    n.notifyListeners = function(a, b) {
        for (var c = 0; c < this.v.length; ++c) {
            var d = this.v[c];
            if (d.ca) {
                d.ca = !1;
                try {
                    d.ia({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };
    var mc = [],
        nc = {};

    function Q(a) {
        return mc[a] === void 0 ? !1 : mc[a]
    };
    var oc = {},
        pc = {
            delegatedConsentTypes: {},
            corePlatformServices: {},
            usedCorePlatformServices: !1,
            selectedAllCorePlatformServices: !1,
            containerScopedDefaults: (oc.ad_storage = 1, oc.analytics_storage = 1, oc.ad_user_data = 1, oc.ad_personalization = 1, oc),
            usedContainerScopedDefaults: !1
        };

    function qc(a) {
        var b = ic();
        b.accessedAny = !0;
        return (Pb(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c, pc)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function rc(a) {
        var b = ic();
        b.accessedAny = !0;
        return !(u(b, "entries")[a] || {}).quiet
    }

    function sc(a, b) {
        ic().addListener(a, b)
    }

    function tc(a, b) {
        if (b.every(rc)) a({});
        else {
            var c = !1;
            sc(b, function(d) {
                !c && b.every(rc) && (c = !0, a(d))
            })
        }
    }

    function uc(a, b) {
        function c() {
            return d.filter(function(g) {
                return qc(g) && !e[g]
            })
        }
        var d = Pb(b) ? [b] : b,
            e = {};
        b = c();
        if (b.length !== d.length) {
            var f = function(g) {
                g = w(g);
                var h = g.next(),
                    k;
                try {
                    for (; !h.done; h = g.next()) e[h.value] = !0
                } finally {
                    h && !h.done && (k = g.return) && k.call(g)
                }
            };
            f(b);
            sc(d, function(g) {
                function h(m) {
                    m.length !== 0 && (f(m), g.consentTypes = m, a(g))
                }
                var k = c();
                if (k.length !== 0) {
                    var l = u(Object, "keys").call(Object, e).length;
                    k.length + l >= d.length ? h(k) : M.setTimeout(function() {
                        h(c())
                    }, 500)
                }
            })
        }
    };
    var vc = /:[0-9]+$/,
        wc = /^\d+\.fls\.doubleclick\.net$/;

    function xc(a, b) {
        var c = {};
        a = w(a.split("&"));
        var d = a.next(),
            e;
        try {
            for (; !d.done; d = a.next()) {
                var f = w(d.value.split("=")),
                    g = f.next().value,
                    h = ka(f),
                    k = decodeURIComponent(g.replace(/\+/g, " "));
                if (b === void 0 || k === b) {
                    var l = h.join("=");
                    c[k] || (c[k] = []);
                    c[k].push(decodeURIComponent(l.replace(/\+/g, " ")))
                }
            }
        } finally {
            d && !d.done && (e = a.return) && e.call(a)
        }
        var m;
        return (m = c[b]) == null ? void 0 : m[0]
    }

    function yc(a, b, c, d, e) {
        b && (b = String(b).toLowerCase());
        if (b === "protocol" || b === "port") a.protocol = zc(a.protocol) || zc(M.location.protocol);
        b === "port" ? a.port = String(Number(a.hostname ? a.port : M.location.port) || (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")) : b === "host" && (a.hostname = (a.hostname || M.location.hostname).replace(vc, "").toLowerCase());
        var f = zc(a.protocol);
        b && (b = String(b).toLowerCase());
        switch (b) {
            case "url_no_fragment":
                d = "";
                a && a.href && (d = a.href.indexOf("#"), d = d < 0 ? a.href : a.href.substring(0,
                    d));
                a = d;
                break;
            case "protocol":
                a = f;
                break;
            case "host":
                a = a.hostname.replace(vc, "").toLowerCase();
                c && (d = /^www\d*\./.exec(a)) && d[0] && (a = a.substring(d[0].length));
                break;
            case "port":
                a = String(Number(a.port) || (f === "http" ? 80 : f === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || J(1);
                a = a.pathname.charAt(0) === "/" ? a.pathname : "/" + a.pathname;
                a = a.split("/");
                (d || []).indexOf(a[a.length - 1]) >= 0 && (a[a.length - 1] = "");
                a = a.join("/");
                break;
            case "query":
                a = a.search.replace("?", "");
                e && (a = xc(a, e));
                break;
            case "extension":
                a =
                    a.pathname.split(".");
                a = a.length > 1 ? a[a.length - 1] : "";
                a = a.split("/")[0];
                break;
            case "fragment":
                a = a.hash.replace("#", "");
                break;
            default:
                a = a && a.href
        }
        return a
    }

    function zc(a) {
        return a ? a.replace(":", "").toLowerCase() : ""
    }
    var Ac = {},
        Bc = 0;

    function Cc(a) {
        var b = Ac[a];
        if (!b) {
            b = N.createElement("a");
            a && (b.href = a);
            var c = b.pathname;
            c[0] !== "/" && (a || J(1), c = "/" + c);
            var d = b.hostname.replace(vc, "");
            b = {
                href: b.href,
                protocol: b.protocol,
                host: b.host,
                hostname: d,
                pathname: c,
                search: b.search,
                hash: b.hash,
                port: b.port
            };
            Bc < 5 && (Ac[a] = b, Bc++)
        }
        return b
    };

    function Dc(a, b, c, d) {
        var e, f = Number(a.U != null ? a.U : void 0);
        f !== 0 && (e = new Date((b || Rb()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            K: d
        }
    };
    var Ec = ["ad_storage", "ad_user_data"];

    function Fc(a, b) {
        if (a)
            if (b === null || b === void 0 || b === "") J(33);
            else {
                var c = Gc(!1);
                c.error !== 0 ? J(34) : c.value ? (c.value[a] = b, Hc(c) !== 0 && J(36)) : J(35)
            }
        else J(32)
    }

    function Ic(a) {
        if (!a) return J(27), {
            error: 10
        };
        var b = Gc();
        if (b.error !== 0) return J(29), b;
        if (!b.value) return J(30), {
            error: 2
        };
        if (!(a in b.value)) return J(31), {
            value: void 0,
            error: 15
        };
        a = b.value[a];
        return a === null || a === void 0 || a === "" ? (J(28), {
            value: void 0,
            error: 11
        }) : {
            value: a,
            error: 0
        }
    }

    function Jc(a) {
        if (a) {
            var b = Gc(!1);
            b.error !== 0 ? J(38) : b.value ? a in b.value ? (delete b.value[a], Hc(b) !== 0 && J(41)) : J(40) : J(39)
        } else J(37)
    }

    function Gc(a) {
        a = a === void 0 ? !0 : a;
        if (!qc(Ec)) return J(43), {
            error: 3
        };
        try {
            if (!M.localStorage) return J(44), {
                error: 1
            }
        } catch (f) {
            return J(45), {
                error: 14
            }
        }
        var b = {
                schema: "gcl",
                version: 1
            },
            c = void 0;
        try {
            c = M.localStorage.getItem("_gcl_ls")
        } catch (f) {
            return J(46), {
                error: 13
            }
        }
        try {
            if (c) {
                var d = JSON.parse(c);
                if (d && typeof d === "object") b = d;
                else return J(47), {
                    error: 12
                }
            }
        } catch (f) {
            return J(48), {
                error: 8
            }
        }
        if (b.schema !== "gcl") return J(49), {
            error: 4
        };
        if (b.version !== 1) return J(50), {
            error: 5
        };
        try {
            var e = Kc(b);
            a && e && Hc({
                value: b,
                error: 0
            })
        } catch (f) {
            return J(48), {
                error: 8
            }
        }
        return {
            value: b,
            error: 0
        }
    }

    function Kc(a) {
        if (!a || typeof a !== "object") return !1;
        if ("expires" in a && "value" in a) {
            var b;
            typeof a.expires === "number" ? b = a.expires : b = typeof a.expires === "string" ? Number(a.expires) : NaN;
            if (isNaN(b) || !(Date.now() <= b)) return a.value = null, a.error = 9, J(54), !0
        } else {
            b = !1;
            var c = w(u(Object, "keys").call(Object, a)),
                d = c.next(),
                e;
            try {
                for (; !d.done; d = c.next()) b = Kc(a[d.value]) || b
            } finally {
                d && !d.done && (e = c.return) && e.call(c)
            }
            return b
        }
        return !1
    }

    function Hc(a) {
        if (a.error) return a.error;
        if (!a.value) return J(42), 2;
        a = a.value;
        try {
            var b = JSON.stringify(a)
        } catch (c) {
            return J(52), 6
        }
        try {
            M.localStorage.setItem("_gcl_ls", b)
        } catch (c) {
            return J(53), 7
        }
        return 0
    };
    var Lc = {
            M: "value",
            F: "conversionCount",
            V: 1
        },
        Mc = [Lc, {
            M: "timeouts",
            F: "timeouts",
            V: 0
        }, {
            M: "errors",
            F: "errors",
            V: 0
        }, {
            M: "eopCount",
            F: "endOfPageCount",
            V: 0
        }];

    function Nc(a) {
        return qc(["ad_storage", "ad_user_data"]) ? !a.qa || Q(a.qa) : !1
    }

    function Oc(a) {
        return qc(["ad_storage", "ad_user_data"]) ? !a.ma || Q(a.ma) : !1
    };

    function Pc() {
        return qc(["ad_storage", "ad_user_data"]) && Q(7)
    };

    function Qc(a, b, c, d) {
        var e;
        return (e = Rc(function(f) {
            return f === a
        }, b, c, d)[a]) != null ? e : []
    }

    function Rc(a, b, c, d) {
        if (Sc(d)) {
            d = {};
            b = String(b || Tc()).split(";");
            for (var e = 0; e < b.length; e++) {
                var f = b[e].split("="),
                    g = f[0].trim();
                if (g && a(g)) {
                    (f = f.slice(1).join("=").trim()) && c && (f = decodeURIComponent(f));
                    var h = void 0,
                        k = void 0;
                    ((h = d)[k = g] || (h[k] = [])).push(f)
                }
            }
            a = d
        } else a = {};
        return a
    }

    function Uc(a, b, c) {
        var d = Vc,
            e = ["ad_storage", "ad_user_data"];
        if (Sc(e)) {
            a = Wc(a, d, e);
            if (a.length === 1) return a[0];
            if (a.length !== 0) {
                a = Xc(a, function(f) {
                    return f.ga
                }, b);
                if (a.length === 1) return a[0];
                a = Xc(a, function(f) {
                    return f.pa
                }, c);
                return a[0]
            }
        }
    }

    function Yc(a, b, c, d) {
        var e = Tc();
        M.origin !== "null" && (M.document.cookie = a);
        a = Tc();
        return e !== a || c !== void 0 && Qc(b, a, !1, d).indexOf(c) >= 0
    }

    function Zc(a, b, c) {
        function d(p, r, t) {
            if (t == null) return delete g[r], p;
            g[r] = t;
            return p + "; " + r + "=" + t
        }

        function e(p, r) {
            if (r == null) return p;
            g[r] = !0;
            return p + "; " + r
        }
        if (Sc(c.K)) {
            if (b == null) var f = a + "=deleted; expires=" + (new Date(0)).toUTCString();
            else c.encode && (b = encodeURIComponent(b)), b = $c(b), f = a + "=" + b;
            var g = {};
            f = d(f, "path", c.path);
            if (c.expires instanceof Date) var h = c.expires.toUTCString();
            else c.expires != null && (h = c.expires);
            f = d(f, "expires", h);
            f = d(f, "max-age", c.Ja);
            f = d(f, "samesite", c.Ka);
            c.secure && (f = e(f,
                "secure"));
            if ((h = c.domain) && h.toLowerCase() === "auto") {
                h = ad();
                for (var k = 0; k < h.length; ++k) {
                    var l = h[k] !== "none" ? h[k] : void 0,
                        m = d(f, "domain", l);
                    m = e(m, c.flags);
                    if (!bd(l, c.path) && Yc(m, a, b, c.K)) break
                }
            } else h && h.toLowerCase() !== "none" && (f = d(f, "domain", h)), f = e(f, c.flags), bd(h, c.path) || Yc(f, a, b, c.K)
        }
    }

    function cd(a, b, c) {
        c.path == null && (c.path = "/");
        c.domain || (c.domain = "auto");
        Zc(a, b, c)
    }

    function Xc(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var h = a[g],
                k = b(h);
            k === c ? d.push(h) : f === void 0 || k < f ? (e = [h], f = k) : k === f && e.push(h)
        }
        return d.length > 0 ? d : e
    }

    function Wc(a, b, c) {
        var d = [];
        a = Qc(a, void 0, void 0, c);
        for (c = 0; c < a.length; c++) {
            var e = a[c].split("."),
                f = e.shift();
            if (!b || !f || b.indexOf(f) !== -1)
                if (f = e.shift()) f = f.split("-"), d.push({
                    Ia: a[c],
                    ea: e.join("."),
                    ga: Number(f[0]) || 1,
                    pa: Number(f[1]) || 1
                })
        }
        return d
    }

    function $c(a) {
        a && a.length > 1200 && (a = a.substring(0, 1200));
        return a
    }
    var dd = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        ed = /(^|\.)doubleclick\.net$/i;

    function bd(a, b) {
        return a !== void 0 && (ed.test(M.document.location.hostname) || b === "/" && dd.test(a))
    }

    function fd(a) {
        if (!a) return 1;
        var b = a;
        Q(4) && a === "none" && (b = M.document.location.hostname);
        b = b.indexOf(".") === 0 ? b.substring(1) : b;
        return b.split(".").length
    }

    function gd(a) {
        if (!a || a === "/") return 1;
        a[0] !== "/" && (a = "/" + a);
        a[a.length - 1] !== "/" && (a += "/");
        return a.split("/").length - 1
    }

    function hd(a, b) {
        a = "" + fd(a);
        b = gd(b);
        b > 1 && (a += "-" + b);
        return a
    }

    function Tc() {
        return M.origin !== "null" ? M.document.cookie : ""
    }

    function Sc(a) {
        return a && Q(5) ? (Array.isArray(a) ? a : [a]).every(function(b) {
            return rc(b) && qc(b)
        }) : !0
    }

    function ad() {
        var a = [],
            b = M.document.location.hostname.split(".");
        if (b.length === 4) {
            var c = b[b.length - 1];
            if (Number(c).toString() === c) return ["none"]
        }
        for (c = b.length - 2; c >= 0; c--) a.push(b.slice(c).join("."));
        b = M.document.location.hostname;
        ed.test(b) || dd.test(b) || a.push("none");
        return a
    };
    var Vc = ["1"],
        id = {},
        jd = {};

    function kd(a, b) {
        (b === void 0 ? 0 : b) && Nc(Lc) && Jc("gcl_ctr");
        if (b = Oc(Lc)) {
            b = [Lc];
            b: {
                var c = Ic("gcl_ctr");
                if (c.error === 0 && c.value && typeof c.value === "object") {
                    c = c.value;
                    try {
                        var d = "value" in c && typeof c.value === "object" ? c.value : void 0;
                        break b
                    } catch (t) {}
                }
                d = void 0
            }
            c = {};
            b = w(b);
            var e = b.next(),
                f;
            try {
                for (; !e.done; e = b.next()) {
                    var g = e.value;
                    if (d && Nc(g)) {
                        var h = d[g.M];
                        h === void 0 || u(Number, "isNaN").call(Number, h) ? c[g.F] = -1 : c[g.F] = Number(h)
                    } else c[g.F] = -1
                }
            } finally {
                e && !e.done && (f = b.return) && f.call(b)
            }
            b = c[Lc.F] === -1
        }
        if (b) {
            f = {};
            f = (f[Lc.F] = 0, f);
            g = w(Mc);
            h = g.next();
            var k;
            try {
                for (; !h.done; h = g.next()) {
                    var l = h.value;
                    l !== Lc && Oc(l) && (f[l.F] = 0)
                }
            } finally {
                h && !h.done && (k = g.return) && k.call(g)
            }
            k = Rb();
            a = Dc(a || {}, k, !0);
            l = {};
            g = w(Mc);
            h = g.next();
            var m;
            try {
                for (; !h.done; h = g.next()) {
                    var p = h.value,
                        r = f[p.F];
                    r !== void 0 && r !== -1 && (l[p.M] = r)
                }
            } finally {
                h && !h.done && (m = g.return) && m.call(g)
            }
            l.creationTimeMs = k;
            Fc("gcl_ctr", {
                value: l,
                expires: Number(a.expires)
            })
        }
    }

    function ld(a, b) {
        (b === void 0 ? 0 : b) && Pc() && Jc("last_convs");
        if (!(b = !(qc(["ad_storage", "ad_user_data"]) && Q(8)))) a: {
            if (Pc()) {
                var c = Ic("last_convs");
                if (c.error === 0 && c.value && typeof c.value === "object" && (c = c.value, c.value && Array.isArray(c.value))) {
                    var d = c.value;
                    if (!(d.length > 1)) {
                        c = [];
                        d = w(d);
                        var e = d.next(),
                            f;
                        try {
                            for (; !e.done; e = d.next()) {
                                var g = e.value;
                                if (typeof g !== "object" || g === null || typeof g.random !== "number" || typeof g.label !== "string" || g.label.length > 200) {
                                    b = void 0;
                                    break a
                                }
                                c.push({
                                    random: g.random,
                                    label: g.label
                                })
                            }
                        } finally {
                            e &&
                                !e.done && (f = d.return) && f.call(d)
                        }
                        b = c;
                        break a
                    }
                }
            }
            b = void 0
        }
        b || (f = [], !Pc() || f.length > 1 || f.length === 1 && f[0].label.length > 200 || (a = a || {}, Fc("last_convs", {
            value: f,
            expires: Number(Dc(a).expires)
        })))
    }

    function md(a, b, c, d) {
        b = ["1", hd(c.domain, c.path), b].join(".");
        c = Dc(c, d);
        c.K = ["ad_storage", "ad_user_data"];
        cd(a, b, c)
    }

    function nd(a, b, c) {
        var d;
        b = (d = Uc(a, fd(b), gd(c))) == null ? void 0 : d.ea;
        if (!b) return !1;
        c = b.split(".");
        c.length === 3 ? jd[a] = {
            sessionId: c[0] + "." + c[1],
            J: Number(c[2]) || 0,
            P: 0
        } : c.length >= 2 && (id[a] = c[0] + "." + c[1], c.shift(), c.shift(), c.length >= 3 && (d = {
            sessionId: c[0] === "-" ? void 0 : c[0] + "." + c[1],
            J: Number(c[2]) || 0,
            P: 0
        }, Q(13) && c.length >= 6 && (b = c[3] + "." + c[4], c = Number(c[5]) || 0, b && c !== 0 && (d.ba = b, d.P = c)), jd[a] = d));
        return !0
    }

    function od(a) {
        return (a || "_gcl") + "_au"
    };

    function pd(a, b, c) {
        a = qd(a, !0);
        if (a[b]) return !1;
        a[b] = [];
        a[b][0] = c;
        return !0
    }

    function qd(a, b) {
        var c = a.GooglebQhCsO;
        c || (c = {}, b && (a.GooglebQhCsO = c));
        return c
    };
    var rd = {},
        sd = null;

    function td(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        a = 4;
        a === void 0 && (a = 0);
        if (!sd)
            for (sd = {}, c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; e < 5; e++) {
                var f = c.concat(d[e].split(""));
                rd[e] = f;
                for (var g = 0; g < f.length; g++) {
                    var h = f[g];
                    sd[h] === void 0 && (sd[h] = g)
                }
            }
        a = rd[a];
        c = Array(Math.floor(b.length / 3));
        d = a[64] || "";
        for (e = f = 0; f < b.length - 2; f += 3) {
            var k = b[f],
                l = b[f + 1];
            h = b[f + 2];
            g = a[k >> 2];
            k = a[(k &
                3) << 4 | l >> 4];
            l = a[(l & 15) << 2 | h >> 6];
            h = a[h & 63];
            c[e++] = g + k + l + h
        }
        g = 0;
        h = d;
        switch (b.length - f) {
            case 2:
                g = b[f + 1], h = a[(g & 15) << 2] || d;
            case 1:
                b = b[f], c[e] = a[b >> 2] + a[(b & 3) << 4 | g >> 4] + h + d
        }
        return c.join("")
    };
    var ud = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function vd(a) {
        var b = a.match(ud);
        a = b[5];
        var c = b[6];
        b = b[7];
        var d = "";
        a && (d += a);
        c && (d += "?" + c);
        b && (d += "#" + b);
        return d
    }

    function wd(a, b, c, d) {
        for (var e = c.length;
            (b = a.indexOf(c, b)) >= 0 && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (f == 38 || f == 63)
                if (f = a.charCodeAt(b + e), !f || f == 61 || f == 38 || f == 35) return b;
            b += e + 1
        }
        return -1
    }
    var xd = /#|$/;

    function yd(a, b) {
        var c = a.search(xd),
            d = wd(a, 0, b, c);
        if (d < 0) return null;
        var e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    }
    var zd = /[?&]($|#)/;

    function Ad(a, b, c) {
        for (var d = a.search(xd), e = 0, f, g = [];
            (f = wd(a, e, b, d)) >= 0;) g.push(a.substring(e, f)), e = Math.min(a.indexOf("&", f) + 1 || d, d);
        g.push(a.slice(e));
        a = g.join("").replace(zd, "$1");
        c = c != null ? "=" + encodeURIComponent(String(c)) : "";
        (b += c) ? (c = a.indexOf("#"), c < 0 && (c = a.length), d = a.indexOf("?"), d < 0 || d > c ? (d = c, e = "") : e = a.substring(d + 1, c), c = [a.slice(0, d), e, a.slice(c)], a = c[1], c[1] = b ? a ? a + "&" + b : b : a, b = c[0] + (c[1] ? "?" + c[1] : "") + c[2]) : b = a;
        return b
    };

    function Bd(a, b, c, d, e, f) {
        var g = yd(c, "fmt");
        if (d) {
            var h = yd(c, "random"),
                k = yd(c, "label") || "";
            if (!h) return;
            h = td(decodeURIComponent(k.replace(/\+/g, " ")) + ":" + decodeURIComponent(h.replace(/\+/g, " ")));
            if (!pd(a, h, d)) return
        }
        g && Number(g) !== 4 ? (c = Ad(c, "rfmt", g), c = Ad(c, "fmt", 4)) : g || (c = Ad(c, "fmt", 4));
        ac(c, function() {
            a.google_noFurtherRedirects && d && (a.google_noFurtherRedirects = null, d())
        }, function() {
            e == null || e()
        }, f, b.getElementsByTagName("script")[0].parentElement || void 0);
        return c
    };
    var R = {},
        Cd = (R.k = {
            D: /^[\w-]+$/
        }, R.b = {
            D: /^[\w-]+$/,
            W: !0
        }, R.i = {
            D: /^[1-9]\d*$/
        }, R.h = {
            D: /^\d+$/
        }, R.t = {
            D: /^[1-9]\d*$/
        }, R.d = {
            D: /^[A-Za-z0-9_-]+$/
        }, R.j = {
            D: /^\d+$/
        }, R.u = {
            D: /^[1-9]\d*$/
        }, R.l = {
            D: /^[01]$/
        }, R.o = {
            D: /^[1-9]\d*$/
        }, R.g = {
            D: /^[01]$/
        }, R.s = {
            D: /^.+$/
        }, R.m = {
            D: /^[01]$/
        }, R);
    var Dd = {},
        Hd = (Dd[5] = {
            Y: {
                2: Ed
            },
            T: "2",
            N: ["k", "i", "b", "u"]
        }, Dd[4] = {
            Y: {
                2: Ed,
                GCL: Fd
            },
            T: "2",
            N: ["k", "i", "b", "m"]
        }, Dd[2] = {
            Y: {
                GS2: Ed,
                GS1: Gd
            },
            T: "GS2",
            N: "sogtjlhd".split("")
        }, Dd);

    function Ed(a, b) {
        a = a.split(".");
        if (a.length === 3) {
            var c = a[2];
            if (c.indexOf("$") === -1 && c.indexOf("%24") !== -1) try {
                c = decodeURIComponent(c)
            } catch (l) {}
            a = {};
            if (b = Hd[b]) {
                b = b.N;
                c = w(c.split("$"));
                var d = c.next(),
                    e;
                try {
                    for (; !d.done; d = c.next()) {
                        var f = d.value,
                            g = f[0];
                        if (b.indexOf(g) !== -1) try {
                            var h = decodeURIComponent(f.substring(1)),
                                k = Cd[g];
                            k && (k.W ? (a[g] = a[g] || [], a[g].push(h)) : a[g] = h)
                        } catch (l) {}
                    }
                } finally {
                    d && !d.done && (e = c.return) && e.call(c)
                }
                return a
            }
        }
    }

    function Fd(a) {
        a = a.split(".");
        a.shift();
        var b = a.shift(),
            c = a.shift(),
            d = {};
        return d.k = c, d.i = b, d.b = a, d
    }

    function Gd(a) {
        a = a.split(".").slice(2);
        if (!(a.length < 5 || a.length > 7)) {
            var b = {};
            return b.s = a[0], b.o = a[1], b.g = a[2], b.t = a[3], b.j = a[4], b.l = a[5], b.h = a[6], b
        }
    };
    var Id = new q.Map([
        [5, "ad_storage"],
        [4, ["ad_storage", "ad_user_data"]],
        [2, "analytics_storage"]
    ]);

    function Jd(a, b) {
        if (Hd[b]) {
            var c = [];
            a = Qc(a, void 0, void 0, Id.get(b));
            a = w(a);
            var d = a.next(),
                e;
            try {
                for (; !d.done; d = a.next()) {
                    a: {
                        var f = d.value,
                            g = b,
                            h = Hd[g];
                        if (h) {
                            var k = f.split(".")[0];
                            if (k) {
                                var l = h.Y[k];
                                if (l) {
                                    var m = l(f, g);
                                    break a
                                }
                            }
                        }
                        m = void 0
                    }(g = m) && c.push(Kd(g))
                }
            } finally {
                d && !d.done && (e = a.return) && e.call(a)
            }
            return c
        }
    }

    function Ld(a, b, c, d) {
        c = c || {};
        var e = Hd[5];
        if (e) {
            e = e.T;
            var f = hd(c.domain, c.path) || "1";
            var g = Hd[5];
            if (g) {
                var h = [];
                g = w(g.N);
                var k = g.next(),
                    l;
                try {
                    for (; !k.done; k = g.next()) {
                        var m = k.value,
                            p = Cd[m];
                        if (p) {
                            var r = b[m];
                            if (r !== void 0)
                                if (p.W && Array.isArray(r)) {
                                    var t = w(r),
                                        x = t.next(),
                                        D;
                                    try {
                                        for (; !x.done; x = t.next()) h.push(encodeURIComponent(m + x.value))
                                    } finally {
                                        x && !x.done && (D = t.return) && D.call(t)
                                    }
                                } else h.push(encodeURIComponent(m + r))
                        }
                    }
                } finally {
                    k && !k.done && (l = g.return) && l.call(g)
                }
                b = h.join("$")
            } else b = void 0;
            b = [e, f, b].join(".")
        } else b =
            void 0;
        b && (c = Dc(c, d, void 0, Id.get(5)), cd(a, b, c))
    }

    function Md(a, b) {
        b = b.D;
        return typeof b === "function" ? b(a) : b.test(a)
    }

    function Kd(a) {
        var b = w(u(Object, "keys").call(Object, a)),
            c = b.next(),
            d;
        try {
            for (var e = {}; !c.done; e = {
                    L: void 0
                }, c = b.next()) {
                var f = c.value,
                    g = a[f];
                e.L = Cd[f];
                e.L ? e.L.W ? a[f] = Array.isArray(g) ? g.filter(function(h) {
                    return function(k) {
                        return Md(k, h.L)
                    }
                }(e)) : void 0 : typeof g === "string" && Md(g, e.L) || (a[f] = void 0) : a[f] = void 0
            }
        } finally {
            c && !c.done && (d = b.return) && d.call(b)
        }
        return a
    };

    function S(a) {
        a = a === void 0 ? 0 : a;
        this.value = 0;
        this.value = a
    }
    S.prototype.set = function(a) {
        return this.value |= 1 << a
    };

    function Nd(a, b) {
        b <= 0 || (a.value |= 1 << b - 1)
    }
    S.prototype.get = function() {
        return this.value
    };

    function Od(a) {
        var b = [],
            c = N.cookie.split(";");
        a = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$");
        for (var d = 0; d < c.length; d++) {
            var e = c[d].match(a);
            e && b.push({
                X: e[1],
                value: e[2],
                timestamp: Number(e[2].split(".")[1]) || 0
            })
        }
        b.sort(function(f, g) {
            return g.timestamp - f.timestamp
        });
        return b
    }

    function Pd(a, b) {
        a = Od(a);
        var c = {};
        if (!a || !a.length) return c;
        for (var d = 0; d < a.length; d++) {
            var e = a[d].value.split(".");
            if (!(e[0] !== "1" || b && e.length < 3 || !b && e.length !== 3) && Number(e[1])) {
                c[a[d].X] || (c[a[d].X] = []);
                var f = {
                    version: e[0],
                    timestamp: Number(e[1]) * 1E3,
                    A: e[2]
                };
                b && e.length > 3 && (f.labels = e.slice(3));
                c[a[d].X].push(f)
            }
        }
        return c
    };
    var Qd = /^\w+$/,
        Rd = /^[\w-]+$/,
        Sd = {},
        Td = (Sd.aw = "FPGCLAW", Sd),
        T = {},
        Ud = (T.ag = "_ag", T.gb = "_gb", T.aw = "_aw", T.dc = "_dc", T.gf = "_gf", T.ha = "_ha", T.gp = "_gp", T.gs = "_gs", T);

    function V() {
        return ["ad_storage", "ad_user_data"]
    }

    function W(a) {
        return !Q(5) || qc(a)
    }

    function Vd(a) {
        function b() {
            var d = W(c);
            d && a();
            return d
        }
        var c = V();
        tc(function() {
            b() || uc(b, c)
        }, c)
    }

    function Wd(a) {
        return Xd(a).map(function(b) {
            return b.A
        })
    }

    function Yd(a, b) {
        function c(e) {
            return function(f) {
                f.aa = e;
                return f
            }
        }
        b = b === void 0 ? !1 : b;
        var d = Zd(a.prefix);
        a = $d("gb", d);
        d = $d("ag", d);
        if (!d || !a) return [];
        b = Xd(a, b).map(c("gb"));
        a = ae(d).map(c("ag"));
        return b.concat(a).sort(function(e, f) {
            return f.timestamp - e.timestamp
        })
    }

    function be(a, b, c, d, e) {
        var f = Qb(a, function(g) {
            return g.A === b
        });
        f ? (f.timestamp < c && (f.timestamp = c, f.I = e), f.labels = ce(f.labels || [], d || [])) : a.push({
            version: "2",
            A: b,
            timestamp: c,
            labels: d,
            I: e
        })
    }

    function de(a) {
        var b = Jd(a, 5) || [];
        a = [];
        b = w(b);
        var c = b.next(),
            d;
        try {
            for (; !c.done; c = b.next()) {
                var e = c.value,
                    f = e,
                    g = e ? (Number(e.i) || 0) * 1E3 : 0;
                g && be(a, f.k, g, f.b || [], e.u)
            }
        } finally {
            c && !c.done && (d = b.return) && d.call(b)
        }
        return a.sort(function(h, k) {
            return k.timestamp - h.timestamp
        })
    }

    function Xd(a, b) {
        b = b === void 0 ? !1 : b;
        var c = [];
        ee(c, a, 1);
        if (b)
            if (Sb(a, "_aw")) {
                if (a = fe()) a.I = void 0, a.C = a.C || [2], ge(c, a);
                ee(c, "gcl_aw", 2)
            } else Sb(a, "_gb") && ee(c, "gcl_gb", 2);
        c.sort(function(d, e) {
            return e.timestamp - d.timestamp
        });
        return he(c)
    }

    function ie(a, b) {
        var c = [];
        a = w(a);
        var d = a.next(),
            e;
        try {
            for (; !d.done; d = a.next()) {
                var f = d.value;
                u(c, "includes").call(c, f) || c.push(f)
            }
        } finally {
            d && !d.done && (e = a.return) && e.call(a)
        }
        b = w(b);
        e = b.next();
        var g;
        try {
            for (; !e.done; e = b.next()) {
                var h = e.value;
                u(c, "includes").call(c, h) || c.push(h)
            }
        } finally {
            e && !e.done && (g = b.return) && g.call(b)
        }
        return c
    }

    function ge(a, b, c) {
        c = c === void 0 ? !1 : c;
        var d, e = w(a),
            f = e.next(),
            g;
        try {
            for (; !f.done; f = e.next()) {
                var h = f.value;
                if (h.A === b.A) {
                    var k = h;
                    break
                }
                h.B && b.B && h.B.value === b.B.value && (d = h)
            }
        } finally {
            f && !f.done && (g = e.return) && g.call(e)
        }
        if (k) {
            a = k;
            var l, m;
            c = (l = k.B) != null ? l : new S;
            l = (m = b.B) != null ? m : new S;
            c.value |= l.value;
            a.B = c;
            k.timestamp < b.timestamp && (k.timestamp = b.timestamp, k.I = b.I);
            k.labels = ie(k.labels || [], b.labels || []);
            k.C = ie(k.C || [], b.C || [])
        } else c && d ? u(Object, "assign").call(Object, d, b) : a.push(b)
    }

    function fe() {
        var a = Ic("gclid");
        if (!a || a.error || !a.value || typeof a.value !== "object") return null;
        a = a.value;
        try {
            if (!("value" in a && a.value) || typeof a.value !== "object") return null;
            var b = a.value,
                c = b.value;
            if (!c || !c.match(Rd)) return null;
            var d = b.linkDecorationSource,
                e = b.linkDecorationSources,
                f = new S;
            if (typeof d === "number")
                if (d) {
                    var g = new S;
                    d === 1 ? (Nd(g, 2), Nd(g, 3)) : Nd(g, d);
                    f = g
                } else f = new S;
            else typeof e === "number" && (f.value = e);
            return {
                version: "",
                A: c,
                timestamp: Number(b.creationTimeMs) || 0,
                labels: [],
                B: f,
                C: [2]
            }
        } catch (h) {
            return null
        }
    }

    function je(a) {
        a = Ic(a);
        if (a.error !== 0) return null;
        try {
            return a.value.reduce(function(b, c) {
                if (!c.value || typeof c.value !== "object") return b;
                var d = c.value,
                    e = d.value;
                if (!e || !e.match(Rd)) return b;
                var f = new S,
                    g = d.linkDecorationSources;
                typeof g === "number" && (f.value = g);
                var h;
                b.push({
                    version: "",
                    A: e,
                    timestamp: Number(d.creationTimeMs) || 0,
                    expires: Number(c.expires) || 0,
                    labels: (h = d.labels) != null ? h : [],
                    B: f,
                    C: [2]
                });
                return b
            }, [])
        } catch (b) {
            return null
        }
    }

    function ee(a, b, c) {
        if (c === 1) {
            var d = Qc(b, N.cookie, void 0, V());
            d = w(d);
            var e = d.next(),
                f;
            try {
                for (; !e.done; e = d.next()) {
                    var g = ke(e.value.split(".")),
                        h = g.length === 0 ? null : {
                            version: g[0],
                            A: g[2],
                            timestamp: (Number(g[1]) || 0) * 1E3,
                            labels: g.slice(3)
                        };
                    h != null && (h.I = void 0, h.B = new S, h.C = [c], ge(a, h))
                }
            } finally {
                e && !e.done && (f = d.return) && f.call(d)
            }
        } else if (c === 2 && (c = je(b))) {
            c = w(c);
            f = c.next();
            try {
                for (; !f.done; f = c.next()) e = f.value, e.I = void 0, ge(a, e)
            } finally {
                f && !f.done && (d = c.return) && d.call(c)
            }
        }
    }

    function ae(a) {
        return de(a).map(function(b) {
            b.B = new S;
            b.C = [1];
            return b
        })
    }

    function ce(a, b) {
        if (!a.length) return b;
        if (!b.length) return a;
        var c = {};
        return a.concat(b).filter(function(d) {
            return c.hasOwnProperty(d) ? !1 : c[d] = !0
        })
    }

    function Zd(a) {
        return a && typeof a === "string" && a.match(Qd) ? a : "_gcl"
    }

    function le(a, b) {
        var c = Cc(a);
        a = yc(c, "query", !1, void 0, "gclid");
        var d = yc(c, "query", !1, void 0, "gclsrc"),
            e = yc(c, "query", !1, void 0, "wbraid");
        if (e) {
            var f = e;
            try {
                f = decodeURIComponent(e)
            } catch (k) {}
            f = f.split(",");
            e = f.length === 2 && f[0] === f[1] ? f[0] : e
        }
        f = yc(c, "query", !1, void 0, "gbraid");
        var g = yc(c, "query", !1, void 0, "gad_source"),
            h = yc(c, "query", !1, void 0, "dclid");
        !b || a && d && e && f || (b = c.hash.replace("#", ""), a = a || xc(b, "gclid"), d = d || xc(b, "gclsrc"), e = e || xc(b, "wbraid"), f = f || xc(b, "gbraid"), g = g || xc(b, "gad_source"));
        return me(a,
            d, h, e, f, g)
    }

    function me(a, b, c, d, e, f) {
        function g(k, l) {
            h[l] || (h[l] = []);
            h[l].push(k)
        }
        var h = {};
        h.gclid = a;
        h.gclsrc = b;
        h.dclid = c;
        if (a !== void 0 && a.match(Rd)) switch (b) {
            case void 0:
                g(a, "aw");
                break;
            case "aw.ds":
                g(a, "aw");
                g(a, "dc");
                break;
            case "ds":
                g(a, "dc");
                break;
            case "3p.ds":
                g(a, "dc");
                break;
            case "gf":
                g(a, "gf");
                break;
            case "ha":
                g(a, "ha")
        }
        c && g(c, "dc");
        d !== void 0 && Rd.test(d) && (h.wbraid = d, g(d, "gb"));
        e !== void 0 && Rd.test(e) && (h.gbraid = e, g(e, "ag"));
        f !== void 0 && Rd.test(f) && (h.gad_source = f, g(f, "gs"));
        return h
    }

    function ne(a, b) {
        function c() {
            if (W(d) && a.length > 0) {
                var e = je("gcl_gb") || [];
                a.forEach(function(f) {
                    var g = Dc(b, f.timestamp, !0);
                    g.expires !== void 0 && ge(e, {
                        version: "",
                        A: f.A,
                        timestamp: f.timestamp,
                        expires: Number(g.expires),
                        B: f.B,
                        labels: f.labels
                    }, !0)
                });
                e.length && Fc("gcl_gb", e.map(function(f) {
                    var g = {
                            value: f.A,
                            creationTimeMs: f.timestamp,
                            linkDecorationSources: f.B ? f.B.get() : 0
                        },
                        h;
                    if ((h = f.labels) == null ? 0 : h.length) g.labels = f.labels;
                    return {
                        value: g,
                        expires: Number(f.expires)
                    }
                }))
            }
        }
        b = b || {};
        var d = V();
        tc(function() {
            W(d) ?
                c() : uc(c, d)
        }, d)
    }

    function oe(a, b, c, d, e) {
        function f() {
            if (W(l)) {
                var t = Dc(c, h, !0);
                t.K = l;
                var x = function(E, Ib) {
                        var ea = $d(E, g);
                        ea && (cd(ea, Ib, t), E !== "gb" && (m = !0))
                    },
                    D = function(E) {
                        E = ["GCL", k, E];
                        e.length > 0 && E.push(e.join("."));
                        return E.join(".")
                    },
                    O = w(["aw", "dc", "gf", "ha", "gp"]),
                    U = O.next(),
                    Y;
                try {
                    for (; !U.done; U = O.next()) {
                        var B = U.value;
                        a[B] && x(B, D(a[B][0]))
                    }
                } finally {
                    U && !U.done && (Y = O.return) && Y.call(O)
                }
                if ((!m || r) && a.gb) {
                    var pa = a.gb[0];
                    O = $d("gb", g);
                    !b && Xd(O).some(function(E) {
                        return E.A === pa && E.labels && E.labels.length > 0
                    }) || x("gb",
                        D(pa))
                }
            }
            if (!p && a.gbraid && W("ad_storage") && (p = !0, !m || r)) {
                var va = a.gbraid;
                x = $d("ag", g);
                if (b || !ae(x).some(function(E) {
                        return E.A === va && E.labels && E.labels.length > 0
                    })) D = {}, D = (D.k = va, D.i = "" + k, D.b = e, D), Ld(x, D, c, h)
            }
            pe(a, g, h, c)
        }
        c = c || {};
        e = e || [];
        var g = Zd(c.prefix),
            h = d || Rb(),
            k = Math.round(h / 1E3),
            l = V(),
            m = !1,
            p = !1,
            r = Q(6);
        tc(function() {
            f();
            W(l) || uc(f, l)
        }, l)
    }

    function pe(a, b, c, d) {
        if (a.gad_source !== void 0 && W("ad_storage")) {
            var e = hc();
            if (e !== "r" && e !== "h" && (b = $d("gs", b))) {
                e = (e = M.performance) && Nb(e.now) ? e.now() : void 0;
                e = Math.floor((Rb() - (e || 0)) / 1E3);
                var f = M.location.hostname;
                var g = M.location.pathname;
                f = Tb(f);
                f.split(".").length > 2 && (f = f.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
                g = Tb(g);
                g = g.split(";")[0];
                g = g.replace(/\/(ar|slp|web|index)?\/?$/, "");
                g = (f + g).toLowerCase();
                f = 1;
                var h;
                if (g)
                    for (f = 0, h = g.length - 1; h >= 0; h--) {
                        var k = g.charCodeAt(h);
                        f =
                            (f << 6 & 268435455) + k + (k << 14);
                        k = f & 266338304;
                        f = k !== 0 ? f ^ k >> 21 : f
                    }
                g = String(f);
                f = {};
                a = (f.k = a.gad_source, f.i = "" + e, f.u = g, f);
                Ld(b, a, d, c)
            }
        }
    }

    function $d(a, b) {
        a = Ud[a];
        if (a !== void 0) return b + a
    }

    function qe(a) {
        return ke(a.split(".")).length !== 0 ? (Number(a.split(".")[1]) || 0) * 1E3 : 0
    }

    function ke(a) {
        return a.length < 3 || a[0] !== "GCL" && a[0] !== "1" || !/^\d+$/.test(a[1]) || !Rd.test(a[2]) ? [] : a
    }

    function he(a) {
        return a.filter(function(b) {
            return Rd.test(b.A)
        })
    }

    function re() {
        var a = ["aw"],
            b = {};
        if (M.origin !== "null") {
            for (var c = Zd(b.prefix), d = {}, e = 0; e < a.length; e++) Ud[a[e]] && (d[a[e]] = Ud[a[e]]);
            Vd(function() {
                var f = w(u(Object, "entries").call(Object, d)),
                    g = f.next(),
                    h;
                try {
                    for (; !g.done; g = f.next()) {
                        var k = w(g.value),
                            l = k.next().value,
                            m = k.next().value,
                            p = l,
                            r = Qc(c + m, N.cookie, void 0, V());
                        r.sort(function(Y, B) {
                            return qe(B) - qe(Y)
                        });
                        if (r.length) {
                            var t = r[0],
                                x = qe(t),
                                D = ke(t.split(".")).length !== 0 ? t.split(".").slice(3) : [],
                                O = {};
                            var U = ke(t.split(".")).length !== 0 ? t.split(".")[2] : void 0;
                            O[p] = [U];
                            oe(O, !0, b, x, D)
                        }
                    }
                } finally {
                    g && !g.done && (h = f.return) && h.call(f)
                }
            })
        }
    }

    function se(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        var f = [];
        c = c || {};
        if (!W(V())) return f;
        var g = Xd(a, e);
        var h = [];
        if (g.length !== 0)
            for (var k = {}, l = 0; l < g.length; l++) {
                var m = g[l],
                    p = m.aa ? m.aa : "gcl";
                if ((m.labels || []).indexOf(b) === -1) {
                    f.push(0);
                    var r = !1,
                        t = void 0;
                    if ((t = m.C) == null ? 0 : u(t, "includes").call(t, 2)) r = !0;
                    t = void 0;
                    ((t = m.C) == null ? 0 : u(t, "includes").call(t, 1)) && !k[p] && (r = !0, k[p] = !0);
                    r && h.push(m)
                } else if (f.push(1), r = void 0, (r = m.C) == null ? 0 : u(r, "includes").call(r, 1)) k[p] = !0
            }
        if (h.length && !d) {
            d = [];
            g = !1;
            h = w(h);
            k = h.next();
            var x;
            try {
                for (; !k.done; k = h.next()) {
                    var D = k.value;
                    l = D;
                    var O = l.version,
                        U = l.A,
                        Y = l.timestamp,
                        B = l.C,
                        pa = (l.labels || []).concat([b]);
                    l = void 0;
                    if (((l = B) == null ? 0 : u(l, "includes").call(l, 1)) && !g) {
                        var va = [O, Math.round(Y / 1E3), U].concat(pa).join("."),
                            E = Dc(c, Y, !0);
                        E.K = V();
                        cd(a, va, E);
                        g = !0
                    }
                    l = void 0;
                    e && ((l = B) == null ? 0 : u(l, "includes").call(l, 2)) && d.push(u(Object, "assign").call(Object, {}, D, {
                        labels: pa
                    }))
                }
            } finally {
                k && !k.done && (x = h.return) && x.call(h)
            }
            d.length && ne(d, c)
        }
        return f
    }

    function te(a, b) {
        b = Zd(b);
        b = $d(a, b);
        if (!b) return 0;
        a = a === "ag" ? ae(b) : Xd(b);
        for (var c = b = 0; c < a.length; c++) b = Math.max(b, a[c].timestamp);
        return b
    }

    function ue(a) {
        var b = 0,
            c = w(u(Object, "keys").call(Object, a)),
            d = c.next(),
            e;
        try {
            for (; !d.done; d = c.next())
                for (var f = a[d.value], g = 0; g < f.length; g++) b = Math.max(b, Number(f[g].timestamp))
        } finally {
            d && !d.done && (e = c.return) && e.call(c)
        }
        return b
    };
    var ve = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        we = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        xe = /^\d+\.fls\.doubleclick\.net$/,
        ye = /;gac=([^;?]+)/,
        ze = /;gacgb=([^;?]+)/;

    function Ae(a, b, c) {
        if (xe.test(a.location.host)) {
            if ((b = a.location.href.match(c)) && b.length === 2 && b[1].match(ve)) {
                a: {
                    try {
                        var d = decodeURIComponent(b[1]);
                        break a
                    } catch (l) {}
                    d = void 0
                }
                b = d || ""
            }
            else b = "";
            return b
        }
        d = [];
        a = w(u(Object, "keys").call(Object, b));
        c = a.next();
        var e;
        try {
            for (; !c.done; c = a.next()) {
                for (var f = c.value, g = [], h = b[f], k = 0; k < h.length; k++) g.push(h[k].A);
                d.push(f + ":" + g.join(","))
            }
        } finally {
            c && !c.done && (e = a.return) && e.call(a)
        }
        return d.length > 0 ? d.join(";") : ""
    }

    function Be(a, b, c, d) {
        var e = W(V()) ? Pd("_gac_gb", !0) : {},
            f = [],
            g = !1,
            h = w(u(Object, "keys").call(Object, e)),
            k = h.next(),
            l;
        try {
            for (; !k.done; k = h.next()) {
                var m = k.value,
                    p = se("_gac_gb_" + m, b, c, d);
                g = g || p.length !== 0 && p.some(function(r) {
                    return r === 1
                });
                f.push(m + ":" + p.join(","))
            }
        } finally {
            k && !k.done && (l = h.return) && l.call(h)
        }
        return {
            la: g ? f.join(";") : "",
            ka: Ae(a, e, ze)
        }
    }

    function Ce(a, b) {
        return (a = a.location.href.match(new RegExp(";" + b + "=([^;?]+)"))) && a.length === 2 && a[1].match(we) ? a[1] : void 0
    }

    function De(a, b) {
        a = a.split(".");
        b = b ? b.split(".") : [];
        var c = b.length === a.length ? b : void 0;
        return a.map(function(d, e) {
            d = {
                A: d
            };
            if (c && (e = c[e].split("_"), e.length === 2)) {
                d.B = new S(Number(e[0]));
                e = Number(e[1]);
                if (e === 0) e = [0];
                else {
                    var f = [];
                    e & 1 && f.push(1);
                    e & 2 && f.push(2);
                    e & 4 && f.push(3);
                    e & 8 && f.push(4);
                    e & 16 && f.push(5);
                    e = f
                }
                d.C = e
            }
            return d
        })
    }

    function Ee(a, b, c, d) {
        var e = e === void 0 ? !1 : e;
        if (xe.test(a.location.host)) {
            var f = Ce(a, d);
            if (f) {
                if (Q(12)) {
                    var g = Ce(a, d + "_src");
                    return De(f, g)
                }
                if (e) {
                    var h = new S;
                    Nd(h, 2);
                    Nd(h, 3);
                    return f.split(".").map(function(k) {
                        return {
                            A: k,
                            B: h,
                            C: [1]
                        }
                    })
                }
                return f.split(".").map(function(k) {
                    return {
                        A: k,
                        B: new S,
                        C: [1]
                    }
                })
            }
        } else {
            if (c === "gclid") {
                a = Xd((b || "_gcl") + "_aw", e);
                d = Number(nc[1] === void 0 ? 0 : nc[1]);
                e = w(Fe());
                b = e.next();
                try {
                    for (; !b.done; b = e.next()) g = b.value, g.timestamp > d && ge(a, g)
                } finally {
                    b && !b.done && (f = e.return) && f.call(e)
                }
                return a
            }
            if (c ===
                "wbraid") return Xd((b || "_gcl") + "_gb", e);
            if (c === "braids") return Yd({
                prefix: b
            }, e)
        }
        return []
    }

    function Fe() {
        return (Jd(Td.aw, 4) || []).filter(function(a) {
            return a.m === "1"
        }).map(function(a) {
            return {
                A: a.k,
                timestamp: Number(a.i),
                version: "",
                C: [5]
            }
        })
    }

    function Ge(a, b) {
        return Ee(a, b, "gclid", "gclaw").map(function(c) {
            return c.A
        }).join(".")
    }

    function He(a, b) {
        return Ee(a, b, "wbraid", "gclgb").map(function(c) {
            return c.A
        }).join(".")
    }

    function Ie(a) {
        if (Wd("_gcl_aw").length === 0 && (!a || Wd(a + "_aw").length === 0)) {
            a = le(M.location.href, !0);
            var b = !0,
                c = w(u(Object, "keys").call(Object, a)),
                d = c.next(),
                e;
            try {
                for (; !d.done; d = c.next())
                    if (a[d.value] !== void 0) {
                        b = !1;
                        break
                    }
            } finally {
                d && !d.done && (e = c.return) && e.call(c)
            }
            b && (a = le(M.document.referrer, !1), a.gad_source = void 0);
            oe(a, !1, {});
            re()
        }
    }

    function Je(a, b, c) {
        a = se((b && b.prefix || "_gcl") + "_gb", a, b, c, !1);
        return a.length === 0 || a.every(function(d) {
            return d === 0
        }) ? "" : a.join(".")
    };

    function Ke() {
        var a = M.__uspapi;
        if (Nb(a)) {
            var b = "";
            try {
                a("getUSPData", 1, function(c, d) {
                    d && c && (c = c.uspString) && RegExp("^[\\da-zA-Z-]{1,20}$").test(c) && (b = c)
                })
            } catch (c) {}
            return b
        }
    };

    function Le() {
        var a = a === void 0 ? document : a;
        var b;
        return !((b = a.featurePolicy) == null || !(aa = b.allowedFeatures(), u(aa, "includes")).call(aa, "attribution-reporting"))
    };
    var Me = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Ne(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function Oe(a) {
        a = a.google_tag_data;
        if (a != null && a.uach) {
            a = a.uach;
            var b = u(Object, "assign").call(Object, {}, a);
            a.fullVersionList && (b.fullVersionList = a.fullVersionList.slice(0));
            a = b
        } else a = null;
        return a
    }

    function Pe(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function Qe() {
        var a = window;
        if (Pe(a)) {
            var b = Ne(a);
            b.uach_promise || (a = a.navigator.userAgentData.getHighEntropyValues(Me).then(function(c) {
                b.uach != null || (b.uach = c);
                return c
            }), b.uach_promise = a)
        }
    };
    var Re = /^[a-zA-Z0-9_]+$/,
        Se = !1,
        Te = "google_conversion_id google_conversion_format google_conversion_type google_conversion_order_id google_conversion_language google_conversion_value google_conversion_currency google_conversion_domain google_conversion_label google_conversion_color google_disable_viewthrough google_enable_display_cookie_match google_gtag_event_data google_remarketing_only google_conversion_linker google_tag_for_child_directed_treatment google_tag_for_under_age_of_consent google_allow_ad_personalization_signals google_restricted_data_processing google_conversion_items google_conversion_merchant_id google_user_id google_custom_params google_conversion_date google_conversion_time google_conversion_js_version onload_callback opt_image_generator google_gtm_url_processor google_conversion_page_url google_conversion_referrer_url google_gcl_cookie_prefix google_gcl_cookie_path google_gcl_cookie_flags google_gcl_cookie_domain google_gcl_cookie_max_age_seconds google_read_gcl_cookie_opt_out google_basket_feed_country google_basket_feed_language google_basket_discount google_basket_transaction_type google_additional_conversion_params google_additional_params google_transport_url google_gtm_experiments".split(" "),
        Ue = ["google_conversion_first_time", "google_conversion_snippets"];

    function Ve(a) {
        return a != null ? encodeURIComponent(String(a)) : ""
    }

    function We(a) {
        if (a != null) {
            a = String(a).substring(0, 512);
            var b = a.indexOf("#");
            return b == -1 ? a : a.substring(0, b)
        }
        return ""
    }

    function X(a, b) {
        b = Ve(b);
        return b != "" && (a = Ve(a), a != "") ? "&".concat(a, "=", b) : ""
    }

    function Xe(a) {
        var b = typeof a;
        return a == null || b == "object" || b == "function" ? null : String(a).replace(/,/g, "\\,").replace(/;/g, "\\;").replace(/=/g, "\\=")
    }

    function Ye(a) {
        if (!a || typeof a != "object" || typeof a.join == "function") return "";
        var b = [],
            c;
        for (c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                var d = a[c];
                if (d && typeof d.join === "function") {
                    for (var e, f = [], g = 0; g < d.length; ++g) e = Xe(d[g]), e != null && f.push(e);
                    d = f.length == 0 ? null : f.join(",")
                } else d = Xe(d);
                (e = Xe(c)) && d != null && b.push(e + "=" + d)
            }
        return b.join(";")
    }

    function Ze(a) {
        return typeof a != "number" && typeof a != "string" ? "" : Ve(a.toString())
    }

    function $e(a, b) {
        if (b.google_read_gcl_cookie_opt_out || b.google_remarketing_only || b.google_conversion_domain && (!b.google_gcl_cookie_prefix || !/^_ycl/.test(b.google_gcl_cookie_prefix))) return "";
        var c = "",
            d = af(b),
            e = {};
        b.google_gcl_cookie_domain && (e.domain = b.google_gcl_cookie_domain);
        b.google_gcl_cookie_flags && (e.flags = b.google_gcl_cookie_flags);
        b.google_gcl_cookie_max_age_seconds != null && (e.U = b.google_gcl_cookie_max_age_seconds);
        b.google_gcl_cookie_path && (e.path = b.google_gcl_cookie_path);
        d && (e.prefix = d);
        if (bf(b) && b.R) var f = b.O === void 0;
        else xe.test(a.location.host) ? f = !(Ce(a, "gclaw") || Ce(a, "gac")) : (f = Math.max(te("aw", d), ue(W(V()) ? Pd() : {})), f = Math.max(te("gb", d), ue(W(V()) ? Pd("_gac_gb", !0) : {})) > f);
        if (f) {
            if (b.O !== void 0) return b.O;
            c = He(a, d || void 0);
            f = b.google_conversion_label;
            var g = Je(f, e, b.R);
            c = X("gclgb", c) + (g ? X("mcov", g) : "");
            if (d) return b.O = c;
            d = Be(a, f, e, b.R);
            a = d.ka;
            d = d.la;
            c += (a ? X("gacgb", a) : "") + (d ? X("gacmcov", d) : "");
            return b.O = c
        }
        if (d) return b = Ge(a, d), X("gclaw", b);
        (b = Ge(a)) && (c = X("gclaw", b));
        b = Ae(a,
            W(V()) ? Pd() : {}, ye);
        return c + (b ? X("gac", b) : "")
    }

    function cf(a) {
        function b(d) {
            try {
                return decodeURIComponent(d), !0
            } catch (e) {
                return !1
            }
        }
        a = a ? a.title : "";
        if (a == void 0 || a == "") return "";
        a = encodeURIComponent(a);
        for (var c = 256; !b(a.substr(0, c));) c--;
        return "&tiba=" + a.substr(0, c)
    }

    function df(a, b, c, d) {
        var e = "https://",
            f = c.google_conversion_type === "landing" ? "/extclk" : "/";
        switch (d) {
            default: return "";
            case 2:
                    case 3:
                    var g = "googleads.g.doubleclick.net/";
                var h = "pagead/viewthroughconversion/";
                break;
            case 1:
                    g = "www.google.com/";h = "pagead/1p-conversion/";
                break;
            case 6:
                    g = "www.google.com/";h = "ccm/conversion/";
                break;
            case 0:
                    g = c.google_conversion_domain || "www.googleadservices.com/";h = "pagead/conversion/";
                break;
            case 5:
                    g = c.google_conversion_domain || "www.googleadservices.com/";h = "ccm/conversion/";
                break;
            case 4:
                    g = (g = c.google_gtm_experiments) && g.apcm ? "www.google.com" : g && g.capiorig ? c.google_conversion_id + ".privacysandbox.googleadservices.com" : "www.google.com/",
                h = "pagead/privacysandbox/conversion/"
        }
        qb && c.google_transport_url && (g = c.google_transport_url);
        g[g.length - 1] !== "/" && (g += "/");
        if (g.indexOf("http://") === 0 || g.indexOf("https://") === 0) e = "";
        e = [e, g, h, Ve(c.google_conversion_id), f, "?random=", Ve(c.google_conversion_time)].join("");
        f = X("cv", c.google_conversion_js_version);
        g = X("fst", c.google_conversion_first_time);
        h = X("num", c.google_conversion_snippets);
        var k = X("fmt", c.google_conversion_format),
            l = c.google_remarketing_only ? X("userId", c.google_user_id) : "";
        var m = c.google_tag_for_child_directed_treatment;
        m = m == null || m !== 0 && m !== 1 ? "" : X("tfcd", m);
        var p = c.google_tag_for_under_age_of_consent;
        p = p == null || p !== 0 && p !== 1 ? "" : X("tfua", p);
        var r = c.google_allow_ad_personalization_signals;
        r = r === !1 ? X("npa", 1) : r === !0 ? X("npa", 0) : "";
        var t = c.google_restricted_data_processing;
        t = sb ? t === !0 ? X("rdp", 1) : t === !1 ? X("rdp", 0) : "" : "";
        var x = X("value",
                c.google_conversion_value),
            D = X("currency_code", c.google_conversion_currency),
            O = X("label", c.google_conversion_label),
            U = X("oid", c.google_conversion_order_id),
            Y = X("bg", c.google_conversion_color);
        a: {
            var B = c.google_conversion_language;
            if (B != null) {
                B = B.toString();
                if (2 == B.length) {
                    B = X("hl", B);
                    break a
                }
                if (5 == B.length) {
                    B = X("hl", B.substring(0, 2)) + X("gl", B.substring(3, 5));
                    break a
                }
            }
            B = ""
        }
        var pa = X("guid", "ON"),
            va = !c.google_conversion_domain && "GooglemKTybQhCsO" in ta && typeof ta.GooglemKTybQhCsO == "function" ? X("resp",
                "GooglemKTybQhCsO") : "",
            E = X("disvt", c.google_disable_viewthrough),
            Ib = X("eid", yb().join());
        var ea = [];
        if (a) {
            var Ka = a.screen;
            Ka && (ea.push(X("u_h", Ka.height)), ea.push(X("u_w", Ka.width)))
        }
        ea = ea.join("");
        Ka = ef();
        var tf = X("ig", /googleadservices\.com/.test("www.googleadservices.com") ? 1 : 0);
        var ra = Ye(c.google_custom_params);
        var cb = Ye();
        ra = ra.concat(ra.length > 0 && cb.length > 0 ? ";" : "", cb);
        ra = ra == "" ? "" : "&".concat("data=", encodeURIComponent(ra));
        cb = $e(b, c);
        if (!H || I(23) != "658953496" && I(23) != "658953495" || c.google_read_gcl_cookie_opt_out ||
            c.google_conversion_domain || c.google_remarketing_only) var fa = "";
        else {
            fa = af(c);
            var y = {};
            c.google_gcl_cookie_domain && (y.domain = c.google_gcl_cookie_domain);
            c.google_gcl_cookie_flags && (y.flags = c.google_gcl_cookie_flags);
            c.google_gcl_cookie_max_age_seconds != null && (y.U = c.google_gcl_cookie_max_age_seconds);
            c.google_gcl_cookie_path && (y.path = c.google_gcl_cookie_path);
            fa && (y.prefix = fa);
            var K = !1;
            K = K === void 0 ? !0 : K;
            var z = od(y.prefix);
            if (id[z]) kd(y), ld(y);
            else if (nd(z, y.path, y.domain)) {
                z = jd[od(y.prefix)] || {
                    id: void 0,
                    J: void 0
                };
                if (K) {
                    K = od(y.prefix);
                    var A = id[K];
                    if (A) {
                        var Z = A.split(".");
                        if (Z.length === 2 && (Z = Number(Z[1]) || 0)) {
                            var F = A;
                            Q(13) && z.ba ? F = A + "." + (z.sessionId || "-.-") + "." + (z.J ? z.J : Math.floor(Rb() / 1E3)) + "." + z.ba + "." + (z.P ? z.P : Math.floor(Rb() / 1E3)) : z.sessionId && (F = A + "." + z.sessionId + "." + (z.J ? z.J : Math.floor(Rb() / 1E3)));
                            md(K, F, y, Z * 1E3)
                        }
                    }
                }
                kd(y);
                ld(y)
            } else {
                b: {
                    A = Cc(M.location.href);
                    if ((Z = yc(A, "host", !1)) && Z.match(wc) && (A = yc(A, "path")) && (A = A.split("auiddc="), A.length > 1)) {
                        A = A[1].split(";")[0].split("?")[0];
                        break b
                    }
                    A = void 0
                }
                A ?
                (J(17), id[z] = A) : K && (md(od(y.prefix), [String(Math.round(Math.random() * 2147483647)), Math.round(Rb() / 1E3)].join("."), y), nd(z, y.path, y.domain), kd(y, !0), ld(y, !0))
            }
            fa = (fa = id[od(fa)]) ? X("auid", fa) : ""
        }
        A = c.google_conversion_page_url;
        y = c.google_conversion_referrer_url;
        K = "";
        if (b) {
            z = a.top == a ? 0 : (z = a.location.ancestorOrigins) ? z[z.length - 1] == a.location.origin ? 1 : 2 : ya(a.top) ? 1 : 2;
            A = A ? A : z == 1 ? a.top.location.href : a.location.href;
            Z = "";
            H && G(["509562772", "509562773"], mb, 21);
            if (H && (I(21) == "509562773" || I(21) == "509562772")) {
                for (var L,
                        wa = F = a; F && F !== F.parent;) F = F.parent, ya(F) && (wa = F);
                L = wa;
                F = L.location.href;
                if (L === L.top) var P = {
                    url: F,
                    oa: !0
                };
                else {
                    wa = !1;
                    var Ob = L.document;
                    Ob && Ob.referrer && (F = Ob.referrer, L.parent === L.top && (wa = !0));
                    (L = L.location.ancestorOrigins) && (L = L[L.length - 1]) && ((P = F) == null ? void 0 : P.indexOf(L)) === -1 && (wa = !1, F = L);
                    P = {
                        url: F,
                        oa: wa
                    }
                }
                P.url && A !== P.url && (Z = P.url)
            }
            K += X("frm", z);
            K += X("url", We(A));
            K += X("ref", We(y || b.referrer));
            K += X("top", We(Z))
        }
        a = [f, g, h, k, l, m, p, r, t, x, D, O, U, Y, B, pa, va, E, Ib, ea, Ka, tf, ra, cb, fa, K, cf(b), ff(c.google_additional_params),
            ff(c.google_remarketing_only ? {} : c.google_additional_conversion_params), "&hn=" + Ve("www.googleadservices.com"), gf(a), hf(a)
        ].join("");
        b = xb();
        a += b.length > 0 ? "&debug_experiment_id=" + b : "";
        if (!c.google_remarketing_only && !c.google_conversion_domain) {
            b = [X("mid", c.google_conversion_merchant_id), X("fcntr", c.google_basket_feed_country), X("flng", c.google_basket_feed_language), X("dscnt", c.google_basket_discount), X("bttype", c.google_basket_transaction_type)].join("");
            if (c)
                if (P = c.google_conversion_items) {
                    f = [];
                    g = 0;
                    for (h = P.length; g <
                        h; g++) k = P[g], l = [], k && (l.push(Ze(k.value)), l.push(Ze(k.quantity)), l.push(Ze(k.item_id)), l.push(Ze(k.start_date)), l.push(Ze(k.end_date)), f.push("(" + l.join("*") + ")"));
                    P = f.length > 0 ? "&item=" + f.join("") : ""
                } else P = "";
            else P = "";
            b = [a, b, P].join("");
            a = b.length > 4E3 ? [a, X("item", "elngth")].join("") : b
        }
        e += a;
        d === 1 || d === 6 ? e += [X("gcp", 1), X("sscte", 1), X("ct_cookie_present", 1)].join("") : d == 3 && (e += X("gcp", 1), e += X("ct_cookie_present", 1));
        rb && (d = Ke(), d !== void 0 && (e += X("us_privacy", d || "error")));
        bf(c) && (e = c.R ? e + X("gbcov",
            1) : e + X("gbcov", 0));
        return e
    }

    function jf(a, b, c, d, e, f, g) {
        return '<iframe name="' + a + '"' + (g ? ' id="' + g + '"' : "") + ' title="' + b + '" width="' + d + '" height="' + e + '"' + (c ? ' src="' + c + '"' : "") + ' frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true"' + (f ? ' style="display:none"' : "") + ' scrolling="no"></iframe>'
    }

    function kf(a) {
        return {
            ar: 1,
            bg: 1,
            cs: 1,
            da: 1,
            de: 1,
            el: 1,
            en_AU: 1,
            en_US: 1,
            en_GB: 1,
            es: 1,
            et: 1,
            fi: 1,
            fr: 1,
            hi: 1,
            hr: 1,
            hu: 1,
            id: 1,
            is: 1,
            it: 1,
            iw: 1,
            ja: 1,
            ko: 1,
            lt: 1,
            nl: 1,
            no: 1,
            pl: 1,
            pt_BR: 1,
            pt_PT: 1,
            ro: 1,
            ru: 1,
            sk: 1,
            sl: 1,
            sr: 1,
            sv: 1,
            th: 1,
            tl: 1,
            tr: 1,
            vi: 1,
            zh_CN: 1,
            zh_TW: 1
        }[a] ? a + ".html": "en_US.html"
    }

    function lf(a, b, c) {
        function d(h, k, l, m, p) {
            m = m ? ' style="display:none"' : "";
            return "<img " + (p && Cb() ? "attributionsrc " : "") + 'height="' + l + '" width="' + k + '" border="0" alt="" src="' + h + '"' + m + " />"
        }
        Bb() && Jb(2);
        var e = "";
        c.google_remarketing_only && c.google_enable_display_cookie_match && !Mb && (H && G(["376635470", "376635471"], jb, 2), e = c.google_remarketing_only && c.google_enable_display_cookie_match && !Mb && H && I(2) == "376635471" ? jf("google_cookie_match_frame", "Google cookie match frame", "https://bid.g.doubleclick.net/xbbe/pixel?d=KAE",
            1, 1, !0, null) : "");
        c.google_remarketing_only && !c.google_conversion_domain && H && G(["759238990", "759238991"], pb, 13);
        !c.google_remarketing_only || c.google_conversion_domain || H && (I(14) == "759248991" || I(14) == "759248990") || H && G(["759248990", "759248991"], ob, 14);
        c.google_conversion_linker !== !1 && Ie(c.google_gcl_cookie_prefix);
        var f = df(a, b, c, c.google_remarketing_only ? 2 : 0);
        if (c.google_conversion_format == 0 && c.google_conversion_domain == null) return '<a href="https://services.google.com/sitestats/' + (kf(c.google_conversion_language) +
            "?cid=" + Ve(c.google_conversion_id)) + '" target="_blank">' + d(f, 135, 27, !1, !1) + "</a>" + e;
        if (c.google_conversion_snippets !== void 0 && c.google_conversion_snippets > 1 || c.google_conversion_format == 3) {
            var g = f;
            c.google_conversion_domain == null && (g = c.google_conversion_format == 3 ? f : Ad(f, "fmt", 3));
            f = void 0;
            Cb() && !c.google_remarketing_only && (f = {
                attributionsrc: ""
            });
            return mf(a, b, c, g, f) ? e : d(g, 1, 1, !0, !c.google_remarketing_only) + e
        }
        g = null;
        !c.google_conversion_domain && mf(a, b, c, f) && (g = "goog_conv_iframe", f = "");
        return jf("google_conversion_frame",
            "Google conversion frame", f, c.google_conversion_format == 2 ? 200 : 300, c.google_conversion_format == 2 ? 26 : 13, !1, g) + e
    }

    function mf(a, b, c, d, e) {
        if (c.google_conversion_domain) return !1;
        try {
            return !!Bd(a, b, d, null, void 0, e)
        } catch (f) {
            return !1
        }
    }

    function nf(a) {
        if (a.google_conversion_type === "landing" || !a.google_conversion_id || a.google_remarketing_only && a.google_disable_viewthrough) return !1;
        a.google_conversion_date = new Date;
        a.google_conversion_time = a.google_conversion_date.getTime();
        a.google_conversion_snippets = typeof a.google_conversion_snippets === "number" && a.google_conversion_snippets > 0 ? a.google_conversion_snippets + 1 : 1;
        a.google_conversion_first_time === void 0 && (a.google_conversion_first_time = a.google_conversion_time);
        a.google_conversion_js_version =
            "9";
        a.google_conversion_format != 0 && a.google_conversion_format != 1 && a.google_conversion_format != 2 && a.google_conversion_format != 3 && (a.google_conversion_format = 3);
        a.google_enable_display_cookie_match !== !1 && (a.google_enable_display_cookie_match = !0);
        return !0
    }

    function of (a) {
        for (var b = 0; b < Te.length; b++) a[Te[b]] = null
    }

    function pf(a) {
        for (var b = {}, c = 0; c < Te.length; c++) {
            var d = Te[c],
                e = a[d];
            e == null || d !== "google_conversion_domain" && d !== "google_transport_url" || (e = e == null ? "" : Ma(Va(String(e))).toString());
            b[d] = e
        }
        for (c = 0; c < Ue.length; c++) b[Ue[c]] = a[Ue[c]];
        return b
    }

    function ef() {
        var a = "";
        Bb() && (a = Lb().map(function(b) {
            return b.join("-")
        }).join("_"));
        return X("li", a)
    }

    function gf(a) {
        if (!tb || !a.__gsaExp || !a.__gsaExp.id) return "";
        a = a.__gsaExp.id;
        if (!Nb(a)) return "";
        try {
            var b = Number(a());
            return isNaN(b) ? "" : X("gsaexp", b)
        } catch (c) {
            return ""
        }
    }

    function hf(a) {
        function b(d, e) {
            e != null && c.push(d + "=" + encodeURIComponent(e))
        }
        if (!Ab()) return "";
        a = Oe(a);
        if (!a) return "";
        var c = [];
        b("&uaa", a.architecture);
        b("&uab", a.bitness);
        b("&uam", a.model);
        b("&uap", a.platform);
        b("&uapv", a.platformVersion);
        a.wow64 != null && b("&uaw", a.wow64 ? "1" : "0");
        a.fullVersionList && b("&uafvl", a.fullVersionList.map(function(d) {
            return encodeURIComponent(d.brand || "") + ";" + encodeURIComponent(d.version || "")
        }).join("|"));
        return c.join("")
    }

    function ff(a) {
        if (!a) return "";
        var b = "",
            c;
        for (c in a) a.hasOwnProperty(c) && (b += X(c, a[c]));
        return b
    }

    function bf(a) {
        return (a = a.google_gtm_experiments) && a.gbcov ? !0 : !1
    }

    function af(a) {
        return a.google_gcl_cookie_prefix && a.google_gcl_cookie_prefix !== "_gcl" && Re.test(a.google_gcl_cookie_prefix) ? a.google_gcl_cookie_prefix : ""
    }

    function qf(a, b) {
        var c;
        if (c = !b.google_remarketing_only)
            if (b.google_transport_url || !H || I(19) != "375603261" && I(19) != "375603260") c = !1;
            else {
                b: {
                    if (!Se) {
                        hb("AzMBwcG8UIaKM1GV43UaxMDFsS7hsiLx0FXw9ULTOHJRGxkUVw+UPCxlzz5CudOm+WnidygXLcAHmad6rC6C9QEAAACUeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJBdHRyaWJ1dGlvblJlcG9ydGluZ0Nyb3NzQXBwV2ViIiwiZXhwaXJ5IjoxNzE0NTIxNTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ\x3d\x3d", a);
                        if (!Le() && !hb(/google\.com$/.test("www.googleadservices.com") ? "" : "A2kc5o2ErHAbqJvF2MHSdYtnc2Bp3n6Jn2kNeko6SgHH6zXBHn0+4BbAW2No9ylVJMkzJAPwMqCVHqXm+IF1DgQAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJQcml2YWN5U2FuZGJveEFkc0FQSXMiLCJleHBpcnkiOjE2OTUxNjc5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", a)) {
                            a = !1;
                            break b
                        }
                        Se = !0
                    }
                    a = Le()
                }
                c = a
            }
        c && (a = b.google_additional_conversion_params || {}, c = b.google_gtm_experiments, a.capi = c && c.apcm ? "2" : "1", b.google_additional_conversion_params = a)
    };
    var rf = la(["https://www.googletagmanager.com/debug/bootstrap"]),
        sf = !1,
        uf = document.currentScript && document.currentScript.src || "";

    function vf(a, b, c) {
        try {
            if (!sf && (sf = !0, !c.google_gtm)) {
                var d = void 0,
                    e = void 0,
                    f = yd(a.location.href, "gtm_debug");
                wf(f) && (d = 2);
                d || b.referrer.indexOf("https://tagassistant.google.com/") !== 0 || (d = 3);
                !d && Oa(b.cookie.split("; "), "__TAG_ASSISTANT=x") >= 0 && (d = 4);
                d || (e = b.documentElement.getAttribute("data-tag-assistant-present"), wf(e) && (d = 5));
                if (d) {
                    var g = "AW-" + (c.google_conversion_id || "");
                    if (!a["google.tagmanager.debugui2.queue"]) {
                        a["google.tagmanager.debugui2.queue"] = [];
                        var h = eb(rf),
                            k = new q.Map([
                                ["id", g],
                                ["src",
                                    "LEGACY"
                                ],
                                ["cond", d]
                            ]),
                            l = Ha(h).toString(),
                            m = l.split(/[?#]/),
                            p = /[?]/.test(l) ? "?" + m[1] : "";
                        var r = fb(m[0], p, /[#]/.test(l) ? "#" + (p ? m[2] : m[1]) : "", k);
                        var t = ib("SCRIPT", b);
                        Na(t, r);
                        var x = b.getElementsByTagName("script")[0];
                        x && x.parentNode && x.parentNode.insertBefore(t, x)
                    }
                    a["google.tagmanager.debugui2.queue"].push({
                        messageType: "LEGACY_CONTAINER_STARTING",
                        data: {
                            id: g,
                            scriptSource: uf
                        }
                    })
                }
            }
        } catch (D) {}
    }

    function wf(a) {
        if (a == null || a.length === 0) return !1;
        a = Number(a);
        var b = Date.now();
        return a < b + 3E5 && a > b - 9E5
    };

    function xf(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function yf(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function zf(a, b) {
        if (xf(b) === 3) return !1;
        a();
        return !0
    }

    function Af(a, b) {
        function c() {
            !f && zf(a, b) && (f = !0, typeof b.removeEventListener === "function" && b.removeEventListener(g, c, !1))
        }
        var d = d === void 0 ? !1 : d;
        if (!zf(a, b))
            if (d) {
                var e = function() {
                    typeof b.removeEventListener === "function" && b.removeEventListener("prerenderingchange", e, !1);
                    a()
                };
                typeof b.addEventListener === "function" && b.addEventListener("prerenderingchange", e, !1)
            } else {
                var f = !1,
                    g = yf(b);
                g && typeof b.addEventListener === "function" && b.addEventListener(g, c, !1)
            }
    };

    function Bf(a) {
        var b = a.id;
        a = u(Object, "assign").call(Object, {}, a);
        a = (delete a.id, a);
        if (u(Object, "keys").call(Object, a).length) throw Error("Invalid attribute(s): " + u(Object, "keys").call(Object, a));
        return bb({
            id: b
        })
    };
    H = new function() {
        var a = [];
        var b = 0,
            c;
        for (c in zb) a[b++] = zb[c];
        a = a === void 0 ? [] : a;
        this.Z = {};
        this.v = {};
        for (b = 0; b < a.length; ++b) this.v[a[b]] = ""
    };
    G(["466465925", "466465926"], lb, 20);
    Ab() && Qe();
    H && G(["592230570", "592230571"], kb, 16);
    Bb() && (Jb(1), Kb());

    function Cf(a, b, c, d) {
        function e(m, p, r) {
            r = r === void 0 ? function() {} : r;
            var t = new Image;
            t.onload = m;
            t.onerror = r;
            t.src = p
        }

        function f() {
            --g;
            if (g <= 0) {
                var m = qd(a, !1),
                    p = m[b];
                p && (delete m[b], m = p[0], typeof m === "function" && m())
            }
        }
        d = d === void 0 ? [] : d;
        var g = c.length + 1;
        if (c.length === 2) {
            var h = c[0],
                k = c[1];
            wd(h, 0, "rmt_tld", h.search(xd)) >= 0 && wd(h, 0, "ipr", h.search(xd)) >= 0 && !k.match(ud)[6] && (k += vd(h), c[1] = Ad(k, "rmt_tld", "1"))
        }
        for (h = {
                H: 0
            }; h.H < c.length; h = {
                H: h.H
            }, h.H++) {
            k = c[h.H];
            var l = yd(k, "fmt");
            switch (Number(l)) {
                case 1:
                case 2:
                    (l =
                        a.document.getElementById("goog_conv_iframe")) && !l.src ? cc(k, f, l) : e(f, k);
                    break;
                case 4:
                    Bd(a, a.document, k, f);
                    break;
                case 5:
                    if (a.navigator && a.navigator.sendBeacon)
                        if (a.navigator.sendBeacon(k, "")) {
                            f();
                            break
                        } else k = Ad(k, "sendb", 2);
                    k = Ad(k, "fmt", 3);
                    e(f, k);
                    break;
                default:
                    l = void 0, d && d[h.H] && (l = function(m) {
                        return function() {
                            fc(d[m.H]) && f()
                        }
                    }(h)), e(f, k, l)
            }
        }
        f()
    }
    for (var Df = ["GooglemKTybQhCsO"], Ef = ta, Ff; Df.length && (Ff = Df.shift());) Df.length || Cf === void 0 ? Ef[Ff] && Ef[Ff] !== Object.prototype[Ff] ? Ef = Ef[Ff] : Ef = Ef[Ff] = {} : Ef[Ff] = Cf;
    (function(a, b, c) {
        if (a) {
            vf(a, c, a);
            try {
                if (nf(a)) {
                    var d = pf(a);
                    H && G(["375603260", "375603261"], ub ? 1 : 0, 19);
                    H && G(["512247838", "512247839"], vb ? 1 : 0, 22);
                    H && G(["658953495", "658953496"], nb, 23);
                    if (xf(c) == 3) {
                        var e = "google_conversion_" + Math.floor(Math.random() * 1E9);
                        Pa(c, Bf({
                            id: e
                        }));
                        Af(function() {
                            try {
                                qf(c, d);
                                var f = c.getElementById(e);
                                if (f) {
                                    var g = Vb(lf(a, c, d));
                                    if (f.nodeType === 1 && /^(script|style)$/i.test(f.tagName)) throw Error("");
                                    f.innerHTML = Ma(g)
                                }
                            } catch (h) {}
                        }, c)
                    } else qf(c, d), Pa(c, Vb(lf(a, c, d)))
                }
            } catch (f) {} of (a)
        }
    })(window,
        navigator, document);
}).call(this);
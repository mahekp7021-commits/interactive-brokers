/*! 20261004-14-RELEASE */

function _defineProperty(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function _typeof(e) {
    "@babel/helpers - typeof";
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}! function(e) {
    var t = 'TFASC';
    t.indexOf("{jsScope}") > -1 && (t = "TRC"), e[t] || (e[t] = {})
}(window),
function(e, t) {
    e.TRC = e.TRC || {};
    var n = function e() {
            return !0
        },
        r = function n(r, i, o, a) {
            var s = r + "/" + encodeURIComponent(o || e.TRC.publisherId) + "/log/3" + "/" + i;
            return a && (s += "?" + t.TRCLogger.formatParams(a)), s
        },
        i = function t(r, i, a, s) {
            var c, l = new(e.XDomainRequest || e.XMLHttpRequest);
            return l.open(r, i), l.onload = "function" == typeof s ? s : n, l.onerror = n, l.ontimeout = n, l.onprogress = n, l.withCredentials = !0, a && o(l, a), l
        },
        o = function e(t, n) {
            for (var r in n) n.hasOwnProperty(r) && t.setRequestHeader(r, n[r])
        };
    e.TRC.TRCLogger = t.TRCLogger = {
        post: function n(o, a, s, c, l, u) {
            var f = r(o, a, c, l),
                d = i("POST", f);
            u && "function" == typeof e.navigator.sendBeacon ? e.navigator.sendBeacon(f, t.TRCLogger.formatBeaconParams(s)) : (d.setRequestHeader && d.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), d.send(t.TRCLogger.formatParams(s)))
        },
        get: function e(t, n, o, a, s) {
            if (o.headers) {
                var c = o.headers;
                delete o.headers
            }
            var l = r(t, n, a, o),
                u;
            i("GET", l, c, s).send()
        },
        formatParams: function e(t) {
            var n = [];
            for (var r in t)
                if (t.hasOwnProperty(r)) {
                    var i = t[r];
                    null !== i && "object" === _typeof(i) && (i = JSON.stringify(i)), n.push(encodeURIComponent(r) + "=" + encodeURIComponent(i))
                }
            return n.join("&")
        },
        formatBeaconParams: function e(t) {
            var n = "",
                r;
            for (var i in t)
                if (t.hasOwnProperty(i)) {
                    var o = t[i];
                    null !== o && "object" === _typeof(o) && (o = JSON.stringify(o)), n += i + "=" + encodeURIComponent(o) + "&"
                }
            return new Blob([n.slice(0, -1)], {
                type: "application/x-www-form-urlencoded"
            })
        },
        reportES: function e(n) {
            if (t && t.util && t.util.isPercentEnabled(TRCImpl.global, "enable-rbox-es-events")) {
                var r = TRCImpl && TRCImpl.global && TRCImpl.global["rbox-es-events-url"] || "https://vidanalytics.taboola.com/putes";
                r = r + "/" + n.index;
                var i = {
                    timestamp: (new Date).toISOString(),
                    name: n.name
                };
                for (var o in n.data) i[o] = n.data[o];
                if ("function" == typeof navigator.sendBeacon) navigator.sendBeacon(r, JSON.stringify(i));
                else {
                    var a = new XMLHttpRequest;
                    a.open("POST", r, !0), a.send(JSON.stringify(i))
                }
            }
        }
    }
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    if (t && !t.MessageDelayer) {
        var n = function n(r) {
                return function(n) {
                    var i = n.detail,
                        o = n.type,
                        a = "" + i[this.groupingKeyName],
                        s = this.delayedEventsMap[a],
                        c = t.eventUtils.getDateNow();
                    if (s) {
                        this.timeoutHandles[a] && (clearTimeout(this.timeoutHandles[a]), this.timeoutHandles[a] = null);
                        var l = [].concat(s);
                        this.delayedEventsMap[a] = [];
                        for (var u = 0; u < l.length; u++) {
                            var f = l[u],
                                d;
                            r(f.config).apply(e, [f.groupingKey, f.message, i, o, c - f.queueTime])
                        }
                    }
                }
            },
            r = n(function(e) {
                return e.successCallback
            }),
            i = n(function(e) {
                return e.failCallback
            }),
            o = function e(t, n) {
                var r = "" + t;
                this.timeoutHandles[r] || (this.timeoutHandles[r] = setTimeout(function() {
                    this.timeoutHandles[r] = null;
                    var e = {};
                    e[this.groupingKeyName] = t, i.call(this, {
                        detail: e,
                        type: "dt"
                    })
                }.bind(this), n))
            };
        t.MessageDelayer = function(e, n, o) {
            if (this.groupingKeyName = e, this.delayedEventsMap = {}, this.timeoutHandles = {}, t.eventUtils.safeAddEventListener(n, r.bind(this)), o)
                for (var a = 0; a < o.length; a++) t.eventUtils.safeAddEventListener(o[a], i.bind(this))
        }, t.MessageDelayer.prototype = {
            constructor: t.MessageDelayer,
            delayMessage: function e(n, r, i) {
                var a = "" + n;
                i.failCallback = i.failCallback || function() {}, this.delayedEventsMap[a] || (this.delayedEventsMap[a] = []), this.delayedEventsMap[a].push({
                    groupingKey: n,
                    message: r,
                    config: i,
                    queueTime: t.eventUtils.getDateNow()
                }), i.timeoutInMillis && o.call(this, n, i.timeoutInMillis)
            }
        }
    }
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e) {
    e.TRC = e.TRC || {}, e.TRC.sharedObjects = e.TRC.sharedObjects || {}, e.TRC.sharedObjects.loadedScripts = e.TRC.sharedObjects.loadedScripts || {}, e.TRC.sharedObjects.loadedPixels = e.TRC.sharedObjects.loadedPixels || {}
}(window),
function(e, t, n) {
    ! function() {
        if ("function" == typeof e.CustomEvent) return !1;

        function n(e, n) {
            n = n || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            };
            var r = t.createEvent("CustomEvent");
            return r.initCustomEvent(e, n.bubbles, n.cancelable, n.detail), r
        }
        n.prototype = e.Event.prototype, e.CustomEvent = n
    }(), n.eventUtils = n.eventUtils || {}, n.eventUtils.dispatchEvent = n.eventUtils.dispatchEvent || function(e, t) {
        "function" == typeof CustomEvent && document.dispatchEvent(new CustomEvent(e, {
            detail: t || {}
        }))
    }, n.eventUtils.safeAddEventListener = n.eventUtils.safeAddEventListener || function(e, t) {
        document.addEventListener(e, function(e) {
            try {
                t.call(this, e)
            } catch (e) {}
        })
    }, n.eventUtils.safeAddEventListenerToWindow = n.eventUtils.safeAddEventListenerToWindow || function(e, t) {
        window.addEventListener(e, function(e) {
            try {
                t.call(this, e)
            } catch (e) {}
        })
    }, n.eventUtils.getDateNow = n.eventUtils.getDateNow || function() {
        var e, t;
        if (Date.now) {
            if ("number" == typeof(e = Date.now())) return e;
            if ("number" == typeof(t = Number(e))) return t
        }
        return (new Date).getTime()
    }, n.eventUtils.hashString = n.eventUtils.hashString || function(e) {
        var t = 0;
        if (0 == e.length) return t;
        for (var n = 0; n < e.length; n++) {
            var r;
            t = (t << 5) - t + e.charCodeAt(n), t &= t
        }
        return t
    }, n.sharedEvents = n.sharedEvents || {
        PAGE_VIEW: "TRK_TFA_PAGE_VIEW",
        REQUEST_ID_CREATED: "TRK_TFA_REQUEST_ID_CREATED",
        REQUEST_ID_CREATION_TIMEOUT: "TRK_TFA_REQUEST_ID_CREATION_TIMEOUT",
        REQUEST_ID_CREATION_ERROR: "TRK_TFA_REQUEST_ID_CREATION_ERROR",
        REQUEST_ID_CREATION_JS_ERROR: "TRK_TFA_REQUEST_ID_CREATION_JS_ERROR",
        INVALID_TRK_RESPONSE: "TRK_TFA_INVALID_TRK_RESPONSE"
    }, n.publisherIdType = n.publisherIdType || {
        NAME: "n",
        ID: "i"
    }, n.pageViewInitiator = n.pageViewInitiator || {
        TRK: "trk",
        TFA: "tfa"
    }
}(window, document, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    e._tfa = e._tfa || [], e._tfa.config || (e._tfa.TfaConfig = function() {
        this.configMap = {}, this.trackedElements = []
    }, e._tfa.TfaConfig.prototype = {
        safeGet: function e(t, n, r) {
            var i, o, a;
            if (r && this.configMap[r]) i = "" + r;
            else {
                if (!this.firstPublisherId) return n;
                i = this.firstPublisherId
            }
            try {
                return void 0 === (a = (o = this.configMap[i])[t]) ? n : a
            } catch (e) {
                return n
            }
        },
        hasValidConfig: function e() {
            return !!this.firstPublisherId
        },
        addConfig: function e(t, n) {
            "string" == typeof n || n instanceof String || (this.firstPublisherId || (this.firstPublisherId = t), this.configMap["" + t] = n)
        },
        addTrackedElements: function e(t) {
            this.trackedElements = t
        }
    }, e._tfa.config = new e._tfa.TfaConfig, e._taboola = e._taboola || []), e._tfa.config.addConfig(1603492, {
        "tfa:allow-cross-domain-tracking": true,
        "tfa:event-host-map": {
            "pre_d_eng_tb": "trc-events.taboola.com"
        },
        "tfa:add-item-url:event-list": "*",
        "tfa:trk:is-unified-page-view": true,
        "eid:send-eid-encoded": true,
        "tfa-uid:send-ids-to-cds": false,
        "cds:send-uad-req": true,
        "cds:send-dnid-req": true,
        "tfa:get-publisher-id-from-baker": true,
        "tfa:trk:flc-enabled": true,
        "tfa:engagement:return-visits:is-enabled": true,
        "tfa:collect-eid-from-page": false,
        "eid-enabled": "false",
        "eid:tfa:common-eid-keywords": "help,support,contact,readme,test,info,reply,careers,spam,login,subscribe,feedback,reachus,customers,cookie,members",
        "tfa:trk:topics-enabled": true,
        "tfa:engagement:use-new-interval-calculation": true,
        "tfa:allow-codeless-tracking": true,
        "tfa:tfa-codeless-tracking:selector-matching-by-native-css": true,
        "tfa:tfa-codeless-tracking:advanced-matching": true,
        "tfa:codeless-domain-override": false,
        "tfa:search-click-id-in-query-string-prefix": "tbl"
    }), e._tfa.config.addTrackedElements([])
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t, n) {
    "use strict";
    var r = e[n.jsScope],
        i = {
            map: function e(t, n) {
                if ("function" == typeof Array.prototype.map) return n.map(t);
                for (var r = [], i = 0; i < n.length; i++) r.push(t(n[i], i, n));
                return r
            },
            forEach: function e(t, n) {
                if ("function" == typeof Array.prototype.forEach) return n.forEach(t);
                for (var r = 0; r < n.length; r++) t(n[r], r, n)
            },
            filter: function e(t, n) {
                if ("function" == typeof Array.prototype.filter) return n.filter(t);
                for (var r = [], i = 0; i < n.length; i++) t(n[i], i, n) && r.push(n[i]);
                return r
            },
            objKeys: Object.keys || (o = Object.prototype.hasOwnProperty, a = !{
                toString: null
            }.propertyIsEnumerable("toString"), s = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"], c = s.length, function(e) {
                if ("function" != typeof e && ("object" !== _typeof(e) || null === e)) throw new TypeError("Object.keys called on non-object");
                var t = [],
                    n, r;
                for (n in e) o.call(e, n) && t.push(n);
                if (a)
                    for (r = 0; r < c; r++) o.call(e, s[r]) && t.push(s[r]);
                return t
            })
        },
        o, a, s, c;
    n.networkMap && "string" != typeof n.networkMap || (n.networkMap = {});
    var l = null,
        u = null,
        f = null,
        d = null,
        p = {},
        h = 0,
        g = !1,
        v = "https://cdn.taboola.com/libtrc/static/topics/taboola-browsing-topics-trk.html",
        m = "requestTimeoutHandle",
        y = "requestId",
        S = "requestStatus",
        b = "trkRequestDone",
        E = 5e3,
        I = 2e3,
        C = "init",
        T = "pr",
        _ = "pud",
        w = "tto",
        k = "s",
        R = "f",
        O = "u",
        P = [w, R],
        A = [C, T, _],
        U = (($ = {})[r.publisherIdType.NAME] = "name", $[r.publisherIdType.ID] = "id", $),
        N = function() {
            for (var e = {}, t = i.objKeys(n.networkMap), o = 0; o < t.length; ++o) {
                var a;
                e["" + n.networkMap[t[o]][U[r.publisherIdType.ID]]] = !0
            }
            return e
        }(),
        D = "gk",
        x = "dk",
        L = "TRK_RELEASE_DELAYED_REQUESTS_EVENT",
        M = function() {
            var e = {};
            return e[D] = x, e
        }(),
        j = new r.MessageDelayer(D, L),
        V = function e(t, n) {
            F = F.loadTrc(n.publisherId, n.publisherIdType, n.config, n.requestData)
        },
        B = {
            UNINITIALIZED: {
                loadTrc: function e(t, n, r, i) {
                    var o = Me();
                    return ae(t, n, r, i), o ? B.USER_ID_SET : B.PENDING_USER_ID_SET
                }
            },
            PENDING_USER_ID_SET: {
                loadTrc: function e(t, n, r, i) {
                    return i[S] = _, j.delayMessage(x, {
                        publisherId: t,
                        publisherIdType: n,
                        config: r,
                        requestData: i
                    }, {
                        successCallback: V
                    }), B.PENDING_USER_ID_SET
                }
            },
            USER_ID_SET: {
                loadTrc: function e(t, n, r, i) {
                    return ae(t, n, r, i), B.USER_ID_SET
                }
            }
        },
        F = B.UNINITIALIZED,
        K = (e.taboola_view_id || (e.taboola_view_id = (new Date).getTime()), e.taboola_view_id),
        G, $, H = function t() {
            var i = function e() {};
            i.prototype.isCookieBannerOfProvider = function() {
                throw new Error("method isCookieBannerOfProvider must be implemented in subclasses.")
            }, i.prototype.parseConsent = function() {}, i.prototype.addListenerForConsentChange = function() {}, i.prototype.isCookieBannerOpen = function() {
                return !1
            }, i.prototype.version = "1";
            var o = function e() {};
            (o.prototype = Object.create(i.prototype)).constructor = o, o.prototype.providerName = "TcfApi", o.prototype.version = "2", o.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.__tcfapi && "function" == typeof e.__tcfapi
            }, o.prototype.addListenerForConsentChange = function() {
                e.__tcfapi("addEventListener", 2, function(e, t) {
                    !t || "tcloaded" !== e.eventStatus && "useractioncomplete" !== e.eventStatus || q({
                        tcString: e.tcString,
                        gdprApplies: e.gdprApplies,
                        cmpStatus: 0
                    })
                })
            };
            var a = function e() {};
            (a.prototype = Object.create(i.prototype)).constructor = a, a.prototype.providerName = "OneTrust", a.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.OnetrustActiveGroups && void 0 !== e.OneTrust
            }, a.prototype.parseConsent = function() {
                q({
                    consentData: e.OnetrustActiveGroups
                })
            }, a.prototype.addListenerForConsentChange = function() {
                if (void 0 !== e.OneTrust.OnConsentChanged) {
                    var t = function e() {
                        r.trk.parseCookieBannerConsent(a.prototype)
                    };
                    e.OneTrust.OnConsentChanged(t)
                }
            };
            var s = function e() {};
            (s.prototype = Object.create(i.prototype)).constructor = s, s.prototype.providerName = "Didomi", s.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.Didomi
            }, s.prototype.parseConsent = function() {
                void 0 !== e.Didomi.getUserStatus && void 0 !== e.Didomi.getUserStatus().consent_string ? q({
                    tcString: e.Didomi.getUserStatus().consent_string
                }) : q(null)
            }, s.prototype.addListenerForConsentChange = function() {
                e.didomiEventListeners = window.didomiEventListeners || [], e.didomiEventListeners.push({
                    event: "consent.changed",
                    listener: function e(t) {
                        r.trk.parseCookieBannerConsent(s.prototype)
                    }
                })
            }, s.prototype.isCookieBannerOpen = function() {
                return void 0 !== e.Didomi.notice && void 0 !== e.Didomi.notice.isVisible && e.Didomi.notice.isVisible()
            };
            var c = function e() {};
            (c.prototype = Object.create(i.prototype)).constructor = c, c.prototype.providerName = "Usercentrics", c.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.UC_UI
            }, c.prototype.parseConsent = function() {
                "function" == typeof e.UC_UI.areAllConsentsAccepted && "boolean" == typeof e.UC_UI.areAllConsentsAccepted() ? q({
                    consentData: e.UC_UI.areAllConsentsAccepted().toString()
                }) : q(null)
            };
            var l = function e() {};
            (l.prototype = Object.create(i.prototype)).constructor = l, l.prototype.providerName = "Cookiebot", l.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.Cookiebot
            }, l.prototype.parseConsent = function() {
                void 0 !== e.Cookiebot.consent && "boolean" == typeof e.Cookiebot.consent.marketing ? q({
                    consentData: e.Cookiebot.consent.marketing.toString()
                }) : q(null)
            }, l.prototype.addListenerForConsentChange = function() {
                if ("function" == typeof window.addEventListener) {
                    var e = function e(t) {
                        r.trk.parseCookieBannerConsent(l.prototype)
                    };
                    window.addEventListener("CookiebotOnConsentReady", e)
                }
            };
            var u = function e() {};
            (u.prototype = Object.create(i.prototype)).constructor = u, u.prototype.providerName = "SourcePoint", u.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e._sp_
            }, u.prototype.addListenerForConsentChange = function() {
                "function" == typeof e._sp_.addEventListener ? window._sp_.addEventListener("onConsentReady", function(e, t, n) {
                    q("string" == typeof n ? {
                        tcString: n,
                        cmpStatus: 0
                    } : "string" == typeof t ? {
                        tcString: t,
                        cmpStatus: 0
                    } : null)
                }) : q(null)
            };
            var f = function e() {};
            (f.prototype = Object.create(i.prototype)).constructor = f, f.prototype.providerName = "ConsentManager", f.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.cmpmngr && "function" == typeof e.__cmp
            }, f.prototype.parseConsent = function() {
                var t = e.__cmp("getCMPData");
                void 0 !== t && void 0 !== t.consentstring && "" !== t.consentstring ? q({
                    tcString: t.consentstring,
                    cmpStatus: 0
                }) : q(null)
            }, f.prototype.addListenerForConsentChange = function() {
                var t = function e() {
                    r.trk.parseCookieBannerConsent(f.prototype)
                };
                e.__cmp("addEventListener", ["consent", t, !1, null])
            };
            var d = function e() {};
            (d.prototype = Object.create(i.prototype)).constructor = d, d.prototype.providerName = "Shopify", d.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.Shopify && void 0 !== e.Shopify.customerPrivacy
            }, d.prototype.parseConsent = function() {
                "function" == typeof e.Shopify.customerPrivacy.marketingAllowed ? q({
                    consentData: e.Shopify.customerPrivacy.marketingAllowed().toString()
                }) : q(null)
            }, d.prototype.addListenerForConsentChange = function() {
                if ("function" == typeof window.addEventListener) {
                    var e = function e(t) {
                        r.trk.parseCookieBannerConsent(d.prototype)
                    };
                    window.addEventListener("visitorConsentCollected", e)
                }
            };
            var p = function e() {};
            (p.prototype = Object.create(i.prototype)).constructor = p, p.prototype.providerName = "CookieYes", p.prototype.isCookieBannerOfProvider = function() {
                return "function" == typeof e.getCkyConsent
            }, p.prototype.parseConsent = function() {
                var t = null;
                try {
                    if (e.getCkyConsent && "function" == typeof e.getCkyConsent) {
                        var n = e.getCkyConsent();
                        if (n && n.categories && "object" === _typeof(n.categories)) {
                            var r = n.categories,
                                i;
                            t = {
                                consentData: (Object.keys(r).length > 0 && Object.keys(r).every(function(e) {
                                    return !0 === r[e]
                                })).toString()
                            }
                        }
                    }
                } catch (e) {}
                q(t)
            };
            var h = function e() {};
            (h.prototype = Object.create(i.prototype)).constructor = h, h.prototype.providerName = "CookieFirst", h.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.CookieFirst && void 0 !== e.CookieFirst.consent
            }, h.prototype.parseConsent = function() {
                var t = null;
                try {
                    if (e.CookieFirst && e.CookieFirst.consent && "object" === _typeof(e.CookieFirst.consent)) {
                        var n = e.CookieFirst.consent,
                            r;
                        t = {
                            consentData: (Object.keys(n).length > 0 && Object.keys(n).every(function(e) {
                                return !0 === n[e]
                            })).toString()
                        }
                    }
                } catch (e) {}
                q(t)
            };
            var g = function e() {};
            (g.prototype = Object.create(i.prototype)).constructor = g, g.prototype.providerName = "Klaro", g.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.klaroConfig || void 0 !== e.klaro
            }, g.prototype.parseConsent = function() {
                var t = null;
                try {
                    if (e.klaro && "function" == typeof e.klaro.getManager) {
                        var n = e.klaro.getManager();
                        if (n && n.consents && "object" === _typeof(n.consents)) {
                            var r = n.consents,
                                i;
                            t = {
                                consentData: (Object.keys(r).length > 0 && Object.keys(r).every(function(e) {
                                    return !0 === r[e]
                                })).toString()
                            }
                        }
                    }
                } catch (e) {}
                q(t)
            };
            var v = function e() {};
            (v.prototype = Object.create(i.prototype)).constructor = v, v.prototype.providerName = "CookieScript", v.prototype.isCookieBannerOfProvider = function() {
                return void 0 !== e.CookieScript
            }, v.prototype.parseConsent = function() {
                var t = null;
                try {
                    if (e.CookieScript && e.CookieScript.instance && "function" == typeof e.CookieScript.instance.currentState) {
                        var n = e.CookieScript.instance.currentState();
                        t = n && "accept" === n.action ? {
                            consentData: "true"
                        } : {
                            consentData: "false"
                        }
                    }
                } catch (e) {}
                q(t)
            };
            var m = ["ad_storage"],
                y = function e() {};
            (y.prototype = Object.create(i.prototype)).constructor = y, y.prototype.providerName = "Gtm", y.prototype.isCookieBannerOfProvider = function() {
                return !!(e.dataLayer && "function" == typeof e.dataLayer.push || e.google_tag_data)
            }, y.prototype.parseConsent = function() {
                function t(e, t) {
                    return e ? "granted" : t ? "denied" : null
                }

                function r(e) {
                    q("granted" === e ? {
                        consentData: "true"
                    } : "denied" === e ? {
                        consentData: "false"
                    } : null)
                }

                function i(e, n) {
                    for (var r = !0, i = !1, o = 0; o < n.length; o++) {
                        var a, s = e[n[o]],
                            c = s && s.update;
                        if (!1 === c) {
                            i = !0, r = !1;
                            break
                        }!0 !== c && (r = !1)
                    }
                    return t(r, i)
                }

                function o(e, n) {
                    for (var r = !0, i = !1, o = 0; o < n.length; o++) {
                        var a, s = e[n[o]];
                        if ("denied" === s) {
                            i = !0, r = !1;
                            break
                        }
                        "granted" !== s && (r = !1)
                    }
                    return t(r, i)
                }

                function a(e) {
                    for (var t = e.length - 1; t >= 0; t--) {
                        var n = e[t];
                        if (n && "consent" === n[0] && "update" === n[1] && n[2] && "object" === _typeof(n[2])) return n[2]
                    }
                    return null
                }
                try {
                    var s = e._tfa.config.safeGet("tfa:trk:gtm-consent-fields", m, n.bakedPublisherId),
                        c;
                    if (e.google_tag_data && e.google_tag_data.ics && e.google_tag_data.ics.entries && null !== (c = i(e.google_tag_data.ics.entries, s))) return void r(c);
                    if (e.dataLayer && e.dataLayer.length) {
                        var l = a(e.dataLayer);
                        if (l) return void r(c = o(l, s))
                    }
                } catch (e) {}
                q(null)
            }, y.prototype.addListenerForConsentChange = function() {
                var t = e._tfa.config.safeGet("tfa:trk:gtm-consent-fields", m, n.bakedPublisherId);
                e.google_tag_data && e.google_tag_data.ics && "function" == typeof e.google_tag_data.ics.addListener && e.google_tag_data.ics.addListener(t, function() {
                    r.trk.parseCookieBannerConsent(y.prototype)
                })
            };
            var S = function e() {};
            return S.COOKIE_NAME = "aep_usuc_f", S.CONSENT_FIELD = "ae_u_p_s", S.CONSENT_VALUE = "2", S.NON_CONSENT_VALUE = "1", (S.prototype = Object.create(i.prototype)).constructor = S, S.prototype.providerName = "AliExpress", S.prototype.isCookieBannerOfProvider = function() {
                return null !== Se(S.COOKIE_NAME)
            }, S.prototype.parseConsent = function() {
                var e = Se(S.COOKIE_NAME);
                if (e) {
                    for (var t = e.split("&"), n = 0; n < t.length; n++) {
                        var r = t[n].split("=");
                        if (r[0] === S.CONSENT_FIELD) {
                            var i = r[1];
                            return void q(i === S.CONSENT_VALUE ? {
                                consentData: "true"
                            } : i === S.NON_CONSENT_VALUE ? {
                                consentData: "false"
                            } : null)
                        }
                    }
                    q(null)
                } else q(null)
            }, {
                "TcfApi,V2": new o,
                "OneTrust,V1": new a,
                "Didomi,V1": new s,
                "Usercentrics,V1": new c,
                "Cookiebot,V1": new l,
                "SourcePoint,V1": new u,
                "ConsentManager,V1": new f,
                "Shopify,V1": new d,
                "AliExpress,V1": new S,
                "CookieYes,V1": new p,
                "CookieFirst,V1": new h,
                "CookieScript,V1": new v,
                "Klaro,V1": new g,
                "GTMConsentMode,V1": new y
            }
        },
        q = function e(t) {
            r.trk.cookieBannerConsent = t
        },
        Q = function e() {
            return r.trk.cookieBannerProvider && r.trk.cookieBannerConsent ? {
                cookieBannerConsent: r.trk.cookieBannerConsent,
                cookieBannerProvider: r.trk.cookieBannerProvider
            } : null
        },
        z = function e() {
            return !0 === n.tfaContext
        },
        J = function e() {
            try {
                localStorage.setItem("taboolaStorageDetection", "detect"), localStorage.removeItem("taboolaStorageDetection")
            } catch (e) {
                return !1
            }
            return !0
        },
        W = function e(t, n, r) {
            var i = t.split(n);
            return i.slice(0, r - 1).concat(i.length >= r ? i.slice(r - 1).join(n) : [])
        },
        Y = function e(t) {
            if (!t) throw new Error("Invalid URL!");
            this.href = t;
            var n = W(t, "#", 2);
            return this.hash = n.length > 1 ? "#" + n.pop() : "", t = n[0], n = W(t, "?", 2), this.search = n.length > 1 ? "?" + n.pop() : "", t = n[0], n = W(t, "://", 2), this.protocol = n.length > 1 ? n.shift() + ":" : "", t = n[0], n = W(t, "/", 2), this.pathname = n.length > 1 ? "/" + n.pop() : "/", t = n[0], n = W(t, "@", 2), this.auth = n.length > 1 ? n.shift() : "", t = n[0], n = W(t, ":", 2), this.port = n.length > 1 ? parseInt(n.pop()) : 0, this.host = n[0], this
        },
        X = {
            "http:": 1,
            "https:": 1
        };
    Y.prototype.toString = function(e) {
        return (this.host ? this.protocol + "//" + (this.auth ? this.auth + "@" : "") + this.host + (this.port ? ":" + this.port : "") : "") + this.pathname + this.search + (e ? "" : this.hash || "")
    }, Y.prototype.switchProtocol = function(e, t) {
        var n = this instanceof Y ? this : new Y(this),
            r;
        return X[e] && (t && "https:" === n.protocol || (n.protocol = e)), (r = n.toString(!1)).length > 1 ? r : ""
    }, Y.prototype.getParameter = function(e) {
        for (var t, n = (this instanceof Y ? this : new Y(this)).search.substr(1).split(/&/), r = 0; r < n.length; r++) {
            var i = n[r].split(new RegExp("="), 2);
            if (unescape(i[0]) === e) return unescape(i[1])
        }
        return null
    };
    var Z = {
            states: {
                ABP_DETECTION_DISABLED: -2,
                ABP_NOT_DETECTED: 0,
                ABP_DETECTED: 1
            },
            createBlockDetectionDiv: function e(n) {
                var r = t.createElement("div");
                return r.className = n, r.style.fontSize = "initial", r.appendChild(t.createTextNode(".")), t.documentElement.appendChild(r), r
            },
            isBlockDetectedOnDiv: function e(t) {
                return !t.offsetHeight
            },
            isBlockDetectedOnClassNames: function e(n) {
                var r, i = n.length,
                    o;
                for (r = 0; r < i; r++)
                    if (n[r]) {
                        o = this.createBlockDetectionDiv(n[r]);
                        try {
                            if (this.isBlockDetectedOnDiv(o)) return !0
                        } catch (e) {} finally {
                            t.documentElement.removeChild(o)
                        }
                    }
                return !1
            },
            getBlockedState: function e(t) {
                return ke() || Re() ? this.states.ABP_NOT_DETECTED : t && this.isBlockDetectedOnClassNames(t) ? this.states.ABP_DETECTED : this.states.ABP_NOT_DETECTED
            }
        },
        ee = function e(t, n) {
            for (var r = i.objKeys(t), o = 0; o < r.length; o++) {
                var a = r[o];
                n.push([a, t[a]])
            }
        },
        te = function e(t) {
            r[t.callbackName] = function() {}, t.newScriptElement.parentNode && t.newScriptElement.parentNode.removeChild(t.newScriptElement), t.newScriptElement = null, delete t.newScriptElement
        },
        ne = function t(n) {
            te(n), n[S] = w, n.isMediaRequest || (e.TRC.trkRequestStatus = !1), F === B.PENDING_USER_ID_SET && (F = B.UNINITIALIZED), n[b] ? r.eventUtils.dispatchEvent(r.sharedEvents.INVALID_TRK_RESPONSE, {
                publisherId: n.publisherId
            }) : r.eventUtils.dispatchEvent(r.sharedEvents.REQUEST_ID_CREATION_TIMEOUT, {
                publisherId: n.publisherId
            }), ue()
        },
        re = function e(n, r, i, o) {
            var a = t.getElementsByTagName("script")[0],
                s = t.createElement("script");
            return s.type = "text/javascript", s.src = n, s.charset = "UTF-8", i ? s.setAttribute("defer", "defer") : o && s.setAttribute("async", "async"), "function" == typeof r && (s.addEventListener ? (s.addEventListener("load", r, !1), s.addEventListener("error", r, !1)) : s.onreadystatechange = function() {
                "loaded" !== s.readyState && "complete" !== s.readyState || r.apply(s)
            }), a.parentNode.insertBefore(s, a), s
        },
        ie = function e(t, n, r, i) {
            var o = {
                publisherId: t,
                isMediaRequest: r.isMediaRequest,
                isUnifiedPageView: r.isUnifiedPageView,
                publisherIdType: n,
                callbackName: "trkCallback" + (0 === h ? "" : h),
                metadata: i
            };
            return o[S] = C, p[t] || (p[t] = []), p[t].push(o), ++h, o
        },
        oe = function e(t) {
            return function() {
                ne(t)
            }
        },
        ae = function t(r, i, o, a) {
            var s = n.rboxTrcProtocol + "//trc.taboola.com/" + r + "/trc/3/json?" + "tim=" + (new Date).getTime() + "&" + "data=" + encodeURIComponent(JSON.stringify(ce(a))) + "&" + "pubit=" + i,
                c = o.isMediaRequest ? e._tfa.config.safeGet("tfa:trk:tracking-request-timeout", I, r) : E;
            a[S] = T, a[m] = e.setTimeout(oe(a), c), a.newScriptElement = re(s, function() {
                a[b] = !0
            })
        },
        se = function e(t) {
            return function(e) {
                fe(t, e)
            }
        },
        ce = function e(t) {
            return r[t.callbackName] = se(t), Ie(t)
        },
        le = function e(t) {
            var n = p[t = "" + t];
            return n && n.length > 0 ? n[n.length - 1] : null
        },
        ue = function e() {
            r.eventUtils.dispatchEvent(L, M)
        },
        fe = function t(i, o) {
            if (e.clearTimeout(i[m]), o && o.trc) {
                if (o.trc.ui ? (o.trc["DNT"] && "TRUE" === o.trc["DNT"].toUpperCase() ? localStorage.removeItem("taboola global:user-id") : o.trc["cm"] || localStorage.setItem("taboola global:user-id", o.trc["ui"]), F = B.USER_ID_SET) : F = B.UNINITIALIZED, o.trc.sd && !o.trc["cm"] && localStorage.setItem(i.publisherId + ":session-data", o.trc["sd"]), o.trc["vl"] && o.trc["vl"].length) {
                    var a = o.trc["vl"][0].ri;
                    i.isMediaRequest || (e.TRC.events_ri = a), i[y] = a, i[S] = k, r.eventUtils.dispatchEvent(r.sharedEvents.REQUEST_ID_CREATED, {
                        publisherId: i.publisherId,
                        requestId: a
                    })
                }
                i.isMediaRequest && r.trk.rboxNotLoaded() && (o.trc.stp && r.trk.loadPixels(o.trc.stp), o.trc.jst && r.trk.loadScriptTags(o.trc.jst)), r.privacySandbox && r.privacySandbox.isProtectedAudienceSupported() && i.isMediaRequest && o.trc.ig && r.privacySandbox.joinInterestGroupsInIframe(o.trc.ig)
            }
            i[S] !== k && (i[S] = R, r.eventUtils.dispatchEvent(r.sharedEvents.REQUEST_ID_CREATION_ERROR, {
                publisherId: i.publisherId
            })), i.isMediaRequest || (e.TRC.trkRequestStatus = !(P.indexOf(i[S]) >= 0)), e.TRC.alertVVResponseLoaded && e.TRC.alertVVResponseLoaded(n.tblVersion), te(i), ue()
        },
        de = function() {
            var e, t = function e() {
                    try {
                        return decodeURI(top.window.document.referrer)
                    } catch (e) {}
                    return null
                },
                n = /https?:\/\/\w+\.taboola(?:syndication)?\.com/,
                r = function e(t) {
                    return n.test(t) ? t.split("?")[0] : t.substr(0, 400)
                },
                i, o = [function e() {
                    for (var t = document.head.getElementsByTagName("link"), n = 0; n < t.length; n++)
                        if ("referrer" === t[n].rel) return t[n].href;
                    return null
                }, function e() {
                    var n = t();
                    return n ? r(n) : null
                }],
                a = function e() {
                    for (var e, t = 0; !e && t < o.length; t++) e = o[t].call(this);
                    return e
                };
            return a.innerExtractReferrerFromTopMostReferrer = r, a
        }(),
        pe = function e() {
            var t = d;
            return t || (t = de()), t
        },
        he = function e(t) {
            var n;
            if (t) {
                try {
                    n = Y.prototype.getParameter.call(window.location.href, "cnsntstr")
                } catch (e) {}
                n && (t.tcs = n, t.ga = !0, t.cmps = 5), t.ad = {
                    sdkd: {
                        os: "AMP",
                        osv: 1,
                        sdkt: "Taboola AMP Driver",
                        sdkv: "1"
                    }
                }
            }
        },
        ge = function t() {
            if (G) return G;
            var n = 400,
                r;
            return (G = e.location.search).length > n && (r = G.substring(0, n - 1), G = r.substring(0, r.lastIndexOf("&"))), G
        },
        ve = function e(t) {
            var n = Se("usprivacy");
            if ("function" == typeof __uspapi) try {
                __uspapi("getUSPData", 1, function(e, r) {
                    r && e ? t(e.uspString) : n && t(n)
                })
            } catch (e) {
                throw n && t(n), new Error("Error while calling __uspapi for getUSPData")
            } else n && t(n)
        };

    function me(e, t, n) {
        if (t) {
            try {
                window.__gpp("removeEventListener", function() {}, e.listenerId)
            } catch (e) {}
            n(e)
        }
    }
    var ye = function e(t) {
            if ("function" == typeof t) try {
                var n = function e(n, r) {
                    me(n, r, t)
                };
                window.__gpp("addEventListener", n)
            } catch (e) {}
        },
        Se = function e(t) {
            var n = t + "=",
                r = "; " + document.cookie;
            if (r)
                for (var i = r.split(";"), o = 0; o < i.length; o++)
                    for (var a = i[o];
                        " " === a.charAt(0);)
                        if (0 === (a = a.substring(1, a.length)).indexOf(n)) return a.substring(n.length, a.length);
            return null
        },
        be = function t(o, a) {
            var s = {},
                c = o.metadata,
                l = o.publisherId,
                u = e._tfa.config.safeGet("tfa:trk:should-send-media-data", !0, l),
                f = e._tfa.config.safeGet("tfa:trk:media-data-param-name", "mpvd", l),
                d = e._tfa.config.safeGet("tfa:trk:unified-page-view-param-name", "supv", l),
                p = {},
                h;
            return e._tfa.config.safeGet("tfa:trk:collect-cookie-banner-consent:enabled", !0, n.bakedPublisherId) && (p = r.trk.parseCookieBanner()) && (a.cbp = p.cookieBannerProvider.providerName, a.cbpv = p.cookieBannerProvider.version, p.cookieBannerConsent.tcString && e._tfa.config.safeGet("tfa:trk:send-tc-string:enabled", !0, n.bakedPublisherId) ? (a.tcs = p.cookieBannerConsent.tcString, p.cookieBannerConsent.gdprApplies && (a.ga = p.cookieBannerConsent.gdprApplies), p.cookieBannerConsent.cmpStatus && (a.cmps = p.cookieBannerConsent.cmpStatus)) : p.cookieBannerConsent.consentData && (a.cbcd = p.cookieBannerConsent.consentData)), i.forEach(function(e) {
                var t = c[e];
                a.hasOwnProperty(e) && t === a[e] || (s[e] = t)
            }, i.objKeys(c)), o.isUnifiedPageView && (s[d] = !0), u && (a[f] = s), e._tfa.config.safeGet("tfa:trk:collect-ccpa", !0, n.bakedPublisherId) && ve(function(e) {
                a.ccpa = e
            }), e._tfa.config.safeGet("tfa:trk:collect-gpp", !1, n.bakedPublisherId) && ye(function(e) {
                e && (a.cmpStatus = 0, a.applicableSections = e.pingData.applicableSections, a.gppString = e.pingData.gppString)
            }), r.privacySandbox && r.privacySandbox.isProtectedAudienceSupported() && (a.pa = {
                su: !0
            }, a.psb = !0), a
        },
        Ee = function t(r) {
            var i = n.jsScope + "." + r.callbackName,
                o = Z.getBlockedState(["banner_ad", "sponsored_ad"]);
            return {
                id: ~~(1e3 * Math.random()),
                ii: _e(r),
                it: xe(e._taboola),
                sd: Le(r.publisherId),
                ui: Me(),
                vi: K,
                cv: n.tblVersion,
                uiv: "default",
                u: je(),
                e: pe(),
                cb: i,
                qs: ge(),
                r: [{
                    li: "rbox-tracking",
                    s: 0,
                    uim: "rbox-tracking:pub=" + n.bakedPublisherName + ":abp=" + o,
                    uip: "rbox-tracking",
                    orig_uip: "rbox-tracking"
                }]
            }
        },
        Ie = function e(t) {
            var n = Ee(t);
            return ke() && he(n), t.isMediaRequest && (n = be(t, n)), n
        },
        Ce = function e(t) {
            for (var n = 0; n < t.length; ++n)
                for (var r = t[n], o = i.objKeys(r), a = 0; a < o.length; ++a) {
                    var s = o[a],
                        c = r[s];
                    if ("unknown" !== c) switch ("auto" === c && (c = ""), s) {
                        case "video":
                            l = c;
                            break;
                        case "url":
                            f = c;
                            break;
                        case "article":
                        case "category":
                        case "home":
                        case "search":
                        case "photo":
                        case "other":
                        case "content_hub":
                            u = c;
                            break;
                        case "ref_url":
                            d = c
                    }
                }
        },
        Te = function t(n) {
            if (n) {
                var i = r.trk.getPublisherRequestId(n);
                if (i) return i
            }
            return e.TRC.events_ri
        },
        _e = function e(t) {
            var r = null;
            return l || "" === l ? r = l : (u || "" === u) && (r = u), ("" === r || t.isMediaRequest) && (r = Pe("item-id", n.normalizeItemId, n.prenormalizeIdRules)), r
        },
        we = function e(t, n, r) {
            var o;
            if (!r) return n;
            i.forEach(function(e) {
                var t = n.search(e);
                t >= 0 && (n = n.substr(0, t))
            }, r["truncate-at"] || []);
            for (var a = new Y(n), s = i.objKeys(r), c = 0; c < s.length; ++c) {
                var l = s[c];
                if (r[l]) switch (l) {
                    case "host":
                        delete a.host;
                        break;
                    case "trailing-dirsep":
                        for (;
                            "/" === a.pathname.substr(a.pathname.length - 1);) a.pathname = a.pathname.substr(0, a.pathname.length - 1);
                        break;
                    case "query":
                        var u = [],
                            f = a.search.replace(/^\?/, "").split("&");
                        "string" == typeof(o = r[l]) && (o = new RegExp(o));
                        var d = o instanceof Array ? function(e) {
                            for (var t = 0; t < o.length; t++)
                                if (e === o[t]) return !0;
                            return !1
                        } : o instanceof RegExp ? o.test.trcBind(o) : function() {
                            return !1
                        };
                        f.forEach(function(e) {
                            d(decodeURIComponent(e.split("=")[0])) && u.push(e)
                        }), a.search = (u.length ? "?" : "") + u.join("&");
                        break;
                    case "fragment":
                        var p = a.hash.replace(/^#/, "");
                        "string" == typeof(o = r[l]) && (o = new RegExp(o)), a.hash = "", o instanceof RegExp && o.test(p) ? a.hash = "#" + p : o instanceof Array && o.forEach(function(e) {
                            p.search(e) >= 0 && (a.hash = "#" + p)
                        })
                }
            }
            return a.pathname || (a.pathname = "/"), "item-id" === t ? a.toString().toLowerCase() : a.toString()
        },
        ke = function e() {
            return Oe(pe(), "ampproject.net")
        },
        Re = function e() {
            return Oe(pe(), "instantarticles.fb.com")
        },
        Oe = function e(t, n) {
            try {
                return void 0 !== t && void 0 !== n && t.indexOf(n) > 0
            } catch (e) {
                return !1
            }
        },
        Pe = function e(t, r, i) {
            var o = ["paramUrl", "meta", "canonical", "og", "location"],
                a = {
                    paramUrl: Ae,
                    canonical: Ue,
                    og: Ne,
                    location: De
                },
                s = n.urlExtractOrder && Array.isArray(n.urlExtractOrder) ? n.urlExtractOrder : o,
                c = 0,
                u, f, d, p = "",
                h = function e(t, n) {
                    return we.call(this, t, n, i)
                };
            for (s.push("location"); c < s.length && (!p || /^\s*$/.test(p));) f = s[c], p = (u = a[s[c]]) ? u.call(null, t, h) : null, c++;
            return "item-url" === t && f === Ae ? p : (d = f !== De, p = "function" == typeof r ? r.call(this, p, l ? "video" : "text", d) : p)
        },
        Ae = function e(t, n) {
            return !f || "item-id" !== t && "item-url" !== t ? null : n.call(this, t, r.trk.encodeItemUrlIfNeeded(f))
        },
        Ue = function e(n, i) {
            for (var o = t.head.getElementsByTagName("link"), a = 0; a < o.length; a++)
                if ("canonical" === o[a].rel && o[a].href) return i.call(this, n, r.trk.encodeItemUrlIfNeeded(o[a].href));
            return null
        },
        Ne = function e(n, i) {
            for (var o = t.head.getElementsByTagName("meta"), a = 0; a < o.length; a++)
                if ("og:url" === o[a].getAttribute("property") && o[a].content.length > 5) return i.call(this, n, r.trk.encodeItemUrlIfNeeded(o[a].content));
            return null
        },
        De = function t(n, r) {
            var o = function t() {
                var n = e.location,
                    r = i.filter(function(e) {
                        return 0 !== e.search("trc_") && "taboola-debug" !== e
                    }, n.search.replace(/^\?/, "").split("&")).join("&");
                return n.origin + n.pathname + "?" + r
            };
            return r.call(this, n, o())
        },
        xe = function e(t) {
            try {
                var n = i.objKeys(t[0]);
                for (var r in n) switch (n[r]) {
                    case "home":
                        return "home";
                    case "category":
                        return "category";
                    case "text":
                    case "article":
                        return "text";
                    case "search":
                        return "search";
                    case "photo":
                        return "photo";
                    case "other":
                        return "other";
                    case "content_hub":
                        return "content_hub";
                    case "video":
                    default:
                        return "video"
                }
            } catch (e) {
                return "video"
            }
        },
        Le = function e(t) {
            return localStorage.getItem(t + ":session-data")
        },
        Me = function e() {
            return localStorage.getItem("taboola global:user-id")
        },
        je = function e() {
            return Pe("item-url", n.normalizeItemUrl, n.prenormalizeUrlRules)
        },
        Ve = function e(t) {
            for (var n, r = /^(.*\/libtrc\/.+\/)(?:(?:trk)|(?:tfa))\.js(?:\?(.*))?$/, i = 0; i < t.length; i++)
                if (n = t[i].src.match(r)) return n[1]
        },
        Be = function e() {
            for (var n = Ve(t.getElementsByTagName("script")), r = [{
                    key: "?",
                    index: 0
                }, {
                    key: "://",
                    index: 1
                }, {
                    key: "//",
                    index: 1
                }, {
                    key: "/",
                    index: 0
                }], i = 0, o = r.length, a = n, s; i < o; i++) a = (s = W(a, r[i].key, 2)).length > 1 ? s[r[i].index] : s[0];
            return a
        },
        Fe = function t() {
            if (!e.TRC.AdServerManager) {
                var r = Be();
                e.TRC.VVReady = Ke, re("//" + r + "/libtrc/vv." + n.tblVersion + ".js")
            }
        },
        Ke = function t() {
            e.TRC.adManager = new e.TRC.AdServerManager(n.vvConfig, n.tblVersion), e.TRC.adManager.startVV().then(function() {
                e.TRC.adManager.run()
            })
        },
        Ge = function e(t, n) {
            return t ? t[n] : t
        },
        $e = function e(t, n, r) {
            if (0 === i.objKeys(r).length || N["" + t]) return t;
            var o = document.createElement("a");
            o.href = f;
            var a = (o.host || location.host).toLowerCase(),
                s = (o.href || location.href).toLowerCase(),
                c = U[n],
                l = Ge(r[a], c),
                u = "/",
                d = ["m", "mobile", "www2", "www3"],
                p = [],
                h, g, v, m, y;
            if (!l) {
                for (ee(r, p), p.sort(function(e, t) {
                        return e[0].length > t[0].length ? -1 : e[0].length < t[0].length ? 1 : 0
                    }), h = 0, g = p.length; h < g; h++)
                    if ((v = p[h][0].toLowerCase()).indexOf(u) > 0) {
                        if (s.match(v)) {
                            l = Ge(p[h][1], c);
                            break
                        }
                        if (v.indexOf("www.") > -1 && s.match(v.replace("www.", ""))) {
                            l = Ge(p[h][1], c);
                            break
                        }
                    } else if (a.match(v)) {
                    l = Ge(p[h][1], c);
                    break
                }
                if (!l && a.indexOf("www.") < 0) {
                    for (h = 0, g = d.length; h < g && (m = new RegExp("(https://|http://|^)" + d[h] + "."), y = a.replace(m, "www."), !(l = Ge(r[y], c))); h++);
                    l || (l = Ge(r[y = "www." + a], c))
                }
            }
            return l || "unknown-site-on-" + t
        },
        He = function e(t, n, r) {
            var i = le(t);
            return i ? n.call(this, i[S]) : r
        },
        qe = function e(t, n, i) {
            var o, a, s = [];
            try {
                if (!Array.isArray(t)) return;
                for (a = 0; a < t.length; a++)(o = t[a]) && !n[o] && (n[o] = !0, o = Y.prototype.switchProtocol.call(o, r.trk.rboxTrcProtocol()), s.push(i(o)));
                return s
            } catch (e) {}
        };
    e.TRC = e.TRC || {}, e.TRC.trk = r.trk = e.TRC.trk || {
        init: function t() {
            r.trk.parseCookieBanner(), e.TRC.utm && !z() || (z() || g || (e.TRC._getGlobalRequestId = Te, e.TRC._getItemId = _e, e.TRC._getItemType = xe, g = !0), e.TRC.hasTrk ? z() || r.trk.execute() : e._tfa && !e._tfa.config.hasValidConfig() || (r.hasTrk = !0, J() && (r.eventUtils.safeAddEventListener(r.sharedEvents.PAGE_VIEW, function(t) {
                try {
                    var i = t.detail,
                        o = i.publisherIdType,
                        a = i.accountId,
                        s = i.pageViewInitiator,
                        c = i.isUnifiedPageView,
                        l = s === r.pageViewInitiator.TFA,
                        u = i.metadata,
                        f, d;
                    if (Ce(e._taboola), l) {
                        if (e._tfa.config.safeGet("tfa:trk:prevent-concurrent-requests", !0, a) && r.trk.isRequestProcessing(a)) return;
                        e._tfa.config.safeGet("tfa:trk:network-solution-enabled", !1, a) && (a = $e(a, o, n.networkMap))
                    }
                    d = ie(a, o, f = {
                        pageViewInitiator: s,
                        isMediaRequest: l,
                        isUnifiedPageView: c
                    }, u), F = F.loadTrc(a, o, f, d)
                } catch (t) {
                    r.eventUtils.dispatchEvent(r.sharedEvents.REQUEST_ID_CREATION_JS_ERROR, {
                        publisherId: a
                    })
                }
            }), z() || r.trk.execute(), n.enableVV && Fe())))
        },
        execute: function t() {
            var i = r.publisherIdType.NAME,
                o = $e(n.bakedPublisherName, i, n.networkMap);
            r.eventUtils.dispatchEvent(r.sharedEvents.PAGE_VIEW, {
                accountId: o,
                publisherIdType: i,
                pageViewInitiator: r.pageViewInitiator.TRK
            }), e.TRC.publisherId = e.TRC.publisherId || o
        },
        getRequestStatus: function e(t) {
            var n = le(t);
            return n ? n[S] : O
        },
        isRequestProcessing: function e(t) {
            return He(t, function(e) {
                return A.indexOf(e) > -1
            }, !1)
        },
        hasRequestEnded: function e(t) {
            return He(t, function(e) {
                return P.indexOf(e) > -1 || !(A.indexOf(e) > -1)
            }, !1)
        },
        getPublisherRequestId: function e(t) {
            var n = le(t);
            return n && n[S] === k ? n[y] : null
        },
        getPublisherSessionData: function e(t) {
            var n = Le(t);
            return n || null
        },
        getViewId: function e() {
            return K
        },
        getReferrer: de,
        getCcpaParam: function e(t) {
            return ve(t)
        },
        getGppParam: function e(t) {
            return ye(t)
        },
        COOKIE_BANNER_MAP: H(),
        parseCookieBanner: function e() {
            var t, n;
            try {
                return (n = Q()) ? n : null === (t = r.trk.parseCookieBannerProvider()) ? null : (r.trk.parseCookieBannerConsent(t), Q())
            } catch (e) {
                return null
            }
        },
        parseCookieBannerProvider: function e() {
            var t, n;
            if (r.trk.cookieBannerProvider) return r.trk.COOKIE_BANNER_MAP[r.trk.cookieBannerProvider.providerName + ",V" + r.trk.cookieBannerProvider.version];
            for (n in r.trk.COOKIE_BANNER_MAP)
                if (r.trk.COOKIE_BANNER_MAP.hasOwnProperty(n) && (t = r.trk.COOKIE_BANNER_MAP[n]).isCookieBannerOfProvider()) return r.trk.cookieBannerProvider = {
                    providerName: t.providerName,
                    version: t.version
                }, t.addListenerForConsentChange(), t;
            return null
        },
        parseCookieBannerConsent: function e(t) {
            try {
                t.isCookieBannerOpen() || t.parseConsent()
            } catch (e) {}
        },
        loadPixels: function t(n) {
            try {
                return qe(n, e.TRC.sharedObjects.loadedPixels, function(e) {
                    var t = new Image;
                    return t.src = e, t
                })
            } catch (e) {}
        },
        loadScriptTags: function t(n) {
            try {
                return qe(n, e.TRC.sharedObjects.loadedScripts, function(e) {
                    return re(e, null, null, !0)
                })
            } catch (e) {}
        },
        rboxNotLoaded: function t() {
            return !(e.TRC && e.TRC.utm)
        },
        rboxTrcProtocol: function e() {
            return n.rboxTrcProtocol
        },
        hasSuperUTFSeq: function e(t) {
            for (var n = t.split("").map(function(e) {
                    return e.charCodeAt(0)
                }), i = 0, o = 0; o < n.length; o++) {
                if (r.trk.isSuperUTF(n[o]) || (i = 0), i >= 3) return !0;
                i++
            }
            return !1
        },
        isSuperUTF: function e(t) {
            var n;
            return t > 1200
        },
        encodeItemUrlIfNeeded: function e(t) {
            try {
                if (r.trk.hasSuperUTFSeq(t)) return encodeURI(t)
            } catch (e) {}
            return t
        },
        getItemUrl: je
    }, z() && !e._tfa.config.safeGet("tfa:trk:enabled", !0, n.bakedPublisherId) || r.trk.init()
}(window, document, {
    bakedPublisherId: 1603492,
    bakedPublisherName: 'interactivebrokers-sc',
    tblVersion: "20261004-14-RELEASE",
    normalizeItemId: function(itemid, type, canon) {
        if (!canon && type == 'text' && typeof itemid == 'string' && itemid.search(new RegExp('^https?://')) == 0) itemid = itemid.replace(/\?.*/, '', false);
        return itemid.toLowerCase();
    },
    prenormalizeIdRules: {
        "host": true,
        "fragment": "^(/video/|!)",
        "query": ["p", "id"],
        "truncate-at": ["search.searchcompletion.com", "org.mozilla.javascript.undefined"],
        "trailing-dirsep": true
    },
    prenormalizeUrlRules: false,
    normalizeItemUrl: function(itemurl, type, canon) {
        return itemurl;
    },
    urlExtractOrder: null,
    networkMap: {},
    vvConfig: null,
    enableVV: false,
    rboxTrcProtocol: 'https:',
    tfaContext: true,
    jsScope: 'TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC'
}),
function(e, t) {
    e._tfa = e._tfa || [], t.useStorageDetection = e.TRC.useStorageDetection = e.TRC.useStorageDetection || !0, t.text = t.text || {}, t.text.lsplit = t.text.lsplit || function(e, t, n) {
        var r = e.split(t);
        return r.slice(0, n - 1).concat(r.length >= n ? r.slice(n - 1).join(t) : [])
    }, t.tfaUtil = t.tfaUtil || {}, t.tfaUtil.safeAddParam = t.tfaUtil.safeAddParam || function(e, t, n) {
        var r, i;
        n && t && e && (r = encodeURIComponent(e), i = encodeURIComponent(t), n.push(r + "=" + i))
    }, t.tfaUtil.getParameterByName = t.tfaUtil.getParameterByName || function(e, t) {
        if (!t || !e) return null;
        e = e.replace(/[\[\]]/g, "\\$&");
        var n, r = new RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)").exec(t);
        return r ? r[2] ? decodeURIComponent(r[2].replace(/\+/g, " ")) : "" : null
    }, t.cnxUtil = t.cnxUtil || {}, t.cnxUtil.CNX_CLICK_ID_KEY = "cnxclid", t.cnxUtil.TBLA_CNX_ROI_COOKIE_NAME = "tbla_cnx_roi", t.cnxUtil.CNX_TRACKER_ID_SEPARATOR = "~", t.cnxUtil.CNX_TRACKER_IDS_TO_KEEP = 3, t.cnxUtil.getCnxClickId = function() {
        var n = t.tfaPageManager,
            r = e._tfa || {},
            i = !r.config || !r.config.safeGet || r.config.safeGet("tfa:ecomm:setTblacnxclidCookie", !0),
            o = t.tfaUtil.getParameterByName(t.cnxUtil.CNX_CLICK_ID_KEY, e.location.href),
            a;
        if (i && o) {
            var s = t.cnxUtil.buildTrackerIds(o);
            return n.storePublisherValue(n.TABOOLA_GLOBAL_KEY, t.cnxUtil.TBLA_CNX_ROI_COOKIE_NAME, s), o
        }
        if (a = n.getPublisherValue(n.TABOOLA_GLOBAL_KEY, t.cnxUtil.TBLA_CNX_ROI_COOKIE_NAME)) return a.split(t.cnxUtil.CNX_TRACKER_ID_SEPARATOR)[0]
    }, t.cnxUtil.buildTrackerIds = function(e) {
        var n = t.tfaPageManager,
            r = n.getPublisherValue(n.TABOOLA_GLOBAL_KEY, t.cnxUtil.TBLA_CNX_ROI_COOKIE_NAME);
        if (e) {
            var i = r ? r.split(t.cnxUtil.CNX_TRACKER_ID_SEPARATOR) : [];
            i.unshift(e), r = i.slice(0, t.cnxUtil.CNX_TRACKER_IDS_TO_KEEP).join(t.cnxUtil.CNX_TRACKER_ID_SEPARATOR)
        }
        return r
    };
    var n = e.TRCImpl = e.TRCImpl || {};
    n.global = n.global || {}, e.__trcError = e.__trcError || function e() {}
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    var n = "taboola global",
        r = "trctestcookie";

    function i() {
        for (var e = "trc_cookie_storage", n = new Object, r = document.cookie.split(/;\s+/), i = 0; i < r.length; i++) {
            var o = t.text.lsplit(r[i], "=", 2),
                a = unescape(o[0]),
                s = unescape(o[1]);
            if (a == e) {
                for (var c = s.split("|"), l = 0; l < c.length; l++) {
                    var o = c[l].split("=");
                    n[unescape(o[0])] = unescape(o[1])
                }
                break
            }
        }

        function u() {
            var t = new Array,
                r, i;
            for (var o in n) n.hasOwnProperty(o) && null != n[o] && (t[t.length] = escape(o) + "=" + escape(n[o]));
            r = t.length > 0 ? 1 : -1, i = new Date((new Date).getTime() + 365 * r * 864e5);
            var a = "",
                s = document.domain.match(/[^\.]*\.[^.]*$/);
            s && s.length > 0 && (a = ";domain=." + s[0]), document.cookie = e + "=" + escape(t.join("|")) + ";path=/;expires=" + i.toUTCString() + a
        }
        return this.getValue = function(e) {
            return n.hasOwnProperty(e) ? n[e] : null
        }, this.setValue = function(e, t) {
            n[e] = t, u()
        }, this.removeKey = function(e) {
            delete n[e], u()
        }, this
    }

    function o(e) {
        var t = e || {};
        return this.getValue = function(e) {
            return t[e] ? t[e] : null
        }, this.setValue = function(e, n) {
            t[e] = n
        }, this.removeKey = function(e) {
            delete t[e]
        }, this.getData = function() {
            return t
        }, this
    }

    function a(t) {
        return this.getValue = function(n) {
            return e[t + "Storage"].getItem(n)
        }, this.setValue = function(n, r) {
            try {
                e[t + "Storage"].setItem(n, r)
            } catch (e) {}
        }, this.removeKey = function(n) {
            try {
                e[t + "Storage"].removeItem(n)
            } catch (e) {}
        }, this
    }

    function s(t) {
        var n = e[t + "Storage"],
            r = (new Date).getTime() + "",
            i = "_taboolaStorageDetection";
        try {
            if (n.setItem(i, r), n.getItem(i) == r) return n.removeItem(i), n
        } catch (e) {}
        return null
    }

    function c(n) {
        try {
            if (e.localStorage instanceof Storage && t.useStorageDetection && s(n)) return new a(n)
        } catch (e) {
            return null
        }
    }

    function l(e) {
        var t = [c("local"), new i, c("session")];
        try {
            for (var n = 0, r = t; n < r.length; n++) {
                var a = r[n];
                if (a) {
                    var s = a.getValue(e);
                    if (s) return s
                }
            }
        } catch (e) {}
        return (new o).getValue(e)
    }
    var u = function r() {
        return this.state = {}, this.getLocalStorageImplementation = function(t, n) {
            if (null != this.state.privateStorageImpl && "strict-w3c-storage" != t) return this.state.privateStorageImpl;
            var r = e._tfa.config.safeGet("tfa:local-storage-usage", "prefer-w3c-storage");
            switch (t = t || r) {
                case "strict-w3c-storage":
                    return c("session" === n ? "session" : "local");
                case "prefer-w3c-storage":
                    var a = c("local");
                    if (a) return this.state.privateStorageImpl = a;
                case "prefer-cookies":
                    try {
                        if (this.canWriteCookies()) return this.state.privateStorageImpl = new i
                    } catch (e) {}
                default:
                    return this.state.privateStorageImpl = new o
            }
        }, this.getFirstPartyCookie = function() {
            if (this.state.firstPartyCookie) return this.state.firstPartyCookie;
            var e = this.getLocalStorageImplementation();
            if (e instanceof i || e instanceof o) return this.state.firstPartyCookie = e;
            try {
                if (this.canWriteCookies()) return this.state.firstPartyCookie = new i
            } catch (e) {}
            return this.state.firstPartyCookie = new o
        }, this.canWriteCookies = function() {
            return e.navigator.cookieEnabled
        }, this.getDummyStorage = function(e) {
            return new o(e)
        }, this.getValue = function(e) {
            return this.getPublisherValue(n, e)
        }, this.storePublisherValue = function(e, t, n) {
            var r;
            this.isNotAllowedToWriteValue(t, n) || (r = this.buildKeyWithPublisher(e, t), this.getLocalStorageImplementation().setValue(r, n), this.addKeyToStoredKeysList(r))
        }, this.isNotAllowedToWriteValue = function(e, n) {
            return null == n || void 0 == n || t.doNotTrack && !this.isAllowedKeyWhenDoNotTrack(e)
        }, this.buildKeyWithPublisher = function(e, t) {
            return e + ":" + t
        }, this.getPublisherValue = function(e, n) {
            return t.doNotTrack && !this.isAllowedKeyWhenDoNotTrack(n) ? null : l(this.buildKeyWithPublisher(e, n))
        }, this.addKeyToStoredKeysList = function(e) {
            var t = this.getStoredKeysList(); - 1 === t.indexOf(e) && (t.push(e), this.setStoredKeysList(t))
        }, this.getStoredKeysList = function() {
            var e = this.buildKeyWithPublisher(n, "local-storage-keys"),
                t = this.getLocalStorageImplementation().getValue(e),
                r = [];
            try {
                r = JSON.parse(t) || []
            } catch (e) {
                __trcError("Could not parse local storage keys", e)
            }
            return r
        }, this.setStoredKeysList = function(e) {
            var t, r;
            try {
                t = JSON.stringify(e), r = this.buildKeyWithPublisher(n, "local-storage-keys"), this.getLocalStorageImplementation().setValue(r, t)
            } catch (e) {
                __trcError("Could not stringify local storage keys", e)
            }
        }, this.isAllowedKeyWhenDoNotTrack = function(t) {
            var n, r = (e.TRCImpl && e.TRCImpl.global || {})["dnt-allowed-keys"] || ["session-id"],
                i;
            return null !== t && void 0 !== t && (i = t.split(":")[1] || t, -1 !== r.indexOf(i))
        }, this.storeUserId = function(e) {
            this.isNotAllowedToWriteValue("user-id", e) || this.storePublisherValue(n, "user-id", e)
        }, this.getUserIdFirstPartyCookie = function() {
            return this.getFirstPartyCookie().getValue(this.buildKeyWithPublisher(n, "user-id"))
        }, this.getSessionDataFirstPartyCookie = function() {
            return this.getFirstPartyCookie().getValue(this.buildKeyWithPublisher(n, "session-data"))
        }, this.initState = function() {
            void 0 === this.state && (this.state = {}), this.state.privateStorageImpl = null
        }, this.initState(), this
    };
    t.tfaPageManager = t.tfaPageManager || new u, t.tfaPageManager.TABOOLA_GLOBAL_KEY = n
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t, n) {
    var r = function e(t, n, r) {
            var i = t.split(n);
            return i.slice(0, r - 1).concat(i.length >= r ? i.slice(r - 1).join(n) : [])
        },
        i = n.TFA_URL = function(e) {
            if (!e) throw new Error("Invalid URL!");
            this.href = e;
            var t = r(e, "#", 2);
            return this.hash = t.length > 1 ? "#" + t.pop() : "", e = t[0], t = r(e, "?", 2), this.search = t.length > 1 ? "?" + t.pop() : "", e = t[0], t = r(e, "://", 2), this.protocol = t.length > 1 ? t.shift() + ":" : "", e = t[0], t = r(e, "/", 2), this.pathname = t.length > 1 ? "/" + t.pop() : "/", e = t[0], t = r(e, "@", 2), this.auth = t.length > 1 ? t.shift() : "", e = t[0], t = r(e, ":", 2), this.port = t.length > 1 ? parseInt(t.pop()) : 0, this.host = t[0], this
        };

    function o(e) {
        for (var t = {}, n = 0; n < e.length; n++)
            if (e[n]) {
                var r = e[n].split(new RegExp("="), 2);
                2 === r.length && (t[r[0]] = r[1])
            }
        return t
    }

    function a(e, t, n) {
        for (var r in e)
            if (unescape(r) == t) return n ? n(e[r]) : unescape(e[r]);
        return null
    }
    i.prototype.getParameter = function(e, t) {
        var r;
        return a(n.TFA_URL.prototype.getQueryStringObj.call(this), e, t)
    }, i.prototype.getParameterFromHash = function(e, t) {
        var r;
        return a(n.TFA_URL.prototype.getHashStringObj.call(this), e, t)
    }, i.prototype.getQueryStringObj = function() {
        var e, t;
        return o((this instanceof n.TFA_URL ? this : new n.TFA_URL(this)).search.substr(1).split(/&/))
    }, i.prototype.getHashStringObj = function() {
        var e, t;
        return o((this instanceof n.TFA_URL ? this : new n.TFA_URL(this)).hash.substr(1).split(/&/))
    }, i.prototype.addParamsToUrl = function(e, t) {
        var n = e.split("#");
        return n[0] + (n[0].search("\\?") >= 0 ? "&" : "?") + t + (n[1] ? "#" + n[1] : "")
    }, i.prototype.removeParamFromUrl = function(e, t) {
        var n = e.split("?");
        if (n.length >= 2) {
            for (var r = n[0], i, o = [], a = n[1].split("&"), s = 0; s < a.length; s++) {
                var c;
                a[s].split("=")[0] !== t && o.push(a[s])
            }
            return o.length > 0 ? r + "?" + o.join("&") : r
        }
        return e
    }, i.prototype.removeAllUrlParametersAndFragment = function(e) {
        var t = e.indexOf("?"),
            n = -1 !== t ? e.substr(0, t) : e,
            r = n.indexOf("#");
        return -1 !== r ? n.substr(0, r) : n
    }
}(window, document, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t, n) {
    var r = n.tfaPageManager,
        i = "https://",
        o = "tblci",
        a = "TABOOLA-DO-NOT-TRACK",
        s = "(?:tbl|Gi)[A-Za-z0-9_-]{40,200}",
        c = new RegExp("^#" + o + "(" + s + ")"),
        l = new RegExp("^" + s),
        u = {
            QUERY: "q",
            HASH: "h",
            CUSTOM_QUERY: "cq",
            LOCAL_STORAGE: "ls"
        };

    function f(e, t) {
        e && t && (t[e] = !0)
    }

    function d(e, t, n) {
        for (var r = {}, i = 0; i < arguments.length; i++) f(arguments[i], r);
        return Object.keys(r).length > 1
    }
    n.tfaUserId = {
        initialized: !1,
        userId: null,
        clickId: null,
        clickIdSource: null,
        cnxClickId: null,
        getUserId: function e() {
            return this.userId
        },
        getClickId: function e() {
            return this.clickId
        },
        getClickIdSource: function e() {
            return this.clickIdSource
        },
        getCnxClickId: function e() {
            return this.cnxClickId
        },
        getHttpsPrefix: function e() {
            return i
        },
        sendUserIdsToTrc: function t(r, i, o, a) {
            var s, c = 'https:',
                l = [];
            if (d(r, i, o)) return n.tfaUtil.safeAddParam("uiref", r, l), n.tfaUtil.safeAddParam("uils", i, l), n.tfaUtil.safeAddParam("uifpc", o, l), n.tfaUtil.safeAddParam("tblci", a, l), s = new Image, e._tfa.config.safeGet("tfa:add-referrer-policy-when-firing-pixel", !0) && (s.referrerPolicy = "no-referrer-when-downgrade"), s.src = c + "//trc.taboola.com/sg/taboola-tfa/1/um/?" + l.join("&"), s
        },
        isUserCanBeTracked: function t(n) {
            return !n || !e._tfa.config.safeGet("tfa-uid:filter-do-not-track", !0) || -1 === n.indexOf(a)
        },
        readAndStoreUserId: function e() {
            var t = this.extractUserIdFromReferrer(),
                n = r.getValue("user-id"),
                i = r.getUserIdFirstPartyCookie();
            this.isUserCanBeTracked(t) || (t = void 0), this.isUserCanBeTracked(n) || (n = void 0), this.isUserCanBeTracked(i) || (i = void 0), this.sendUserIdsToTrc(t, n, i, this.getClickId()), t && (r.storeUserId(t), i && r.getFirstPartyCookie().setValue(r.TABOOLA_GLOBAL_KEY + ":" + "user-id", t)), this.userId = t || n || i
        },
        readAndStoreClickIdParam: function e() {
            var t = this.extractClickIdFromUrl(this.getWindowLocation().toString()) || this.extractClickIdFromUrl(this.getItemUrlFromTrk()) || this.extractClickIdFromUrl(this.getReferrer()),
                n = t ? t.clickId : null,
                i = t ? t.source : null,
                a = r.getValue(o);
            n ? (r.storePublisherValue(r.TABOOLA_GLOBAL_KEY, o, n), this.clickId = n, this.clickIdSource = i) : a && (this.clickId = a, this.clickIdSource = u.LOCAL_STORAGE)
        },
        readAndStoreCnxClickId: function e() {
            this.cnxClickId = n.cnxUtil.getCnxClickId() || null
        },
        extractUserIdFromReferrer: function e() {
            var t = this.getReferrer();
            if (t && t.indexOf("taboola") > -1) return n.tfaUtil.getParameterByName("ui", t)
        },
        searchAllParameterValuesForClickId: function e(t) {
            if (t)
                for (var r = n.TFA_URL.prototype.getQueryStringObj.call(t), i = Object.keys(r), o = 0; o < i.length; o++) {
                    var a = r[i[o]],
                        s = decodeURIComponent(a),
                        c = s && s.match(l);
                    if (c) return c[0]
                }
        },
        extractClickIdFromUrl: function t(r) {
            if (r) {
                var i = r.length > 1 && r.indexOf("#") > -1 ? r.substring(r.indexOf("#")) : "",
                    a = n.tfaUtil.getParameterByName(o, r),
                    s, l;
                if (a) return {
                    clickId: a,
                    source: u.QUERY
                };
                if (l = i.match(c)) return {
                    clickId: l[1],
                    source: u.HASH
                };
                if (e._tfa.config.safeGet("tfa:search-click-id-in-query-string-enabled", !0) && (s = this.searchAllParameterValuesForClickId(r))) return {
                    clickId: s,
                    source: u.CUSTOM_QUERY
                }
            }
        },
        getWindowLocation: function t() {
            return e.location
        },
        getReferrer: function e() {
            return t.referrer
        },
        getItemUrlFromTrk: function e() {
            return n && n.trk && "function" == typeof n.trk.getItemUrl && n.trk.getItemUrl()
        },
        init: function e() {
            this.initialized || (this.readAndStoreClickIdParam(), this.readAndStoreCnxClickId(), this.readAndStoreUserId(), this.initialized = !0)
        }
    }, n.tfaUserId.init(), n.tfaUserId.CLICK_ID_KEY = o, n.tfaUserId.CLICK_ID_SOURCE = u
}(window, document, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    var n = "_tfa",
        r = e[n] = e[n] || [],
        i, o, a, s, c = 6 * 60 * 60 * 1e3,
        l = "eng_mt",
        u = "crossSessionsData",
        f = 36,
        d;

    function p(e, t, n) {
        var r = this.getTimeLeftForSession(e, this.getSessionDuration(), t);
        r < 0 && (r = 0), setTimeout(function() {
            n()
        }, r)
    }

    function h(e) {
        return e.ver && e.ver === this.getDataVersion()
    }
    var g = function e() {};
    g.prototype = {
        constructor: g,
        init: function e(n) {
            if (d = r.config.safeGet("tfa:engagement:session-duration-in-milliseconds", c), !this.isInitialized()) {
                var i = t.eventUtils.getDateNow(),
                    o = this.getSessionDataFromStorage();
                if (this.getIsLocalStorageAvailable()) return a = o && o.sessionStartTime, p.call(this, o, i, n), a && !this.isSessionInvalid(o) || (a = i, this.persistDefaultValues(a)), s = !0, this
            }
        },
        getStorageKey: function e() {
            return l
        },
        getCrossSessionsData: function e(t) {
            var n = t && t.getValue(this.getStorageKey()),
                r = n && JSON.parse(n);
            return r && r[u]
        },
        resetStorageMetricData: function e() {
            var n = t.tfaPageManager.getLocalStorageImplementation("strict-w3c-storage"),
                r = this.getCrossSessionsData(n),
                i = {
                    crossSessionsData: r
                };
            n.setValue(this.getStorageKey(), r ? JSON.stringify(i) : "")
        },
        hasOnlyCrossSessionData: function e(t, n) {
            return t && 1 === t.length && n.hasOwnProperty(u)
        },
        isSessionInvalid: function e(t) {
            if (!t) return !0;
            var n = Object.keys(t);
            return this.hasOnlyCrossSessionData(n, t)
        },
        getSessionDataFromStorage: function e() {
            var n, r;
            n = t.tfaPageManager.getLocalStorageImplementation("strict-w3c-storage"), o = !!n;
            var i = n && n.getValue(this.getStorageKey());
            if (r = i && JSON.parse(i)) return this.isSessionInvalid(r) ? r : !h.call(this, r) || this.hasSessionEnded() ? (this.resetStorageMetricData(), r) : r
        },
        hasSessionEnded: function e() {
            return !!s && (!a || t.eventUtils.getDateNow() - a > this.getSessionDuration())
        },
        persistDefaultValues: function e(n) {
            var r = t.tfaPageManager.getLocalStorageImplementation("strict-w3c-storage");
            if (r) {
                var i = {
                        ver: f,
                        sessionStartTime: n,
                        scrollDepth: 0,
                        sessionDepth: [],
                        timeOnSite: 0
                    },
                    o = this.getCrossSessionsData(r);
                o && (i[u] = o), r.setValue(this.getStorageKey(), JSON.stringify(i))
            }
        },
        persistSpecificMetricsData: function e(n, r) {
            var i = t.tfaPageManager.getLocalStorageImplementation("strict-w3c-storage"),
                o;
            i && n && (o = this.getSessionDataFromStorage()) && (o[n] = r, i.setValue(this.getStorageKey(), JSON.stringify(o)))
        },
        getCrossSessionsDataKey: function e() {
            return u
        },
        getSessionDuration: function e() {
            return d
        },
        getDataVersion: function e() {
            return f
        },
        getIsLocalStorageAvailable: function e() {
            return o
        },
        getSessionStartTime: function e() {
            return a
        },
        getTimeLeftForSession: function e(t, n, r) {
            return t && a ? a + n - r : n
        },
        isInitialized: function e() {
            return s
        }
    }, (i = r.TEM = r.TEM || {}).ESU = i.ESU || new g
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    var n = "_tfa",
        r;

    function i(e, t) {
        this.storageUtils.persistSpecificMetricsData(e, t)
    }
    var o = function e() {};
    o.prototype = {
        constructor: o,
        init: function e(t, n, r) {
            this.isValid = t && n && r, this.storageUtils = t, this.visibilityListener = r, this.refreshFromStorage(), this.initLastVisibleStartTime(), this.visibilityListener.subscribeToEvent(this.handleVisibilityChange.bind(this)), n.subscribeToEvent(this.handleStorageChange.bind(this))
        },
        getStorageKey: function e() {
            return "timeOnSite"
        },
        initLastVisibleStartTime: function e() {
            this.isValid && (this.lastVisibleStartTime = t.eventUtils.getDateNow())
        },
        refreshFromStorage: function e() {
            if (this.isValid) {
                var t = this.storageUtils.getSessionDataFromStorage(),
                    n = 0;
                t && t[this.getStorageKey()] && (n = t[this.getStorageKey()] || 0), this.timeOnSite = n
            }
        },
        calcTimeOnSite: function e() {
            if (this.isValid) return this.lastVisibleStartTime ? this.timeOnSite + (t.eventUtils.getDateNow() - this.lastVisibleStartTime) : this.timeOnSite
        },
        handleVisibilityChange: function e() {
            this.isValid && (this.visibilityListener.getIsPageHidden() ? (this.timeOnSite = this.calcTimeOnSite(), i.call(this, this.getStorageKey(), this.timeOnSite)) : this.lastVisibleStartTime = t.eventUtils.getDateNow())
        },
        handleStorageChange: function e() {
            this.refreshFromStorage()
        },
        getTimeOnSite: function e() {
            if (this.isValid) return this.visibilityListener.getIsPageHidden() ? this.timeOnSite : this.calcTimeOnSite()
        }
    }, (r = e[n] = e[n] || []).TEM = r.TEM || {}, r.TEM.TOS = r.TEM.TOS || new o
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function() {
    var e = "_tfa",
        t, n = !1,
        r;

    function i() {
        return void 0 == document.body || void 0 == document.documentElement ? 0 : (n = !0, Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight) - document.documentElement.clientHeight);
        var e
    }

    function o(e, t) {
        this.storageUtils.persistSpecificMetricsData(e, t)
    }

    function a(e, t) {
        var n;
        return function() {
            var r = this,
                i = arguments;
            clearTimeout(n), n = setTimeout(function() {
                e.apply(r, i)
            }, t)
        }
    }
    var s = function e() {};
    s.prototype = {
        constructor: s,
        init: function e(t, n) {
            this.storageUtils = t || {}, n.subscribeToEvent(this.handleStorageChange.bind(this)), this.refreshFromStorage(), this.initEventListeners(), this.updateMeasurements(), this.calcMaxScrollPercentage()
        },
        getStorageKey: function e() {
            return "scrollDepth"
        },
        getScrollDepth: function e() {
            return n || this.calcMaxScrollPercentage(), this.maxScrollPercentage
        },
        getMaxScrollableAmount: function e() {
            return n || (this.maxScrollableAmount = i()), this.maxScrollableAmount
        },
        initEventListeners: function e() {
            window.addEventListener("resize", a(this.onResize.bind(this), 100)), window.addEventListener("scroll", a(this.onScroll.bind(this), 50))
        },
        refreshFromStorage: function e() {
            var t = this.storageUtils.getSessionDataFromStorage(),
                n = 0;
            t && t[this.getStorageKey()] && (n = t[this.getStorageKey()] || 0), this.maxScrollPercentage = n
        },
        onResize: function e() {
            this.updateMeasurements()
        },
        onScroll: function e() {
            this.calcMaxScrollPercentage()
        },
        updateMeasurements: function e() {
            this.winHeight = window.innerHeight, this.maxScrollableAmount = i()
        },
        calcMaxScrollPercentage: function e() {
            this.updateMeasurements();
            var t = 0 === this.maxScrollableAmount ? 0 : Math.floor(window.pageYOffset / this.maxScrollableAmount * 100);
            t > this.maxScrollPercentage && (this.maxScrollPercentage = t, o.call(this, this.getStorageKey(), this.maxScrollPercentage))
        },
        handleStorageChange: function e() {
            this.refreshFromStorage()
        }
    }, (r = (t = window[e] = window[e] || []).TEM = t.TEM || {}).SCD = r.SCD || new s
}(),
function(e, t) {
    var n, r, i = e["_tfa"].TEM,
        o = function e() {};
    o.prototype = {
        constructor: o,
        init: function e(n, r, i) {
            this.storageUtils = n, this.refreshFromStorage(), t.eventUtils.safeAddEventListener(i, this.handleUnipPageView.bind(this)), r.subscribeToEvent(this.handleStorageChange.bind(this))
        },
        getKey: function e() {
            return "ssd"
        },
        getStorageKey: function e() {
            return "sessionDepth"
        },
        setState: function e(t) {
            this.visitedUrls = {};
            for (var n = 0; n < t.length; n++) this.visitedUrls[t[n]] = !0
        },
        getState: function e() {
            return this.visitedUrls ? Object.keys(this.visitedUrls) : []
        },
        getMetric: function e() {
            return this.getState().length
        },
        persistState: function e() {
            var t = this.getState();
            this.storageUtils.persistSpecificMetricsData(this.getStorageKey(), t)
        },
        refreshFromStorage: function e() {
            var t = this.storageUtils.getSessionDataFromStorage(),
                n = [];
            t && t[this.getStorageKey()] && (n = t[this.getStorageKey()] || []), this.setState(n)
        },
        handleUnipPageView: function e() {
            try {
                var n = t.eventUtils.hashString(window.location.href);
                this.visitedUrls[n] || (this.visitedUrls[n] = !0, this.persistState())
            } catch (e) {}
        },
        handleStorageChange: function e() {
            this.refreshFromStorage()
        },
        isURLVisited: function e(t) {
            return this.visitedUrls && this.visitedUrls[t]
        }
    }, i.SSD = i.SSD || new o
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e) {
    var t, n = e["_tfa"] || [],
        r = n.TEM || {},
        i = 30 * 24 * 60 * 60 * 1e3,
        o = 10,
        a = "tfa:engagement:session-history-timeframe-in-milliseconds",
        s = "tfa:engagement:session-history-limit",
        c = "sessionsHistory",
        l, u, f = function e() {};
    f.prototype = {
        init: function e(t) {
            l = n.config.safeGet(s, o), u = n.config.safeGet(a, i), this.storageUtils = t, this.updateCrossSessionsData(this.storageUtils.getSessionStartTime())
        },
        updateCrossSessionsData: function e(t) {
            var n = this.updateData(t);
            return this.storageUtils.persistSpecificMetricsData(this.storageUtils.getCrossSessionsDataKey(), n), n
        },
        updateData: function e(t) {
            var n = this.getCrossSessionsDataFromStorage() || {};
            return n[c] = this.getSessionsHistory(t), n
        },
        resetCrossSessionsData: function e() {
            this.storageUtils.persistSpecificMetricsData(this.storageUtils.getCrossSessionsDataKey(), "")
        },
        getCrossSessionsDataFromStorage: function e() {
            var t = this.storageUtils.getSessionDataFromStorage();
            return t && t[this.storageUtils.getCrossSessionsDataKey()]
        },
        getFilteredSessionsHistory: function e(t, n) {
            var r = t ? this.removeOldSessions(t, n) : [];
            if (!r.indexOf(n) > -1 && !this.isInPreviousSession(r, n)) {
                for (; r.length > l - 1;) r.shift();
                r.push(n)
            }
            return r
        },
        removeOldSessions: function e(t, n) {
            for (var r = [], i = 0; i < t.length; i++) this.isSessionOld(t[i], n) || r.push(t[i]);
            return r
        },
        isSessionOld: function e(t, n) {
            return n - u > t
        },
        getSessionsHistory: function e(t) {
            var n = this.getCrossSessionsDataFromStorage(),
                r = n ? n[c] : [];
            return this.getFilteredSessionsHistory(r, t)
        },
        isInPreviousSession: function e(t, n) {
            return !(!Array.isArray(t) || !t.length) && n - t[t.length - 1] < this.storageUtils.getSessionDuration();
            var r, i
        }
    }, r.crossSessionsUtils = r.crossSessionsUtils || new f
}(window),
function(e) {
    var t, n = e["_tfa"] || [],
        r = n.TEM || {},
        i = "tfa:engagement:return-visits:is-enabled",
        o, a = function e() {};
    a.prototype = {
        init: function e(t, r, a) {
            (o = n.config.safeGet(i, !1)) && (this.storageUtils = t, this.crossSessionsUtils = a, this.refreshSessionsHistoryFromLocalStorage(), r.subscribeToEvent(this.handleStorageChange.bind(this)))
        },
        setState: function e(t) {
            this.sessionsHistory = [];
            for (var n = 0; n < t.length; n++) this.sessionsHistory.push(t[n])
        },
        addReturnVisits: function e(t) {
            if (t) {
                if (o) {
                    var n = this.getReturnVisits();
                    t.rv = n && n.length
                }
                return t
            }
        },
        getReturnVisits: function e() {
            var t = this.sessionsHistory;
            return Array.isArray(t) && t.length ? t : []
        },
        refreshSessionsHistoryFromLocalStorage: function e() {
            var t = this.storageUtils ? this.storageUtils.getSessionStartTime() : [],
                n = this.crossSessionsUtils && this.crossSessionsUtils.getSessionsHistory(t);
            this.setState(n)
        },
        handleStorageChange: function e() {
            this.refreshSessionsHistoryFromLocalStorage()
        }
    }, r.returnVisits = r.returnVisits || new a
}(window),
function(e, t) {
    var n = "_tfa",
        r, i = function e() {};
    i.prototype = {
        constructor: i,
        init: function e() {
            this.runningId = 0, this.subscribers = {}, this.setVisibilityProperties(), this.initMetricData(), this.initListener()
        },
        initMetricData: function e() {
            this.isPageHidden = document[this.hiddenProp]
        },
        initListener: function e() {
            t.eventUtils.safeAddEventListener(this.visibilityChangeEventName, this.handleVisibilityChange.bind(this))
        },
        setVisibilityProperties: function e() {
            void 0 !== document.hidden ? (this.hiddenProp = "hidden", this.visibilityChangeEventName = "visibilitychange") : void 0 !== document.msHidden ? (this.hiddenProp = "msHidden", this.visibilityChangeEventName = "msvisibilitychange") : void 0 !== document.webkitHidden && (this.hiddenProp = "webkitHidden", this.visibilityChangeEventName = "webkitvisibilitychange")
        },
        handleVisibilityChange: function e() {
            this.isPageHidden = document[this.hiddenProp], this.notify()
        },
        getIsPageHidden: function e() {
            return this.isPageHidden
        },
        subscribeToEvent: function e(t) {
            var n = this.runningId++;
            return this.subscribers[n] = t,
                function() {
                    delete this.subscribers[n]
                }.bind(this)
        },
        notify: function e() {
            Object.keys(this.subscribers).forEach(function(e) {
                this.subscribers[e]()
            }.bind(this))
        }
    }, (r = e[n] = e[n] || []).TEM = r.TEM || {}, r.TEM.visibilityListener = r.TEM.visibilityListener || new i
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    var n = "_tfa",
        r, i = function e() {};
    i.prototype = {
        constructor: i,
        init: function e(t) {
            this.runningId = 0, this.subscribers = {}, this.storageUtils = t, this.initListener()
        },
        initListener: function e() {
            t.eventUtils.safeAddEventListenerToWindow("storage", this.handleStorageChange.bind(this))
        },
        handleStorageChange: function e(t) {
            t && t.key === this.storageUtils.getStorageKey() && this.notify(t)
        },
        subscribeToEvent: function e(t) {
            var n = this.runningId++;
            return this.subscribers[n] = t,
                function() {
                    delete this.subscribers[n]
                }.bind(this)
        },
        notify: function e(t) {
            Object.keys(this.subscribers).forEach(function(e) {
                this.subscribers[e](t)
            }.bind(this))
        }
    }, (r = e[n] = e[n] || []).TEM = r.TEM || {}, r.TEM.storageListener = r.TEM.storageListener || new i
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    var n = "_tfa",
        r = e[n] = e[n] || [],
        i, o = r.TEM = r.TEM || {},
        a = o.ESU || {},
        s = o.SCD || {},
        c = o.SSD || {},
        l = o.TOS || {},
        u = o.returnVisits || {},
        f = o.crossSessionsUtils || {},
        d = o.visibilityListener || {},
        p = o.storageListener || {},
        h = 1500,
        g = 50,
        v = 3e4,
        m = "numOfTimesMetricsSent",
        y = "pre_d_eng_tb",
        S = "external-pixel-id",
        b = "external-source",
        E = {
            SESSION_END: "SESSION_END"
        },
        I, C, T = !1,
        _ = Date.now();

    function w(e, t) {
        var n = l.getTimeOnSite(),
            r = s.getScrollDepth(),
            o = c.getMetric(),
            f = {
                notify: "event",
                name: y,
                tos: n,
                scd: r,
                ssd: o,
                est: a.getSessionStartTime(),
                ver: a.getDataVersion(),
                isls: a.getIsLocalStorageAvailable(),
                src: e,
                invt: t,
                msa: "function" == typeof s.getMaxScrollableAmount ? s.getMaxScrollableAmount() : void 0
            };
        return f = u.addReturnVisits(f), i.externalPixelId && (f[S] = i.externalPixelId), i.externalSource && (f[b] = i.externalSource), f
    }

    function k(e, t) {
        var n = w(e, t);
        n.est && (i.pageViewAccountIds ? R(i.pageViewAccountIds, n) : O(n))
    }

    function R(e, t) {
        var n = Object.keys(e);
        n.length > 0 ? n.forEach(function(n) {
            t.id = e[n], O(t)
        }) : O(t)
    }

    function O(e) {
        i.push(e)
    }

    function P() {
        A(), a.resetStorageMetricData()
    }

    function A() {
        clearTimeout(C)
    }

    function U(e) {
        (isNaN(I) || I < 0) && (I = 0), a.hasSessionEnded() || (I++, a.persistSpecificMetricsData(m, I), N() || o.sendMetrics("i", e), x())
    }

    function N() {
        return l.getTimeOnSite() > 5 * 60 * 1e3 && c.getMetric() > 5
    }

    function D(e) {
        var t;
        return t = 0 === e ? 4500 : 1 === e ? 5500 : e > 1 && e <= 9 ? 1e4 : h * Math.pow(2, e - 3)
    }

    function x() {
        if (clearTimeout(C), T && !d.getIsPageHidden()) {
            var e, t = r.config.safeGet("tfa:engagement:use-new-interval-calculation", !1) ? D(I) : h * Math.pow(2, I);
            t !== 1 / 0 && (C = setTimeout(U, t, t))
        }
    }

    function L() {
        M(), x()
    }

    function M() {
        var e = a.getSessionDataFromStorage();
        I = e && e[m] && e[m] || 0
    }

    function j() {
        p.subscribeToEvent(B.bind(this)), d.subscribeToEvent(V.bind(this))
    }

    function V() {
        d.getIsPageHidden() ? A() : x()
    }

    function B(e) {
        function t(e) {
            var t = JSON.parse(e.newValue),
                i = JSON.parse(e.oldValue);
            return !n(t, i) && !r(t, i)
        }

        function n(e, t) {
            return e.sessionDepth.length !== t.sessionDepth.length
        }

        function r(e, t) {
            return e.timeOnSite !== t.timeOnSite
        }
        M(), e && T && !d.getIsPageHidden() && t(e) && (T = !1, A(), F(g, v, L, A))
    }

    function F(e, t, n, r) {
        var i = !1;

        function o(e) {
            if (window.top !== window) {
                var t = window.parent;
                for (t.postMessage(e, "*"); t !== t.parent;)(t = t.parent).postMessage(e, "*")
            }

            function n(t) {
                try {
                    for (var r = 0; r < t.frames.length; r++) {
                        var i = t.frames[r];
                        i !== window && (i.postMessage(e, "*"), n(i))
                    }
                } catch (e) {}
            }
            n(window.top), window.parent !== window && n(window)
        }

        function a() {
            o({
                type: "TARP",
                query: !1,
                t: _
            })
        }

        function s() {
            i = !1, o({
                type: "TARP",
                query: !0
            }), setTimeout(function() {
                i ? setTimeout(t, s) : T || (T = !0, n(), a())
            }, e)
        }
        T = !1, window.addEventListener("message", function(e) {
            var o = e.data;
            o && "TARP" === o.type && e.source !== window && (T ? o.query ? a() : o.t < _ ? (T = !1, i = !0, r(), setTimeout(t, s)) : a() : o.query || (o.t < _ ? i = !0 : (T = !0, n(), a())))
        }), s()
    }

    function K() {
        o.initialized || r.config.safeGet("tfa:engagement:is-manager-disabled", !1, 1603492) || (i = r.TUP || {}, o.initialized = !0, o.ESU.init(P), d.init(), p.init(a), j(), o.ESU.getIsLocalStorageAvailable() && (f.init(a), l.init(a, p, d), s.init(a, p), c.init(a, p, t.sharedEvents.PAGE_VIEW), u.init(a, p, f), o.initIntervalTrigger()), F(g, v, L, A))
    }
    o.init = o.init || K, o.onSessionEndTrigger = o.onSessionEndTrigger || P, o.sendMetrics = o.sendMetrics || k, o.initIntervalTrigger = o.initIntervalTrigger || L, o.EVENTS = o.EVENTS || E
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t) {
    var n = "_tfa",
        r = e[n] = e[n] || [],
        i = "taboola global:last-external-referrer",
        o = "taboola",
        a = "other",
        s = ["taboola", "taboolanews", "taboolasyndication"];
    t.lastExternalReferrer = {
        init: function e() {
            r.config.safeGet("tfa:last-external-referrer:is-disabled", !1, 1603492) || this.extractExternalReferrerIfExistsAndStoreLocally()
        },
        extractExternalReferrerIfExistsAndStoreLocally: function t() {
            var n = this.extractExternalReferrer(e);
            n && this.saveExternalReferrerToLocalStorage(n)
        },
        extractExternalReferrer: function e(n) {
            var r = n.location.href,
                i = this.getExternalReferrer(n);
            return this.isExternalReferrerTaboola(r, i) ? o : i || t.tfaUtil.getParameterByName("utm_source", r) || t.tfaUtil.getParameterByName("gclid", r) || t.tfaUtil.getParameterByName("fbclid", r) || t.tfaUtil.getParameterByName("dicbo", r) || t.tfaUtil.getParameterByName("dclid", r) ? a : ""
        },
        isExternalReferrerTaboola: function e(n, r) {
            if (t.tfaUtil.getParameterByName("tblci", n)) return !0;
            var i = t.tfaUtil.getParameterByName("utm_source", n);
            if (i && "taboola" === i.toLowerCase()) return !0;
            if (r)
                for (var o = r.split("/")[2], a = 0; a < s.length; a++) {
                    var c, l;
                    if (new RegExp("(^|.+\\.)" + s[a] + "\\.com.*").exec(o)) return !0
                }
            return !1
        },
        getExternalReferrer: function e(t) {
            var n = t.document.referrer,
                r, i;
            if (n && t.location.hostname !== n.split("/")[2]) return n;
            return ""
        },
        saveExternalReferrerToLocalStorage: function e(n) {
            var r = t.tfaPageManager.getLocalStorageImplementation("strict-w3c-storage");
            r && r.setValue(i, n)
        },
        getLastExternalReferrer: function n() {
            var r = t.tfaPageManager.getLocalStorageImplementation("strict-w3c-storage");
            return r ? r.getValue(i) : this.extractExternalReferrer(e)
        }
    }, t.lastExternalReferrer.init()
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t, n) {
    var r = "https://pa.taboola.com/ig/joinIg.html";
    n.privacySandbox = {
        isProtectedAudienceSupported: function e() {
            return navigator && !!navigator.joinAdInterestGroup
        },
        joinInterestGroupsInIframe: function e(t) {
            var n;
            if (this.isProtectedAudienceSupported() && t && t.igList && Array.isArray(t.igList) && t.igList.length) return (n = document.createElement("iframe")).style.display = "none", n.src = r, n.addEventListener("load", function() {
                n.contentWindow.postMessage(JSON.stringify(t), "*")
            }), document.body.appendChild(n), n
        }
    }
}(window, document, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']),
function(e, t, n) {
    var r = "tfa:allow-cross-domain-tracking",
        i = "tfa:cross-domain-tracking:elements-to-update",
        o = [{
            selector: 'a[href^="http"], a[href^="https"], a[href^="//"]',
            urlAttribute: "href"
        }],
        a = "UpdateTrackingData",
        s = ["tblci"],
        c = n.jsScope,
        l = n.publisherId,
        u = c.tfaPageManager;

    function f() {
        e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(r, !1, l) && c.cdt.init()
    }
    e.TRC = e.TRC || {}, e.TRC.cdt = c.cdt = e.TRC.cdt || {
        init: function e() {
            t.addEventListener(a, this.updateTrackingData.bind(this)), this.verifyUpdatesAfterDomLoaded()
        },
        updateTrackingData: function e() {
            for (var t = this.getAdvertiserSelectors(), n = 0; n < t.length; n++) try {
                var r = this.getLinksToUpdate(t[n].selector, t[n].urlAttribute);
                this.updateLinks(r, t[n].urlAttribute)
            } catch (e) {}
        },
        getAdvertiserSelectors: function t() {
            try {
                var n = e._tfa.config.safeGet(i, "", l);
                if (n || "" !== n) return JSON.parse(n).concat(o)
            } catch (e) {}
            return o
        },
        getLinksToUpdate: function e(n, r) {
            for (var i = window.location.hostname, o = [], a = t.querySelectorAll(n), s = 0; s < a.length; ++s) try {
                var l = a[s],
                    u, f;
                i !== new c.TFA_URL(l.getAttribute(r)).host && o.push(l)
            } catch (e) {}
            return o
        },
        updateLinks: function e(t, n) {
            for (var r = 0; r < t.length; r++) {
                var i = t[r],
                    o = this.updateUrl(i, n);
                i.setAttribute(n, o)
            }
        },
        updateUrl: function e(t, n) {
            for (var r = t.getAttribute(n), i = 0; i < s.length; i++) {
                var o;
                if (!(null !== this.getQueryParamFromSearch(r, s[i]) || null !== this.getQueryParamFromHash(r, s[i]))) {
                    var a = this.getQueryParamFromSearch(window.location.href, s[i]);
                    if (a) {
                        var l = s[i] + "=" + a;
                        return c.TFA_URL.prototype.addParamsToUrl.call(t, r, l)
                    }
                    var u = this.getQueryParamFromHash(window.location.href, s[i]);
                    if (u) {
                        var f = s[i] + "=" + u;
                        return c.TFA_URL.prototype.addParamsToUrl.call(t, r, f)
                    }
                    var d = this.getParamFromLocalStorage(s[i]);
                    if (d) {
                        var p = s[i] + "=" + d;
                        return c.TFA_URL.prototype.addParamsToUrl.call(t, r, p)
                    }
                }
            }
            return r
        },
        getParamFromLocalStorage: function e(t) {
            return u.getValue(t)
        },
        getQueryParamFromSearch: function e(t, n) {
            return c.TFA_URL.prototype.getParameter.call(t, n)
        },
        getQueryParamFromHash: function e(t, n) {
            return c.TFA_URL.prototype.getParameterFromHash.call(t, n)
        },
        dispatchUpdateTrackingData: function e() {
            if ("complete" === t.readyState) {
                var n = new CustomEvent(a);
                t.dispatchEvent(n)
            }
        },
        verifyUpdatesAfterDomLoaded: function e() {
            var n;
            "complete" === t.readyState ? this.dispatchUpdateTrackingData() : t.addEventListener("readystatechange", this.dispatchUpdateTrackingData.bind(this))
        }
    }, e.TRC.cdtInit = c.cdtInit = f, f()
}(window, document, {
    publisherId: 1603492,
    jsScope: window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']
}),
function(e, t, n) {
    var r = "tfa:allow-codeless-tracking",
        i = "tfa:codeless-domain-override",
        o = "taboola-codeless-active",
        a = n.jsScope,
        s = n.publisherId;

    function c() {
        return t.referrer && "string" == typeof t.referrer && t.referrer.indexOf("ads.realizeperformance.com") > -1
    }

    function l() {
        try {
            return !!sessionStorage.getItem(o)
        } catch (e) {
            return !1
        }
    }

    function u() {
        (c() || l()) && e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(r, !1, s) && a.codeless.init()
    }
    e.TRC = e.TRC || {}, e.TRC.codeless = a.codeless = e.TRC.codeless || {
        shouldUseCspBypass: function t() {
            return !!(e._tfa && e._tfa.config && e._tfa.config.safeGet) && !0 === e._tfa.config.safeGet(i, !1, s)
        },
        isCodelessResourceUrl: function t(n) {
            return "string" == typeof n && "string" == typeof e.__CODELESS_APP_HOST__ && 0 === n.indexOf(e.__CODELESS_APP_HOST__ + "/resources/codeless/")
        },
        init: function e() {
            this.loadCodelessScript()
        },
        loadCodelessScript: function n() {
            var r = t.createElement("script"),
                i, o = this.shouldUseCspBypass() ? "https://code.taboola.com" : "https://ads.realizeperformance.com";
            e.__CODELESS_APP_HOST__ = o;
            var a = o + "/resources/codeless/codeless-events.js",
                s = (new Date).getTime();
            r.src = a + "?t=" + s, r.async = !0, r.type = "text/javascript", r.id = "codeless_script", t.head.appendChild(r)
        }
    }, e.TRC.codelessInit = a.codelessInit = u, u()
}(window, document, {
    publisherId: 1603492,
    jsScope: window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']
}),
function(e, t, n) {
    var r = n.jsScope;
    e.TRC = e.TRC || {};
    var i = "advancedMatching",
        o = "originalMatching",
        a = "tfa:tfa-codeless-tracking:advanced-matching",
        s = "tfa:allow-codeless-debug-events",
        c = "tfa:tfa-codeless-tracking:selector-matching-by-native-css";

    function l() {
        if (!isNaN(parseInt(n.publisherId, 10))) return n.publisherId;
        if (e._tfa && e._tfa.config && e._tfa.config.firstPublisherId) {
            var t = e._tfa.config.firstPublisherId;
            if (!isNaN(parseInt(t, 10))) return t
        }
        return null
    }
    e.TRC.codelessTrackingInit = r.codelessTrackingInit = function() {
        var u, f = l();
        if (f) {
            var d = "codelessTracking-" + f,
                p = "string" == typeof n.publisherName && -1 === n.publisherName.indexOf("${") ? n.publisherName : null;
            e.TRC[d] = r[d] = e.TRC[d] || (_defineProperty(u = {
                trackedElements: [],
                init: function e() {
                    this.trackedElements = this.getTrackedElements(), this.trackedElements.length && this.setupClickTracking()
                },
                getTrackedElements: function t() {
                    var n = e._tfa && e._tfa.config && e._tfa.config.trackedElements || [];
                    if (Array.isArray(n)) return n;
                    if ("string" == typeof n) try {
                        var r = JSON.parse(n);
                        return Array.isArray(r) ? r : []
                    } catch (e) {
                        return []
                    }
                    return "object" === _typeof(n) ? Object.values(n) : []
                },
                setupClickTracking: function e() {
                    t.addEventListener("click", this.handleClick.bind(this), !0)
                },
                extractElementText: function e(t) {
                    var n = "";
                    return !n && t && void 0 !== t.textContent && (n = t.textContent.trim()), t && void 0 !== t.innerText && (n = t.innerText.trim()), !n && t && t.tagName && "input" === t.tagName.toLowerCase() && (n = t.getAttribute("value") || ""), !n && t && (n = t.getAttribute("aria-label") || t.getAttribute("data-text") || t.getAttribute("title") || ""), n.trim()
                },
                extractHref: function e(t) {
                    if (t) {
                        if (t.tagName && "a" === t.tagName.toLowerCase() && t.href) return this.readAnchorHref(t);
                        var n = t.closest("a");
                        return n ? this.readAnchorHref(n) : void 0
                    }
                },
                readAnchorHref: function e(t) {
                    var n = t.href,
                        r, i;
                    return "string" == typeof n ? n : n && n.baseVal || void 0
                },
                handleClick: function t(n) {
                    var r = n.target;
                    if (this.trackedElements && this.trackedElements.length) {
                        var i = n && n.target && n.target.form;
                        if (!i || i.checkValidity()) {
                            var o = this.findAllMatchingTrackedElements({
                                clickedElement: r,
                                sendCodelessDebugEvents: this.isCodelessDebugEventsAllowed(),
                                isAdvancedMatchingEnabled: this.isAdvancedMatchingEnabled(),
                                isSelectorMatchingByNativeCSSEnabled: this.isSelectorMatchingByNativeCSSEnabled(),
                                publisherName: p
                            });
                            if (o && o.length) {
                                var a = this;
                                o.forEach(function(t) {
                                    t.eventNames && t.eventNames.length && t.eventNames.forEach(function(t) {
                                        a.pushEvent(t), e._tfa.lastNonAutoTrackedClickEvent = n
                                    })
                                })
                            }
                        }
                    }
                },
                isCodelessDebugEventsAllowed: function t() {
                    return e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(s, !1, f)
                },
                isAdvancedMatchingEnabled: function t() {
                    return e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(a, !1, f)
                },
                isSelectorMatchingByNativeCSSEnabled: function t() {
                    return e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(c, !1, f)
                },
                getFeatureFlag: function t(n, r) {
                    return e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(n, r || !1, f)
                }
            }, "isCodelessDebugEventsAllowed", function e() {
                return this.getFeatureFlag(s)
            }), _defineProperty(u, "isAdvancedMatchingEnabled", function e() {
                return this.getFeatureFlag(a)
            }), _defineProperty(u, "isSelectorMatchingByNativeCSSEnabled", function e() {
                return this.getFeatureFlag(c)
            }), _defineProperty(u, "findAllMatchingTrackedElements", function e(t) {
                var n = t.clickedElement,
                    r = this.getElementPath(n),
                    i = this.extractElementText(n),
                    o = this.extractHref(n),
                    a = t.sendCodelessDebugEvents,
                    s = t.publisherName,
                    c = t.isAdvancedMatchingEnabled,
                    l = t.isSelectorMatchingByNativeCSSEnabled;
                try {
                    var u;
                    return this.trackedElements.filter(function(e) {
                        var t = this.isElementMatched({
                            clickedElement: n,
                            trackedElement: e,
                            legacyElementPath: r,
                            elementText: i,
                            elementHref: o,
                            isAdvancedMatchingEnabled: c,
                            isSelectorMatchingByNativeCSSEnabled: l
                        });
                        return t.isMatch && a && this.sendCodelessDebugEvent({
                            matchInfo: t,
                            publisherName: s
                        }), t.isMatch
                    }.bind(this))
                } catch (e) {
                    var d = n ? n.tagName : null;
                    return this.sendCodelessErrorEvent({
                        error: e,
                        functionName: "findAllMatchingTrackedElements",
                        publisherId: f,
                        additionalContext: {
                            clickedElementTag: d
                        }
                    }), []
                }
            }), _defineProperty(u, "isElementMatched", function e(t) {
                var n = t.clickedElement,
                    r = t.trackedElement,
                    a = t.legacyElementPath,
                    s = t.elementText,
                    c = t.elementHref,
                    l = t.isAdvancedMatchingEnabled,
                    u = t.isSelectorMatchingByNativeCSSEnabled;
                if (!r) return {
                    isMatch: !1
                };
                var f = this.isMatchedBySelector({
                        clickedElement: n,
                        trackedSelector: r.selector,
                        legacyElementPath: a,
                        isSelectorMatchingByNativeCSSEnabled: u
                    }),
                    d = this.hasValidDisplayText(r.displayText),
                    p = !!d && this.isMatchedByDisplayText(r.displayText, s),
                    h = this.isMatchedByHref(r.href, c),
                    g;
                return g = l ? !!h || (r.selector ? d ? f && p : f : p) : f || p, {
                    legacyElementPath: a,
                    elementText: s,
                    elementHref: c,
                    trackedElementSelector: r.selector,
                    trackedElementDisplayText: r.displayText,
                    trackedElementHref: r.href,
                    isMatchedBySelector: f,
                    isMatchedByDisplayText: p,
                    isMatchedByHref: h,
                    isMatch: g,
                    eventNames: r.eventNames,
                    matchingStrategy: l ? i : o
                }
            }), _defineProperty(u, "isMatchedBySelector", function e(t) {
                var n = t.clickedElement,
                    r = t.trackedSelector,
                    i = t.legacyElementPath,
                    o = t.isSelectorMatchingByNativeCSSEnabled;
                if (!r) return !1;
                var a = function e() {
                    return i.includes(r)
                };
                if (!o) return a();
                try {
                    return !!n.matches(r) || !!n.closest(r);
                    var s
                } catch (e) {
                    var c = n ? n.tagName : null;
                    return this.sendCodelessErrorEvent({
                        error: e,
                        functionName: "isMatchedBySelector",
                        publisherId: f,
                        additionalContext: {
                            trackedSelector: r,
                            clickedElementTag: c
                        }
                    }), a()
                }
            }), _defineProperty(u, "unescapeEmojis", function e(t) {
                return t ? t.replace(/\\u\{([0-9a-fA-F]+)\}/g, function(e, t) {
                    var n = parseInt(t, 16);
                    return String.fromCodePoint(n)
                }) : ""
            }), _defineProperty(u, "normalizeWhitespace", function e(t) {
                return t && "string" == typeof t ? t.replace(/\s+/g, " ").trim() : ""
            }), _defineProperty(u, "hasValidDisplayText", function e(t) {
                return t && "string" == typeof t && t.trim().length > 0
            }), _defineProperty(u, "isMatchedByDisplayText", function e(t, n) {
                if ("string" != typeof n) return !1;
                var r = this.normalizeWhitespace(this.unescapeEmojis(t)).toLowerCase(),
                    i;
                return this.normalizeWhitespace(n).toLowerCase().includes(r)
            }), _defineProperty(u, "isMatchedByHref", function e(t, n) {
                return !(!t || "string" != typeof t || void 0 === n || !n.toLowerCase().includes(t.toLowerCase()))
            }), _defineProperty(u, "sendLogMessage", function e(t, n, r) {
                if (r) try {
                    var i = new Date,
                        o = i.toTimeString().slice(0, 8).replace(/:/g, "%3A") + "." + i.getMilliseconds().toString().padStart(3, "0"),
                        a = new URL("https://trc.taboola.com/" + r + "/log/2/debug"),
                        s;
                    a.searchParams.set("tim", o), a.searchParams.set("type", n), a.searchParams.set("msg", JSON.stringify(t)), (new Image).src = a.toString()
                } catch (e) {}
            }), _defineProperty(u, "sendCodelessDebugEvent", function e(t) {
                var n = t.matchInfo,
                    r = t.publisherName;
                this.sendLogMessage(n, "CODELESS_TRACKING", r)
            }), _defineProperty(u, "sendCodelessErrorEvent", function e(t) {
                var n = t.error,
                    r = t.functionName,
                    i = t.publisherId,
                    o = t.additionalContext,
                    a = void 0 === o ? {} : o,
                    s, c, l = {
                        errorMessage: "string" == typeof n ? n : n && n.message ? n.message : "Unknown error",
                        errorStack: n && n.stack ? n.stack : void 0,
                        functionName: r,
                        publisherId: i,
                        additionalContext: a,
                        timestamp: (new Date).toISOString()
                    };
                this.sendLogMessage(l, "CODELESS_ERROR", p)
            }), _defineProperty(u, "pushEvent", function t(r) {
                try {
                    var i = f;
                    if (!i) return void this.sendCodelessErrorEvent({
                        error: "Could not find valid publisher id",
                        functionName: "pushEvent",
                        publisherId: null,
                        additionalContext: {
                            eventName: r,
                            configPublisherId: n.publisherId,
                            tfaFirstPublisherId: e._tfa && e._tfa.config && e._tfa.config.firstPublisherId
                        }
                    });
                    i = parseInt(i, 10), e._tfa.push({
                        notify: "event",
                        name: r,
                        id: i
                    })
                } catch (e) {
                    this.sendCodelessErrorEvent({
                        error: e,
                        functionName: "pushEvent",
                        publisherId: f,
                        additionalContext: {
                            eventName: r,
                            parsedId: i
                        }
                    })
                }
            }), _defineProperty(u, "getElementPath", function e(n) {
                for (var r = [], i = n; i && i !== t;) {
                    var o = i.tagName.toLowerCase(),
                        a = i.id ? "#" + i.id : "",
                        s = "";
                    i.className && (s = "." + Array.from(i.classList || i.className.split(" ")).join(".")), r.unshift(o + a + s), i = i.parentElement
                }
                return r.join(" > ")
            }), u), h()
        }

        function h() {
            e._tfa && e._tfa.config && ("complete" === t.readyState || "interactive" === t.readyState ? setTimeout(function() {
                r[d].init()
            }, 0) : t.addEventListener("DOMContentLoaded", function() {
                r[d].init()
            }))
        }
    }, e.TRC.codelessTrackingInit()
}(window, document, {
    publisherName: 'interactivebrokers-sc',
    publisherId: 1603492,
    jsScope: window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']
}),
function(e, t, n) {
    var r = n.jsScope;
    e.TRC = e.TRC || {};
    var i = "tfa:allow-codeless-error-reporting",
        o = "scriptLoadFailure",
        a = "cspViolation",
        s = "windowError",
        c = "codelessInitCheck",
        l = "heavyAdIntervention";

    function u() {
        if (!isNaN(parseInt(n.publisherId, 10))) return n.publisherId;
        if (e._tfa && e._tfa.config && e._tfa.config.firstPublisherId) {
            var t = e._tfa.config.firstPublisherId;
            if (!isNaN(parseInt(t, 10))) return t
        }
        return null
    }
    var f = u();
    if (f && e._tfa && e._tfa.config && e._tfa.config.safeGet && e._tfa.config.safeGet(i, !0, f)) {
        var d, p = r["codelessTracking-" + f];
        if (p && p.sendLogMessage) {
            var h = "string" == typeof n.publisherName && -1 === n.publisherName.indexOf("${") ? n.publisherName : null,
                g = t.getElementById("codeless_script");
            g && g.addEventListener("error", function() {
                b({
                    error: "Script failed to load: " + (g.src || "unknown"),
                    errorType: o,
                    publisherId: f,
                    additionalContext: {
                        scriptSrc: g.src
                    }
                })
            }), t.addEventListener("securitypolicyviolation", function(e) {
                var t = e.blockedURI ? e.blockedURI.split("?")[0] : "";
                t && (t.indexOf("codeless") > -1 || t.indexOf("realizeperformance") > -1 || t.indexOf("code.taboola.com") > -1) && b({
                    error: "CSP violation: " + e.violatedDirective,
                    errorType: a,
                    publisherId: f,
                    additionalContext: {
                        blockedURI: e.blockedURI,
                        violatedDirective: e.violatedDirective,
                        originalPolicy: (e.originalPolicy || "").substring(0, 200)
                    }
                })
            }), e.addEventListener("error", function(e) {
                e.filename && r.codeless && r.codeless.isCodelessResourceUrl(e.filename) && b({
                    error: e.error || e.message,
                    errorType: s,
                    publisherId: f,
                    additionalContext: {
                        filename: e.filename,
                        lineno: e.lineno,
                        colno: e.colno
                    }
                })
            });
            var v = t.referrer && "string" == typeof t.referrer && t.referrer.indexOf("ads.realizeperformance.com") > -1,
                m = !1;
            try {
                m = !!sessionStorage.getItem("taboola-codeless-active")
            } catch (e) {}
            if ((v || m) && !g) {
                var y = !!(e._tfa && e._tfa.config && e._tfa.config.safeGet),
                    S = y && e._tfa.config.safeGet("tfa:allow-codeless-tracking", !1, f);
                b({
                    error: "Codeless expected but not loaded",
                    errorType: c,
                    publisherId: f,
                    additionalContext: {
                        referrerFromRealize: v,
                        codelessInSessionStorage: m,
                        tfaConfigAvailable: y,
                        featureFlagEnabled: !!S
                    }
                })
            }
            "function" == typeof e.ReportingObserver && g && new e.ReportingObserver(function(e) {
                var n = e.find(function(e) {
                    return e.body && "HeavyAdIntervention" === e.body.id
                });
                n && b({
                    error: n.body.message || "Heavy Ad Intervention",
                    errorType: l,
                    publisherId: f,
                    additionalContext: {
                        iframeStillInDom: !!t.getElementById("taboola-codeless-events"),
                        reportId: n.body.id,
                        reportUrl: n.url
                    }
                })
            }, {
                types: ["intervention"],
                buffered: !0
            }).observe()
        }
    }

    function b(e) {
        var t = e.error,
            n = e.errorType,
            r = e.additionalContext || {},
            i, o, a = {
                errorMessage: "string" == typeof t ? t : t && t.message ? t.message : "Unknown error",
                errorStack: t && t.stack ? t.stack : void 0,
                errorType: n,
                publisherId: e.publisherId,
                additionalContext: r,
                timestamp: (new Date).toISOString()
            };
        p.sendLogMessage(a, "CODELESS_LOADING_ERROR", h)
    }
}(window, document, {
    publisherName: 'interactivebrokers-sc',
    publisherId: 1603492,
    jsScope: window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']
}),
function(e, t, n) {
    var r = t.tfaPageManager || {},
        i = "_tfa",
        o = window[i] = window[i] || [],
        a = o.TEM || {},
        s = {
            event: le,
            subscription: fe
        },
        c = /(\S+)taboola(\S+|)\.com\/libtrc\/unip\/(\S+)\/tfa\.js(\S+|)/,
        l = "script[src*='/tfa.js']",
        u = "//",
        f, d = ["notify", "id"],
        p = "JS_PIXEL",
        h = {
            name: "en",
            url: "item-url",
            referrer: "ref",
            timestamp: "tim",
            integrationType: "it"
        },
        g = -1,
        v = {
            protocol: 'https:',
            host: "trc.taboola.com",
            httpMethod: "get",
            loggerEventName: "unip",
            logToConsole: !0
        },
        m = {
            EMPTY_COMMAND: "EMPTY_COMMAND",
            MISSING_NOTIFY: "MISSING_NOTIFY",
            INVALID_NOTIFY: "INVALID_NOTIFY",
            MISSING_NAME: "MISSING_NAME",
            INVALID_ID: "INVALID_ID"
        },
        y = {
            TFA_VALIDATION_ERROR: "TFA_VALIDATION_ERROR"
        },
        S = ((T = {})["page_view"] = de, T),
        b = function() {
            var e = {};
            return e[t.sharedEvents.REQUEST_ID_CREATION_TIMEOUT] = "to", e[t.sharedEvents.REQUEST_ID_CREATION_ERROR] = "err", e[t.sharedEvents.REQUEST_ID_CREATION_JS_ERROR] = "jserr", e[t.sharedEvents.INVALID_TRK_RESPONSE] = "itrkr", e
        }(),
        E = !isNaN(parseFloat(1603492)),
        I = "callback",
        C = "ler",
        T;

    function _() {
        var e = he();
        e.initialized && e.domAccountId && setTimeout(function() {
            for (var e = he().asyncQueue; e.length;) ge(e.shift())
        }, 0)
    }

    function w() {
        var e = k(),
            t;
        if (e && e.src && (t = e.src.replace(c, "$3"))) return /^\d+$/.test(t) ? parseInt(t, 10) : (me("Value '" + t + "' is invalid for 'id' param in script source url '" + e.src + "'. Only numeric values are allowed."), g)
    }

    function k() {
        for (var e = document.querySelectorAll(l), t, n = 0; n < e.length; n++)
            if ((t = e[n]).src && t.src.indexOf("/unip/") > 0) return t
    }

    function R() {
        return t.eventUtils.getDateNow()
    }

    function O(e) {
        e["ce"] = "subscr"
    }

    function P(e) {
        var t = r.getSessionDataFirstPartyCookie();
        void 0 !== t && t && (e["sd"] = t)
    }

    function A(e) {
        var t = U();
        t && (e["ui"] = t)
    }

    function U() {
        try {
            var e = t.tfaUserId.getUserId(),
                n = r.getValue("user-id");
            if (e || n) return e || n
        } catch (e) {
            me("Error while trying to add user-id param", e)
        }
    }

    function N(e) {
        try {
            var n = t.tfaUserId.getClickId();
            n && (e[t.tfaUserId.CLICK_ID_KEY] = n)
        } catch (t) {
            me("Error while trying to addClickIdParam, params=" + JSON.stringify(e), t)
        }
    }

    function D(e) {
        try {
            var n = t.tfaUserId.getCnxClickId();
            n && (e[t.cnxUtil.CNX_CLICK_ID_KEY] = n)
        } catch (t) {
            me("Error while trying to addCnxClickIdParam, params=" + JSON.stringify(e), t)
        }
    }

    function x(e, n) {
        try {
            if (!o.config.safeGet("unip:add-click-id-source", !0, n)) return;
            var r = t.tfaUserId.getClickIdSource();
            r && (e["cis"] = r)
        } catch (t) {
            me("Error while trying to addClickIdSourceParam, params=" + JSON.stringify(e), t)
        }
    }

    function L(e) {
        var n = he();
        n.referrer || (n.referrer = t.trk.getReferrer()), e[h.referrer] = n.referrer
    }

    function M(e, t) {
        var n = h.url,
            r;
        we(be(e), t) && (e[n] = e[n] || document.location.href)
    }

    function j(e) {
        var t = {},
            n = !1,
            r;
        for (var i in e[h.timestamp] = R(), e) !e.hasOwnProperty(i) || d.indexOf(i) >= 0 || (t[r = h.hasOwnProperty(i) ? h[i] : i] = e[i], n = !0);
        return n && t
    }

    function V(e, t) {
        $(t), G(e, t)
    }

    function B(e) {
        var n;
        if (t.privacySandbox && t.privacySandbox.isProtectedAudienceSupported()) try {
            n = JSON.parse(e), t.privacySandbox.joinInterestGroupsInIframe(n)
        } catch (e) {}
    }

    function F() {
        200 === this.status && B(this.responseText)
    }

    function K(e) {
        return !!(t.privacySandbox && t.privacySandbox.isProtectedAudienceSupported() && e && "pre_d_eng_tb" !== e[h.name]) && (e["psb"] = "true", !0)
    }

    function G(e, n) {
        var r = Ee(e) + u + Ie(e, n),
            i, o;
        te(n, e), H(n, e), (o = K(n)) && (i = F);
        try {
            t.TRCLogger[v.httpMethod](r, v.loggerEventName, n, e, i)
        } catch (t) {
            me("Error while trying to send to server event with id '" + e + "' and params '" + JSON.stringify(n) + "'.", t)
        }
    }

    function $(e) {
        var t = U(),
            n = e[I];
        if (n) {
            if (!t) return ye("No UserId to notify callback"), void delete e[I];
            if ("function" != typeof n) return ye("Callback function parameter is not a function " + n), void delete e[I];
            try {
                n({
                    userId: t
                })
            } catch (e) {
                me("Error calling advertiser callback", e)
            }
            delete e[I]
        }
    }

    function H(e, t) {
        A(e), N(e), x(e, t), D(e), L(e), se(e), M(e, t), J(e), q(e), Z(e, t), z(e, t), ee(e, t), Q(e)
    }

    function q(e) {
        var n = t.lastExternalReferrer.getLastExternalReferrer();
        n && (e[C] = n)
    }

    function Q(e) {
        var t = h.integrationType,
            n = e[t];
        n ? n !== p && (r.currentIntegrationType = n) : r.currentIntegrationType ? e[t] = r.currentIntegrationType : (r.scriptIntegrationType || (r.scriptIntegrationType = ke(), r.scriptIntegrationType && r.scriptIntegrationType !== p && (r.currentIntegrationType = r.scriptIntegrationType)), r.scriptIntegrationType ? e[t] = r.scriptIntegrationType : e[t] = p)
    }

    function z(e, n) {
        var r;
        o.config.safeGet("unip:collect-cookie-banner-consent:enabled", !0, n) && (r = t.trk.parseCookieBanner()) && (e.cbp = r.cookieBannerProvider.providerName, e.cbpv = r.cookieBannerProvider.version, r.cookieBannerConsent.tcString && o.config.safeGet("unip:send-tc-string:enabled", !0, n) ? (e.tcs = r.cookieBannerConsent.tcString, void 0 !== r.cookieBannerConsent.gdprApplies && (e.ga = r.cookieBannerConsent.gdprApplies), void 0 !== r.cookieBannerConsent.cmpStatus && (e.cmps = r.cookieBannerConsent.cmpStatus)) : r.cookieBannerConsent.consentData && (e.cbcd = r.cookieBannerConsent.consentData))
    }

    function J(e) {
        e && a && a.ESU && a.ESU.getIsLocalStorageAvailable() && (W(e), Y(e), X(e))
    }

    function W(e) {
        a.TOS && (e.tos = a.TOS.getTimeOnSite())
    }

    function Y(e) {
        if (a.SSD) {
            var n = a.SSD.getMetric(),
                r = t.eventUtils.hashString(window.location.href);
            a.SSD.isURLVisited(r) || n++, e.ssd = n
        }
    }

    function X(e) {
        a.SCD && (e.scd = a.SCD.getScrollDepth())
    }

    function Z(e, n) {
        o.config.safeGet("unip:add-ccpa-params", !0, n) && t.trk.getCcpaParam(function(t) {
            t && (e["ccpaPs"] = t)
        })
    }

    function ee(e, n) {
        if (o.config.safeGet("unip:add-gpp-params", !1, n)) try {
            t.trk.getGppParam(function(t) {
                t && (e.cmpStatus = 0, e.applicableSections = t.pingData.applicableSections, e.gppString = t.pingData.gppString)
            })
        } catch (e) {}
    }

    function te(e, t) {
        re(e), ie(e, t), oe(e, t)
    }

    function ne(e, t) {
        O(t), P(t), ue(e, t)
    }

    function re(e) {
        e["vi"] = t.trk.getViewId()
    }

    function ie(e, n) {
        var r = t.trk.getPublisherRequestId(n);
        r && (e["ri"] = r)
    }

    function oe(e, n) {
        var r = t.trk.getPublisherSessionData(n);
        r && (e["sd"] = r)
    }

    function ae(e, t) {
        e["mrir"] = t
    }

    function se(e) {
        e["cv"] = n
    }

    function ce(e, n) {
        var r = he(),
            i;
        if (!t.trk.getPublisherRequestId(e)) {
            if (t.trk.isRequestProcessing(e)) return void r.messageDelayer.delayMessage(e, n, {
                successCallback: V,
                failCallback: function e(t, n, r, i) {
                    var o = b[i];
                    o || (o = i), ae(n, o), G(t, n)
                },
                timeoutInMillis: Se(e)
            });
            ae(n, t.trk.getRequestStatus(e))
        }
        G(e, n)
    }

    function le(e, n) {
        var r = j(e),
            i = be(r),
            o = S[i];
        if (n = parseInt(n, 10), !o || !o(r, n)) {
            if (Te(n)) {
                if (_e(n)) return void ce(n, r);
                t.trk.getPublisherRequestId(n) || ae(r, "wffo")
            } else ae(r, "ttd");
            G(n, r)
        }
    }

    function ue(e, t) {
        void 0 !== e["sourceurl"] && e["sourceurl"] && (t["surl"] = e["sourceurl"])
    }

    function fe(e, t) {
        var n = j(e);
        ne(e, n), G(parseInt(t, 10), n)
    }

    function de(e, n) {
        var r = he(),
            i = !1;
        return n && (i = Ce(n), H(e), r.pageViewAccountIds[n] = parseInt(n, 10), e["external-pixel-id"] && (r.externalPixelId = e["external-pixel-id"]), e["external-source"] && (r.externalSource = e["external-source"]), t.eventUtils.dispatchEvent(t.sharedEvents.PAGE_VIEW, {
            accountId: n,
            publisherIdType: t.publisherIdType.ID,
            pageViewInitiator: t.pageViewInitiator.TFA,
            isUnifiedPageView: i,
            metadata: e
        })), i
    }

    function pe(e) {
        return e ? e.notify ? s.hasOwnProperty(e.notify) ? e.name ? !(e.hasOwnProperty("id") && !/^\d+$/.test(e.id)) || (ve(m.INVALID_ID, e, "Value '" + e.id + "' is invalid for 'id' field in command '" + JSON.stringify(e) + "'. Only numeric values are allowed."), !1) : (ve(m.MISSING_NAME, e, "Mandatory 'name' field is missing in command '" + JSON.stringify(e) + "'."), !1) : (ve(m.INVALID_NOTIFY, e, "Value '" + e.notify + "' is invalid for 'notify' field in command '" + JSON.stringify(e) + "'."), !1) : (ve(m.MISSING_NOTIFY, e, "Mandatory 'notify' field is missing in command '" + JSON.stringify(e) + "'."), !1) : (ve(m.EMPTY_COMMAND, e, "Command is '" + e + "'."), !1)
    }

    function he() {
        return window && window[i] && window[i].TUP || {}
    }

    function ge(e) {
        var t, n;
        if (pe(e))
            if (t = he(), n = e.id || t.domAccountId) {
                if (n !== g) try {
                    s[e.notify](e, n)
                } catch (t) {
                    me("An error occurred while handling command '" + JSON.stringify(e) + "'.", t)
                }
            } else t.asyncQueue.push(e)
    }

    function ve(e, n, r) {
        var i = he();
        t.eventUtils.dispatchEvent(y.TFA_VALIDATION_ERROR, {
            accountId: i.domAccountId,
            errorCode: e,
            command: n
        }), me(r)
    }

    function me(e, t) {
        v.logToConsole && ye(e, t)
    }

    function ye(e, t) {
        t ? console.log("Taboola Pixel: " + e, t) : console.log("Taboola Pixel: " + e)
    }

    function Se(e) {
        return 500 + o.config.safeGet("tfa:trk:tracking-request-timeout", 2e3, e)
    }

    function be(e) {
        return e[h.name]
    }

    function Ee(e) {
        return o.config.safeGet("tfa:default-protocol", v.protocol, e)
    }

    function Ie(e, t) {
        var n = be(t),
            r;
        return o.config.safeGet("tfa:event-host-map", {}, e)[n] || v.host
    }

    function Ce(e) {
        return Te(e) && o.config.safeGet("tfa:trk:is-unified-page-view", !1, e)
    }

    function Te(e) {
        return o.config.safeGet("tfa:trk:enabled", !0, e)
    }

    function _e(e) {
        return o.config.safeGet("tfa:trk:wait-for-request-id", !0, e)
    }

    function we(e, t) {
        var n = o.config.safeGet("tfa:add-item-url:event-list", [], t);
        return "*" === n || n.indexOf(e) >= 0
    }

    function ke() {
        var e = k(),
            t;
        if (e && e.src && (t = e.src.match(/[?&]it=([^&]+)/)) && t[1]) try {
            return decodeURIComponent(t[1])
        } catch (e) {
            return t[1]
        }
    }

    function Re() {
        var e = o.TUP = o.TUP || {},
            n = o.config.safeGet("tfa:get-publisher-id-from-baker", !1);
        e.domAccountId = e.domAccountId || (n && E ? 1603492 : w()), e.initialized || (e.push = o.TUP.push || ge, e.initialized = !0, e.asyncQueue = [], e.EVENTS = y, e.pageViewAccountIds = {}, e.messageDelayer = new t.MessageDelayer("publisherId", t.sharedEvents.REQUEST_ID_CREATED, [t.sharedEvents.REQUEST_ID_CREATION_JS_ERROR, t.sharedEvents.REQUEST_ID_CREATION_ERROR, t.sharedEvents.REQUEST_ID_CREATION_TIMEOUT, t.sharedEvents.INVALID_TRK_RESPONSE]), a && a.init && a.init(), r.scriptIntegrationType = ke(), r.scriptIntegrationType && r.scriptIntegrationType !== p && (r.currentIntegrationType = r.scriptIntegrationType)), _()
    }
    Re()
}(window, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC'], "20261004-14-RELEASE"),
function(e, t, n) {
    var r = "_tfa",
        i, o = {
            orderid: "orderid",
            currency: "currency",
            revenue: "revenue",
            quantity: "quantity",
            name: "name",
            attributionGroup: "attributionGroup"
        },
        a = {
            type: "marking-type"
        },
        s = 'https:' + "//trc.taboola.com/{$publishreId}log/3/{$logType}?",
        c = /(\S+)taboola(\S+|)\.com\/libtrc\/(\S+)\/tfa\.js(\S+|)/,
        l = "unip/",
        u = [],
        f = [],
        d = "_tecq",
        p = "_dcojobs",
        h = !isNaN(parseFloat(1603492));

    function g(e) {
        var t;
        switch (e.notify) {
            case "action":
                t = u;
                break;
            case "mark":
                t = f;
                break;
            case "event":
            case "subscription":
                t = i.TUP;
                break;
            case "ecevent":
                var n = i.config && i.config.safeGet("tfa:ecomm:enabled", !1, e.id),
                    r = i.config && i.config.safeGet("tfa:ecomm:cnx-enabled", !1, e.id);
                n || r ? t = window[d] = window[d] || [] : i.config && i.config.safeGet("tfa:dco:jobs:enabled", !1, e.id) && (t = window[p] = window[p] || []);
                break;
            default:
                return
        }
        t && t.push(e)
    }

    function v() {
        return n.tfaUserId && n.tfaUserId.getUserId() ? "&ui=" + encodeURIComponent(n.tfaUserId.getUserId()) : ""
    }

    function m() {
        return n.tfaUserId && n.tfaUserId.getClickId() ? "&" + n.tfaUserId.CLICK_ID_KEY + "=" + encodeURIComponent(n.tfaUserId.getClickId()) : ""
    }

    function y() {
        var t, n, r, i;
        if (r = e._tfa.config.safeGet("tfa:get-publisher-id-from-baker", !1) && h ? 1603492 : w())
            for (t = 0, n = u.length; t < n; t++) E(b(s, {
                $publishreId: r ? r + "/" : "",
                $logType: "action"
            }) + "tim=" + escape(C()) + "&item-url=" + escape(I()) + k(o, u.shift()) + T() + v() + m())
    }

    function S() {
        var t, n, r, i;
        if (r = e._tfa.config.safeGet("tfa:get-publisher-id-from-baker", !1) && h ? 1603492 : w())
            for (t = 0, n = f.length; t < n; t++) E(b(s, {
                $publishreId: r ? r + "/" : "",
                $logType: "mark"
            }) + "tim=" + escape(C()) + "&item-url=" + escape(I()) + k(a, f.shift()) + T() + v() + m())
    }

    function b(e, t) {
        return e.replace(/\{([^{}]*)\}/g, function(e, n) {
            var r = t[n];
            return "string" == typeof r || "number" == typeof r ? r : e
        })
    }

    function E(t) {
        var n = new Image;
        e._tfa.config.safeGet("tfa:add-referrer-policy-when-firing-pixel", !0) && (n.referrerPolicy = "no-referrer-when-downgrade"), n.src = t
    }

    function I() {
        return e.location.href
    }

    function C() {
        var e = new Date,
            t = e.getHours(),
            n = e.getMinutes(),
            r = e.getSeconds() + e.getMilliseconds() / 1e3;
        return (t < 10 ? "0" : "") + t + ":" + (n < 10 ? "0" : "") + n + ":" + (r < 10 ? "0" : "") + r.toFixed(3)
    }

    function T() {
        var n = e.location.search,
            r = t.referrer.match(/(\?\S+)$/g),
            i = "";
        return i = _(n.replace(/^\?/, "").split(/&/)) + (r ? _(r[0].replace(/^\?/, "").split(/&/)) : "")
    }

    function _(e) {
        var t = "",
            n, r, i = "trc_";
        for (n = 0, r = e.length; n < r; n++) 0 == e[n].indexOf(i) && (t = t + "&" + e[n]);
        return t
    }

    function w() {
        var e = document.getElementsByTagName("script"),
            t, n, r = "",
            i;
        for (t = 0, n = e.length; t < n; t++)
            if ((i = e[t].src) && (r = i.replace(c, "$3")) !== e[t].src && r.indexOf(l) < 0) return r;
        return r
    }

    function k(e, t) {
        var n, r = "";
        for (n in e) void 0 !== t[n] && (r += "&" + e[n] + "=" + t[n]);
        return r
    }

    function R(e) {
        for (var t = 0; t < arguments.length; t++)(e = arguments[t]) instanceof Object && g(e);
        return O(), arguments.length
    }

    function O() {
        y(), S()
    }

    function P() {
        for (; i.length;) R(i.shift())
    }

    function A() {
        (i = e[r] = e[r] || []).registered || (i.push = R, i.registered = !0, P())
    }
    A()
}(window, document, window['TFASC'.indexOf("{jsScope}") >= 0 ? "TRC" : 'TFASC']);